# Workboard

Requires Node.js 22.22.1. No dependencies need installing.

Run:

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
```

Open http://localhost:8080. The server binds to `0.0.0.0`; `/health` returns JSON health status. Projects and their tasks (including completion state) are stored in the configured SQLite file. Open a project to create tasks, toggle completion, and filter by All, Open, or Completed. Combine this with the Priority filter (All, Low, Normal, High); both selections remain unchanged during task edits, and only tasks matching both filters appear in creation order. Filters remain usable in archived projects and do not affect completion summaries. Filter the project list by Active or Archived, archive projects, or restore them without losing tasks. Active project pages support renaming projects and individual tasks without changing their identity, order, ownership, or completion state. Each task has a saved Low, Normal, or High priority, independent of its title and completion. Each project has a saved Default task priority (initially Normal); new tasks inherit it, while existing tasks are unchanged. Defaults persist through renaming, archival, restoration, and restarts without resetting task filters. Each task also has an optional Task due date: enter a real Gregorian date in YYYY-MM-DD format (years 0001–9999) and select Save due date. Surrounding whitespace is trimmed; empty input clears the date. Invalid dates show an alert without changing saved data. Dates persist independently without timezone conversion or changes to filters, summaries, or other task fields. Use Due from and Due through with Apply due range to intersect inclusive calendar boundaries with both task filters. Blank boundaries are unbounded; undated tasks only match when both are blank. Invalid ranges leave the previous applied range unchanged. Edits retain the applied range and both selections; reopening from the project list resets the range. Due-range controls remain usable while archived. Archived projects remain viewable with read-only tasks and disabled rename, priority, default-priority, and due-date controls. Each project row shows its completed/total task count. Defaults are port 8080 and `data/workboard.sqlite`.

Verify:

```sh
npm test
```

Tests use a temporary database and verify project and task creation, blank-input validation, ordering, escaping, detail navigation, project isolation, completion toggling, filtering, archive/restore, read-only archived tasks, completion summaries, rename validation and identity preservation, archived project and task rename protection, task rename validation and ownership preservation, priority defaults and edits, priority validation and ownership protection, archived priority controls, all combined filter intersections, preserved filter selections and immediate row re-evaluation after edits, archived combined filtering, legacy schema migration (including existing tasks), project-default migration, independent defaults and inheritance, unchanged existing tasks and filter selections, archived default protection, due-date calendar validation, clearing, ownership isolation, filter preservation, archived date protection, due-date migration, inclusive and one-sided due ranges, invalid and reversed range handling, intersected filters and range preservation through edits, archived range controls, reopening resets, and persistence across server restarts.
