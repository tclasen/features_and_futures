const view = document.querySelector('#project-view');

async function request(path, options = {}) {
  const response = await fetch(path, options);
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || 'Something went wrong');
  return body;
}

function heading(text) {
  const element = document.createElement('h1');
  element.textContent = text;
  return element;
}

async function showProjects() {
  view.replaceChildren(heading('Workboard'));
  const form = document.createElement('form');
  form.className = 'project-form';
  const label = document.createElement('label');
  label.htmlFor = 'project-name';
  label.textContent = 'Project name';
  const input = document.createElement('input');
  input.id = 'project-name';
  input.name = 'name';
  input.type = 'text';
  input.autocomplete = 'off';
  const filterLabel = document.createElement('label');
  filterLabel.htmlFor = 'project-filter';
  filterLabel.textContent = 'Project filter';
  const filter = document.createElement('select');
  filter.id = 'project-filter';
  for (const value of ['Active', 'Archived']) {
    const option = document.createElement('option');
    option.value = value === 'Archived' ? 'archived' : 'active';
    option.textContent = value;
    filter.append(option);
  }
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.textContent = 'Create project';
  const alert = document.createElement('p');
  alert.className = 'alert';
  alert.setAttribute('role', 'alert');
  alert.hidden = true;
  form.append(label, input, submit, alert);
  const list = document.createElement('section');
  list.className = 'project-list';
  list.setAttribute('aria-label', 'Projects');
  view.append(form, filterLabel, filter, list);

  async function refresh() {
    const projects = await request(`/api/projects?archived=${filter.value === 'archived'}`);
    list.replaceChildren(...projects.map((project) => {
      const row = document.createElement('article');
      row.className = 'project-row';
      row.dataset.testid = 'project-row';
      const name = document.createElement('span');
      name.textContent = project.name;
      const summary = document.createElement('span');
      summary.dataset.testid = 'project-summary';
      summary.textContent = `${project.completedCount}/${project.totalCount} completed`;
      const open = document.createElement('button');
      open.type = 'button';
      open.textContent = 'Open project';
      open.addEventListener('click', () => { window.location.href = `/projects/${encodeURIComponent(project.id)}`; });
      row.append(name, summary, open);
      const archive = document.createElement('button');
      archive.type = 'button';
      archive.textContent = project.archived ? 'Restore project' : 'Archive project';
      archive.addEventListener('click', async () => {
        await request(`/api/projects/${encodeURIComponent(project.id)}/archive`, {
          method: 'PATCH', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ archived: !project.archived }),
        });
        await refresh();
      });
      row.append(archive);
      return row;
    }));
  }

  filter.addEventListener('change', () => refresh().catch((error) => {
    alert.textContent = error.message;
    alert.hidden = false;
  }));

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    alert.hidden = true;
    try {
      await request('/api/projects', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: input.value }),
      });
      input.value = '';
      await refresh();
    } catch (error) {
      alert.textContent = error.message;
      alert.hidden = false;
    }
  });
  await refresh();
}

async function showProject(id) {
  const project = await request(`/api/projects/${encodeURIComponent(id)}`);
  view.replaceChildren(heading(project.name));
  if (project.archived) {
    const archivedNotice = document.createElement('p');
    archivedNotice.textContent = 'Archived project';
    view.append(archivedNotice);
  }
  const back = document.createElement('button');
  back.type = 'button';
  back.textContent = 'Projects';
  back.addEventListener('click', () => { window.location.href = '/'; });
  const form = document.createElement('form');
  form.className = 'task-form';
  const label = document.createElement('label');
  label.htmlFor = 'task-title';
  label.textContent = 'Task title';
  const input = document.createElement('input');
  input.id = 'task-title';
  input.name = 'title';
  input.type = 'text';
  input.autocomplete = 'off';
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.textContent = 'Create task';
  submit.disabled = project.archived;
  input.disabled = project.archived;
  const alert = document.createElement('p');
  alert.className = 'alert';
  alert.setAttribute('role', 'alert');
  alert.hidden = true;
  form.append(label, input, submit, alert);

  const filterLabel = document.createElement('label');
  filterLabel.htmlFor = 'task-filter';
  filterLabel.textContent = 'Task filter';
  const filter = document.createElement('select');
  filter.id = 'task-filter';
  for (const value of ['All', 'Open', 'Completed']) {
    const option = document.createElement('option');
    option.value = value.toLowerCase();
    option.textContent = value;
    filter.append(option);
  }
  const list = document.createElement('section');
  list.className = 'task-list';
  list.setAttribute('aria-label', 'Tasks');
  view.append(back, form, filterLabel, filter, list);

  async function refresh() {
    const tasks = await request(`/api/projects/${encodeURIComponent(id)}/tasks`);
    const visible = tasks.filter((task) => filter.value === 'all' || (filter.value === 'completed') === task.completed);
    list.replaceChildren(...visible.map((task) => {
      const row = document.createElement('article');
      row.className = 'task-row';
      row.dataset.testid = 'task-row';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = task.completed;
      checkbox.disabled = project.archived;
      checkbox.setAttribute('aria-label', `Complete ${task.title}`);
      checkbox.addEventListener('change', async () => {
        checkbox.disabled = true;
        try {
          await request(`/api/projects/${encodeURIComponent(id)}/tasks/${encodeURIComponent(task.id)}`, {
            method: 'PATCH', headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ completed: checkbox.checked }),
          });
          await refresh();
        } catch (error) {
          checkbox.checked = task.completed;
          alert.textContent = error.message;
          alert.hidden = false;
        }
      });
      const title = document.createElement('span');
      title.textContent = task.title;
      row.append(checkbox, title);
      return row;
    }));
  }

  filter.addEventListener('change', () => refresh().catch(showTaskError));
  function showTaskError(error) {
    alert.textContent = error.message;
    alert.hidden = false;
  }
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    alert.hidden = true;
    try {
      await request(`/api/projects/${encodeURIComponent(id)}/tasks`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ title: input.value }),
      });
      input.value = '';
      await refresh();
    } catch (error) { showTaskError(error); }
  });
  await refresh();
}

const match = window.location.pathname.match(/^\/projects\/([^/]+)\/?$/);
if (match) {
  showProject(decodeURIComponent(match[1])).catch(() => { window.location.href = '/'; });
} else {
  showProjects().catch((error) => {
    view.replaceChildren(heading('Workboard'));
    const message = document.createElement('p');
    message.setAttribute('role', 'alert');
    message.textContent = error.message;
    view.append(message);
  });
}
