# Workboard

Requires Node.js 22.22.1. There are no application dependencies to install.

```sh
npm start
```

The server binds to `0.0.0.0` at `PORT` (default `8080`). Set `DB_PATH` to the
SQLite file to use (default `data/workboard.sqlite`). Its parent directory is
created automatically. Keep this file to preserve projects, tasks, and completion
state, priorities, and archive status between restarts. Existing databases are migrated
automatically without changing project IDs or tasks.

```sh
PORT=8080 DB_PATH=data/workboard.sqlite npm start
npm test
```

`GET /health` returns HTTP 200 with `{"status":"ok"}`. Project creation and
navigation use ordinary browser forms. Names are trimmed before persistence;
blank names return a visible validation alert without creating a project.
Each project has its own tasks. Titles are trimmed and blank titles show a
validation alert. Checkboxes save completion immediately; the task filter shows
All (the default), Open, or Completed tasks in creation order. Direct project
URLs remain usable after reloads and restarts.

The project filter defaults to Active and also offers Archived. Archive project
moves a project to Archived; Restore project returns it to Active, retaining its
tasks and completion state. Archived project pages allow viewing and filtering
tasks but disable creation and completion changes. The server also rejects task
changes on archived projects. Each project row shows completed/total task counts
across all its tasks.

Active project pages offer New project name and Rename project. Renaming trims
the name and preserves the project URL, creation order, tasks, and completion
summary. Blank names show a validation alert without changing the saved name.
Archived projects disable renaming, and the server rejects rename requests until
the project is restored. Renamed project names persist between restarts.

Each task row offers New task title and Rename task. Renaming trims the title
and updates the completion checkbox label while preserving ownership, creation
order, completion, filter membership, and project counts. Blank titles show an
alert without changing the saved task. Archived projects disable task renaming;
the server rejects changes until restoration. Task titles persist between restarts.

Each task row has a Task priority selector with Low, Normal, and High options.
Existing and new tasks default to Normal. Changes save immediately and persist
between restarts, independently of completion and renaming. Archived projects
disable priority changes in the browser and on the server; restoration preserves
the saved priorities.
