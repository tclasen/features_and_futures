# Workboard

Requires Node.js 22.22.1. No installation or external dependencies are needed.

```sh
npm start
```

The HTTP server binds to `0.0.0.0` at `PORT` (default `8080`). SQLite data is stored at `DB_PATH` (default `data/workboard.sqlite`); parent directories are created automatically. Keep this file to preserve projects, archive state, tasks, task completion, task priorities, project default priorities, and task due dates across restarts. Existing databases are migrated automatically without losing data.

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
npm test
```

`GET /health` returns `{"status":"ok"}`. The application uses server-rendered forms. Each project has its own tasks, completion checkboxes, an All/Open/Completed task filter, and an All/Low/Normal/High priority filter. Both filters apply together in creation order and remain selected through task edits, including when a changed task no longer matches. Opening a project from the list starts both filters at All. Filter selections are URL query parameters, not saved task data, and never affect completion summaries. Small browser change handlers submit completion and filter forms immediately; without JavaScript, fallback buttons submit them explicitly. The project list supports Active/Archived filtering, archive/restore controls, and completion summaries across all tasks. Active projects can be renamed with a trimmed, nonblank name without changing their URL, creation order, or tasks. Each task can also be renamed with a trimmed, nonblank title, preserving its identity, owner, order, completion state, and filter membership. Each task has an independent Low/Normal/High priority. Each project's Default task priority starts at Normal and is saved independently; new tasks inherit it at creation. Changing the default preserves all existing tasks and both selected filters. Migrated tasks retain their priorities (or initialize to Normal if absent). Priority changes preserve task identity, order, completion, and summaries; renaming preserves priority. Tasks optionally have a due date saved with Save due date. Blank input clears it; otherwise trimmed input must be a real Gregorian date in YYYY-MM-DD format with year 0001–9999. Dates are stored as calendar days without timezone conversion. Invalid dates show an alert and leave the saved value unchanged. Due-date edits preserve both selected filters and all other task data; renaming preserves the date. Archived projects remain readable and filterable, but project/task renaming, task creation, completion changes, task priority changes, default priority changes, and due-date changes are blocked both in the UI and on the server. Restoring a project preserves its tasks and enables renaming again.

Tests use a temporary database and check schema migration, validation, escaping, ordering, project isolation, completion, filtering, archive/restore, rename identity preservation, priority defaults and validation, independent priority edits, all combined filter combinations, selection preservation and immediate re-filtering after edits, project defaults and inheritance without retroactive changes, strict Gregorian date boundaries, date saving and clearing, due-date isolation and preservation, read-only restrictions, detail navigation, and process-restart persistence.
