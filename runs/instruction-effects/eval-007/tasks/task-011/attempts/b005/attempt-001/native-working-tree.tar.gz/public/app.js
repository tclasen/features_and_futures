import { filterTasks, normalizeDueRange } from './task-filters.js';

const app = document.querySelector('#app');

async function api(path, options) {
  const response = await fetch(path, options);
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || 'Unable to complete request');
  return value;
}

function showAlert(message) {
  let alert = app.querySelector('[role="alert"]');
  if (!alert) {
    alert = document.createElement('p');
    alert.setAttribute('role', 'alert');
    app.append(alert);
  }
  alert.textContent = message;
}

function projectRow(project, onArchiveChange) {
  const row = document.createElement('li');
  row.dataset.testid = 'project-row';
  const name = document.createElement('span');
  name.textContent = project.name;
  const open = document.createElement('button');
  open.type = 'button';
  open.textContent = 'Open project';
  open.addEventListener('click', () => location.assign(`/projects/${project.id}`));
  const summary = document.createElement('span');
  summary.dataset.testid = 'project-summary';
  summary.textContent = `${project.completed_count}/${project.total_count} completed`;
  const archive = document.createElement('button');
  archive.type = 'button';
  archive.textContent = project.archived ? 'Restore project' : 'Archive project';
  archive.addEventListener('click', async () => {
    archive.disabled = true;
    showAlert('');
    try {
      const saved = await api(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archived: !project.archived }),
      });
      onArchiveChange(saved);
    } catch (error) {
      showAlert(error.message);
    } finally {
      archive.disabled = false;
    }
  });
  row.append(name, summary, open, archive);
  return row;
}

async function showProjects() {
  app.innerHTML = `
    <h1>Workboard</h1>
    <form>
      <label for="project-name">Project name</label>
      <div class="form-controls">
        <input id="project-name" name="name" type="text" autocomplete="off">
        <button type="submit">Create project</button>
      </div>
    </form>
    <p role="alert"></p>
    <label for="project-filter">Project filter</label>
    <select id="project-filter">
      <option>Active</option>
      <option>Archived</option>
    </select>
    <ul aria-label="Projects"></ul>
  `;
  const form = app.querySelector('form');
  const input = app.querySelector('input');
  const button = form.querySelector('button');
  const list = app.querySelector('ul');
  const filter = app.querySelector('select');
  let projects = [];
  function renderProjects() {
    const visible = projects.filter((project) => project.archived === (filter.value === 'Archived'));
    list.replaceChildren(...visible.map((project) => projectRow(project, (saved) => {
      Object.assign(project, saved);
      renderProjects();
    })));
  }
  filter.addEventListener('change', renderProjects);
  // Load first so submissions cannot race the initial list render.
  button.disabled = true;
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (button.disabled) return;
    const name = input.value.trim();
    if (!name) return showAlert('Project name is required');
    button.disabled = true;
    showAlert('');
    try {
      const project = await api('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      projects.push(project);
      renderProjects();
      input.value = '';
      input.focus();
    } catch (error) {
      showAlert(error.message);
    } finally {
      button.disabled = false;
    }
  });
  try {
    projects = await api('/api/projects');
    renderProjects();
  } finally {
    button.disabled = false;
  }
}

async function showProject(id) {
  const back = document.createElement('button');
  back.textContent = 'Projects';
  back.type = 'button';
  back.addEventListener('click', () => location.assign('/'));
  app.append(back);
  const project = await api(`/api/projects/${id}`);
  const destinations = (await api('/api/projects')).filter((candidate) => !candidate.archived && candidate.id !== project.id);
  const heading = document.createElement('h1');
  heading.textContent = project.name;
  app.prepend(heading);
  document.title = `${project.name} — Workboard`;
  if (project.archived) {
    const notice = document.createElement('p');
    notice.textContent = 'Archived project';
    app.append(notice);
  }
  const renameForm = document.createElement('form');
  renameForm.innerHTML = `
    <label for="new-project-name">New project name</label>
    <div class="form-controls">
      <input id="new-project-name" name="name" type="text" autocomplete="off">
      <button type="submit">Rename project</button>
    </div>
  `;
  const renameInput = renameForm.querySelector('input');
  const renameButton = renameForm.querySelector('button');
  renameInput.disabled = project.archived;
  renameButton.disabled = project.archived;
  renameForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (renameButton.disabled) return;
    const name = renameInput.value.trim();
    if (!name) return showAlert('Project name is required');
    renameButton.disabled = true;
    showAlert('');
    try {
      const saved = await api(`/api/projects/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      Object.assign(project, saved);
      heading.textContent = project.name;
      document.title = `${project.name} — Workboard`;
      renameInput.value = '';
      renameInput.focus();
    } catch (error) {
      showAlert(error.message);
    } finally {
      renameButton.disabled = project.archived;
    }
  });
  app.append(renameForm);
  const controls = document.createElement('section');
  controls.innerHTML = `
    <label for="default-task-priority">Default task priority</label>
    <select id="default-task-priority">
      <option>Low</option>
      <option>Normal</option>
      <option>High</option>
    </select>
    <form>
      <label for="task-title">Task title</label>
      <div class="form-controls">
        <input id="task-title" name="title" type="text" autocomplete="off">
        <button type="submit" disabled>Create task</button>
      </div>
    </form>
    <p role="alert"></p>
    <label for="task-filter">Task filter</label>
    <select id="task-filter">
      <option>All</option>
      <option>Open</option>
      <option>Completed</option>
    </select>
    <label for="priority-filter">Priority filter</label>
    <select id="priority-filter">
      <option>All</option>
      <option>Low</option>
      <option>Normal</option>
      <option>High</option>
    </select>
    <form id="due-range-form">
      <label for="due-from">Due from</label>
      <input id="due-from" type="text" autocomplete="off">
      <label for="due-through">Due through</label>
      <input id="due-through" type="text" autocomplete="off">
      <button type="submit">Apply due range</button>
    </form>
    <ul aria-label="Tasks"></ul>
  `;
  app.append(controls);
  const form = controls.querySelector('form');
  const input = controls.querySelector('input');
  const button = form.querySelector('button');
  const filter = controls.querySelector('#task-filter');
  const priorityFilter = controls.querySelector('#priority-filter');
  const defaultPriority = controls.querySelector('#default-task-priority');
  defaultPriority.value = project.default_task_priority;
  defaultPriority.disabled = project.archived;
  defaultPriority.addEventListener('change', async () => {
    defaultPriority.disabled = true;
    showAlert('');
    try {
      const saved = await api(`/api/projects/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ default_task_priority: defaultPriority.value }),
      });
      Object.assign(project, saved);
    } catch (error) {
      showAlert(error.message);
    } finally {
      defaultPriority.value = project.default_task_priority;
      defaultPriority.disabled = project.archived;
    }
  });
  const list = controls.querySelector('ul');
  const tasksPath = `/api/projects/${id}/tasks`;
  let tasks = [];
  let dueRange = { from: '', through: '' };
  const rangeForm = controls.querySelector('#due-range-form');
  const dueFrom = controls.querySelector('#due-from');
  const dueThrough = controls.querySelector('#due-through');
  rangeForm.addEventListener('submit', (event) => {
    event.preventDefault();
    try {
      const nextRange = normalizeDueRange(dueFrom.value, dueThrough.value);
      dueRange = nextRange;
      dueFrom.value = dueRange.from;
      dueThrough.value = dueRange.through;
      showAlert('');
      renderTasks();
    } catch (error) {
      showAlert(error.message);
    }
  });

  function renderTasks() {
    const visible = filterTasks(tasks, filter.value, priorityFilter.value, dueRange);
    list.replaceChildren(...visible.map((task) => {
      const row = document.createElement('li');
      row.dataset.testid = 'task-row';
      const title = document.createElement('span');
      title.textContent = task.title;
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = task.completed;
      checkbox.disabled = project.archived;
      checkbox.setAttribute('aria-label', `Complete ${task.title}`);
      checkbox.addEventListener('change', async () => {
        checkbox.disabled = true;
        showAlert('');
        try {
          const saved = await api(`${tasksPath}/${task.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completed: checkbox.checked }),
          });
          Object.assign(task, saved);
          renderTasks();
        } catch (error) {
          checkbox.checked = task.completed;
          showAlert(error.message);
        } finally {
          checkbox.disabled = false;
        }
      });
      const taskRenameForm = document.createElement('form');
      const taskRenameLabel = document.createElement('label');
      taskRenameLabel.htmlFor = `new-task-title-${task.id}`;
      taskRenameLabel.textContent = 'New task title';
      const taskRenameInput = document.createElement('input');
      taskRenameInput.id = taskRenameLabel.htmlFor;
      taskRenameInput.type = 'text';
      taskRenameInput.autocomplete = 'off';
      taskRenameInput.disabled = project.archived;
      const taskRenameButton = document.createElement('button');
      taskRenameButton.type = 'submit';
      taskRenameButton.textContent = 'Rename task';
      taskRenameButton.disabled = project.archived;
      const taskRenameControls = document.createElement('div');
      taskRenameControls.className = 'form-controls';
      taskRenameControls.append(taskRenameInput, taskRenameButton);
      taskRenameForm.append(taskRenameLabel, taskRenameControls);
      taskRenameForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (taskRenameButton.disabled) return;
        const newTitle = taskRenameInput.value.trim();
        if (!newTitle) return showAlert('Task title is required');
        taskRenameButton.disabled = true;
        showAlert('');
        try {
          const saved = await api(`${tasksPath}/${task.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: newTitle }),
          });
          Object.assign(task, saved);
          title.textContent = task.title;
          checkbox.setAttribute('aria-label', `Complete ${task.title}`);
          taskRenameInput.value = '';
          taskRenameInput.focus();
        } catch (error) {
          showAlert(error.message);
        } finally {
          taskRenameButton.disabled = project.archived;
        }
      });
      const priorityLabel = document.createElement('label');
      priorityLabel.htmlFor = `task-priority-${task.id}`;
      priorityLabel.textContent = 'Task priority';
      const prioritySelect = document.createElement('select');
      prioritySelect.id = priorityLabel.htmlFor;
      for (const priority of ['Low', 'Normal', 'High']) {
        const option = document.createElement('option');
        option.value = priority;
        option.textContent = priority;
        prioritySelect.append(option);
      }
      prioritySelect.value = task.priority;
      prioritySelect.disabled = project.archived;
      prioritySelect.addEventListener('change', async () => {
        prioritySelect.disabled = true;
        showAlert('');
        try {
          const saved = await api(`${tasksPath}/${task.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ priority: prioritySelect.value }),
          });
          Object.assign(task, saved);
          renderTasks();
        } catch (error) {
          showAlert(error.message);
        } finally {
          prioritySelect.value = task.priority;
          prioritySelect.disabled = project.archived;
        }
      });
      const dueDateForm = document.createElement('form');
      const dueDateLabel = document.createElement('label');
      dueDateLabel.htmlFor = `task-due-date-${task.id}`;
      dueDateLabel.textContent = 'Task due date';
      const dueDateInput = document.createElement('input');
      dueDateInput.id = dueDateLabel.htmlFor;
      dueDateInput.type = 'text';
      dueDateInput.autocomplete = 'off';
      dueDateInput.value = task.due_date;
      dueDateInput.disabled = project.archived;
      const dueDateButton = document.createElement('button');
      dueDateButton.type = 'submit';
      dueDateButton.textContent = 'Save due date';
      dueDateButton.disabled = project.archived;
      const dueDateControls = document.createElement('div');
      dueDateControls.className = 'form-controls';
      dueDateControls.append(dueDateInput, dueDateButton);
      dueDateForm.append(dueDateLabel, dueDateControls);
      dueDateForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (dueDateButton.disabled) return;
        dueDateButton.disabled = true;
        showAlert('');
        try {
          const saved = await api(`${tasksPath}/${task.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ due_date: dueDateInput.value }),
          });
          Object.assign(task, saved);
          renderTasks();
        } catch (error) {
          showAlert(error.message);
        } finally {
          dueDateButton.disabled = project.archived;
        }
      });
      const moveForm = document.createElement('form');
      const destinationLabel = document.createElement('label');
      destinationLabel.htmlFor = `destination-project-${task.id}`;
      destinationLabel.textContent = 'Destination project';
      const destinationSelect = document.createElement('select');
      destinationSelect.id = destinationLabel.htmlFor;
      for (const destination of destinations) {
        const option = document.createElement('option');
        option.value = destination.id;
        option.textContent = destination.name;
        destinationSelect.append(option);
      }
      const moveButton = document.createElement('button');
      moveButton.type = 'submit';
      moveButton.textContent = 'Move task';
      destinationSelect.disabled = moveButton.disabled = project.archived || destinations.length === 0;
      moveForm.append(destinationLabel, destinationSelect, moveButton);
      moveForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (moveButton.disabled) return;
        destinationSelect.disabled = moveButton.disabled = true;
        showAlert('');
        try {
          await api(`${tasksPath}/${task.id}/move`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ destination_project_id: Number(destinationSelect.value) }),
          });
          tasks = tasks.filter((candidate) => candidate.id !== task.id);
          renderTasks();
        } catch (error) {
          showAlert(error.message);
        } finally {
          destinationSelect.disabled = moveButton.disabled = project.archived || destinations.length === 0;
        }
      });
      row.append(title, checkbox, taskRenameForm, priorityLabel, prioritySelect, dueDateForm, moveForm);
      return row;
    }));
  }

  filter.addEventListener('change', renderTasks);
  priorityFilter.addEventListener('change', renderTasks);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (button.disabled) return;
    const title = input.value.trim();
    if (!title) return showAlert('Task title is required');
    button.disabled = true;
    showAlert('');
    try {
      const task = await api(tasksPath, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title }),
      });
      tasks.push(task);
      renderTasks();
      input.value = '';
      input.focus();
    } catch (error) {
      showAlert(error.message);
    } finally {
      button.disabled = false;
    }
  });
  tasks = await api(tasksPath);
  renderTasks();
  button.disabled = project.archived;
}

try {
  const match = location.pathname.match(/^\/projects\/([1-9]\d*)$/);
  if (match) await showProject(match[1]);
  else await showProjects();
} catch (error) {
  showAlert(error.message);
} finally {
  app.setAttribute('aria-busy', 'false');
}
