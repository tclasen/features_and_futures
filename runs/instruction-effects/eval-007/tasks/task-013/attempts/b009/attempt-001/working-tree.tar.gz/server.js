import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const databasePath = resolve(process.env.DB_PATH || 'data/workboard.sqlite');
mkdirSync(dirname(databasePath), { recursive: true });
const database = new DatabaseSync(databasePath);
database.exec(`
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id),
    title TEXT NOT NULL,
    completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1))
  );
`);
if (!database.prepare('PRAGMA table_info(projects)').all().some(column => column.name === 'archived')) {
  database.exec('ALTER TABLE projects ADD COLUMN archived INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1))');
}
if (!database.prepare('PRAGMA table_info(tasks)').all().some(column => column.name === 'priority')) {
  database.exec("ALTER TABLE tasks ADD COLUMN priority TEXT NOT NULL DEFAULT 'Normal' CHECK (priority IN ('Low', 'Normal', 'High'))");
}
if (!database.prepare('PRAGMA table_info(projects)').all().some(column => column.name === 'default_task_priority')) {
  database.exec("ALTER TABLE projects ADD COLUMN default_task_priority TEXT NOT NULL DEFAULT 'Normal' CHECK (default_task_priority IN ('Low', 'Normal', 'High'))");
}
if (!database.prepare('PRAGMA table_info(tasks)').all().some(column => column.name === 'due_date')) {
  database.exec("ALTER TABLE tasks ADD COLUMN due_date TEXT NOT NULL DEFAULT ''");
}
if (!database.prepare('PRAGMA table_info(tasks)').all().some(column => column.name === 'position')) {
  database.exec('ALTER TABLE tasks ADD COLUMN position INTEGER NOT NULL DEFAULT 0; UPDATE tasks SET position = id');
}
database.exec(`
  BEGIN;
  CREATE TABLE IF NOT EXISTS task_positions (
    task_id INTEGER NOT NULL REFERENCES tasks(id),
    project_id INTEGER NOT NULL REFERENCES projects(id),
    position INTEGER NOT NULL,
    PRIMARY KEY (task_id, project_id)
  );
  CREATE INDEX IF NOT EXISTS task_positions_project ON task_positions(project_id, position);
  INSERT OR IGNORE INTO task_positions (task_id, project_id, position)
    SELECT id, project_id, position FROM tasks;
  COMMIT;
`);
const taskPriorities = ['Low', 'Normal', 'High'];
const listProjects = database.prepare(`
  SELECT projects.id, projects.name, projects.archived,
    COUNT(tasks.id) AS total_count, COALESCE(SUM(tasks.completed), 0) AS completed_count
  FROM projects LEFT JOIN tasks ON tasks.project_id = projects.id
  WHERE projects.archived = ?
  GROUP BY projects.id ORDER BY projects.id
`);
const findProject = database.prepare('SELECT id, name, archived, default_task_priority FROM projects WHERE id = ?');
const createProject = database.prepare('INSERT INTO projects (name) VALUES (?)');
const renameProject = database.prepare('UPDATE projects SET name = ? WHERE id = ?');
const updateProjectArchive = database.prepare('UPDATE projects SET archived = ? WHERE id = ?');
const updateProjectDefaultPriority = database.prepare('UPDATE projects SET default_task_priority = ? WHERE id = ?');
const listTasks = database.prepare('SELECT id, title, completed, priority, due_date FROM tasks WHERE project_id = ? ORDER BY position, id');
const listDestinations = database.prepare('SELECT id, name FROM projects WHERE archived = 0 AND id != ? ORDER BY id');
const createTask = database.prepare(`
  INSERT INTO tasks (project_id, title, priority, position)
  VALUES (?, ?, ?, (SELECT COALESCE(MAX(position), 0) + 1 FROM task_positions WHERE project_id = ?))
`);
const rememberCreatedTask = database.prepare(`
  INSERT INTO task_positions (task_id, project_id, position)
    SELECT id, project_id, position FROM tasks WHERE id = ?
`);
const findTask = database.prepare('SELECT id FROM tasks WHERE id = ? AND project_id = ?');
const rememberDestinationPosition = database.prepare(`
  INSERT OR IGNORE INTO task_positions (task_id, project_id, position)
  VALUES (?, ?, (SELECT COALESCE(MAX(position), 0) + 1 FROM task_positions WHERE project_id = ?))
`);
const moveTask = database.prepare(`
  UPDATE tasks SET project_id = ?,
    position = (SELECT position FROM task_positions WHERE task_id = ? AND project_id = ?)
  WHERE id = ? AND project_id = ?
`);
const updateTask = database.prepare('UPDATE tasks SET completed = ? WHERE id = ? AND project_id = ?');
const renameTask = database.prepare('UPDATE tasks SET title = ? WHERE id = ? AND project_id = ?');
const updateTaskPriority = database.prepare('UPDATE tasks SET priority = ? WHERE id = ? AND project_id = ?');
const updateTaskDueDate = database.prepare('UPDATE tasks SET due_date = ? WHERE id = ? AND project_id = ?');

function transaction(action) {
  database.exec('BEGIN');
  try {
    const result = action();
    database.exec('COMMIT');
    return result;
  } catch (error) {
    database.exec('ROLLBACK');
    throw error;
  }
}

function validDueDate(value) {
  if (!value) return true;
  if (!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  if (year < 1 || month < 1 || month > 12) return false;
  const leapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day >= 1 && day <= daysInMonth[month - 1];
}

function taskFilter(value) {
  return ['All', 'Open', 'Completed'].includes(value) ? value : 'All';
}

function priorityFilter(value) {
  return taskPriorities.includes(value) ? value : 'All';
}

function dueRange(params, fromKey = 'dueFrom', throughKey = 'dueThrough') {
  const from = (params.get(fromKey) || '').trim();
  const through = (params.get(throughKey) || '').trim();
  if (!validDueDate(from) || !validDueDate(through)) {
    return { from: '', through: '', error: 'Due range must use valid YYYY-MM-DD dates' };
  }
  if (from && through && from > through) {
    return { from: '', through: '', error: 'Due from must not be after Due through' };
  }
  return { from, through };
}

function searchQuery(params) {
  return (params.get('search') || '').trim();
}

function matchesSearch(value, query) {
  const foldAscii = text => text.replace(/[A-Z]/g, letter => letter.toLowerCase());
  return foldAscii(value).includes(foldAscii(query));
}

function searchField(query) {
  return `<input type="hidden" name="search" value="${escapeHtml(query)}">`;
}

function taskViewFields(range, query = '') {
  return `${searchField(query)}<input type="hidden" name="dueFrom" value="${range.from}">
    <input type="hidden" name="dueThrough" value="${range.through}">`;
}

function projectPath(projectId, filter, priority, range, query = '') {
  return `/projects/${projectId}?filter=${filter}${priority === 'All' ? '' : `&priorityFilter=${priority}`}` +
    (range.from ? `&dueFrom=${range.from}` : '') + (range.through ? `&dueThrough=${range.through}` : '') +
    (query ? `&search=${encodeURIComponent(query)}` : '');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
}

function page(title, content) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)} · Workboard</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; background: #f5f7fb; color: #1b2840; font: 16px/1.5 system-ui, sans-serif; }
    main { max-width: 760px; margin: 64px auto; padding: 32px; background: white; border: 1px solid #dce2ed; border-radius: 12px; }
    h1 { margin: 0 0 28px; font-size: 32px; overflow-wrap: anywhere; }
    label { display: block; margin-bottom: 8px; font-weight: 600; }
    input { width: 100%; padding: 12px; border: 1px solid #8592aa; border-radius: 6px; font: inherit; }
    select { padding: 10px; font: inherit; }
    .task-filter { margin-top: 28px; }
    .task-row { padding: 18px 0; border-top: 1px solid #dce2ed; overflow-wrap: anywhere; }
    .task-completion { display: flex; align-items: center; gap: 12px; margin: 0; }
    .task-row input[type="checkbox"] { width: 20px; height: 20px; flex-shrink: 0; }
    .task-row .create { margin-top: 16px; }
    button { padding: 10px 16px; border: 1px solid #244fae; border-radius: 6px; background: #244fae; color: white; font: inherit; cursor: pointer; }
    button:hover { background: #193c89; }
    button:disabled { background: #68758b; border-color: #68758b; cursor: default; }
    :focus-visible { outline: 3px solid #da9600; outline-offset: 3px; }
    .create button { margin-top: 14px; }
    .projects { margin-top: 32px; }
    .project-row { display: flex; flex-wrap: wrap; align-items: center; gap: 20px; padding: 18px 0; border-top: 1px solid #dce2ed; }
    .project-details { flex: 1; min-width: 0; }
    .project-summary { color: #58667d; font-size: 14px; }
    .project-row span { overflow-wrap: anywhere; min-width: 0; }
    .project-row form { flex-shrink: 0; }
    [role="alert"] { color: #a51e2c; margin: 0 0 16px; }
    .empty { color: #58667d; }
    @media (max-width: 600px) { main { margin: 20px 12px; padding: 24px; } }
  </style>
</head>
<body><main>${content}</main></body>
</html>`;
}

function projectFilter(value) {
  return value === 'Archived' ? 'Archived' : 'Active';
}

function projectsPage(error = '', filter = 'Active', query = '') {
  const projects = listProjects.all(filter === 'Archived' ? 1 : 0)
    .filter(project => matchesSearch(project.name, query));
  return page('Projects', `
    <h1>Workboard</h1>
    ${error ? `<p role="alert">${escapeHtml(error)}</p>` : ''}
    <form class="create" method="post" action="/projects">
      <input type="hidden" name="filter" value="${filter}">
      ${searchField(query)}
      <label for="project-name">Project name</label>
      <input id="project-name" name="name" type="text" autocomplete="off">
      <button type="submit">Create project</button>
    </form>
    <form class="task-filter" method="get" action="/">
      ${searchField(query)}
      <label for="project-filter">Project filter</label>
      <select id="project-filter" name="filter" onchange="this.form.requestSubmit()">
        ${['Active', 'Archived'].map(option => `<option${filter === option ? ' selected' : ''}>${option}</option>`).join('')}
      </select>
    </form>
    <form class="task-filter" method="get" action="/">
      <input type="hidden" name="filter" value="${filter}">
      <label for="project-search">Project search</label>
      <input id="project-search" name="search" type="text" value="${escapeHtml(query)}" autocomplete="off">
      <button type="submit">Search projects</button>
    </form>
    <section class="projects" aria-label="Projects">
      ${projects.length ? projects.map(project => `
        <div class="project-row" data-testid="project-row">
          <div class="project-details">
            <span>${escapeHtml(project.name)}</span>
            <div class="project-summary" data-testid="project-summary">${project.completed_count}/${project.total_count} completed</div>
          </div>
          <form method="get" action="/projects/${project.id}">
            <button type="submit">Open project</button>
          </form>
          <form method="post" action="/projects/${project.id}/${project.archived ? 'restore' : 'archive'}">
            ${searchField(query)}
            <button type="submit">${project.archived ? 'Restore project' : 'Archive project'}</button>
          </form>
        </div>`).join('') : '<p class="empty">No projects yet.</p>'}
    </section>`);
}

function projectPage(project, filter = 'All', error = '', priority = 'All', range = { from: '', through: '' }, query = '') {
  const destinations = listDestinations.all(project.id);
  const moveDisabled = project.archived || !destinations.length;
  const tasks = listTasks.all(project.id).filter(task =>
    matchesSearch(task.title, query) &&
    (filter === 'All' || Boolean(task.completed) === (filter === 'Completed')) &&
    (priority === 'All' || task.priority === priority) &&
    ((!range.from && !range.through) || (task.due_date &&
      (!range.from || task.due_date >= range.from) &&
      (!range.through || task.due_date <= range.through))));
  return page(project.name, `
    <h1>${escapeHtml(project.name)}</h1>
    ${project.archived ? '<p>Archived project</p>' : ''}
    <form method="get" action="/"><button type="submit">Projects</button></form>
    ${error ? `<p role="alert">${escapeHtml(error)}</p>` : ''}
    <form class="create" method="post" action="/projects/${project.id}/rename">
      <input type="hidden" name="filter" value="${filter}">
      <input type="hidden" name="priorityFilter" value="${priority}">
      ${taskViewFields(range, query)}
      <label for="new-project-name">New project name</label>
      <input id="new-project-name" name="name" type="text" autocomplete="off"${project.archived ? ' disabled' : ''}>
      <button type="submit"${project.archived ? ' disabled' : ''}>Rename project</button>
    </form>
    <form class="create" method="post" action="/projects/${project.id}/default-task-priority">
      <input type="hidden" name="filter" value="${filter}">
      <input type="hidden" name="priorityFilter" value="${priority}">
      ${taskViewFields(range, query)}
      <label for="default-task-priority">Default task priority</label>
      <select id="default-task-priority" name="priority"${project.archived ? ' disabled' : ''} onchange="this.form.requestSubmit()">
        ${taskPriorities.map(option => `<option${project.default_task_priority === option ? ' selected' : ''}>${option}</option>`).join('')}
      </select>
    </form>
    <form class="create" method="post" action="/projects/${project.id}/tasks">
      <input type="hidden" name="filter" value="${filter}">
      <input type="hidden" name="priorityFilter" value="${priority}">
      ${taskViewFields(range, query)}
      <label for="task-title">Task title</label>
      <input id="task-title" name="title" type="text" autocomplete="off">
      <button type="submit"${project.archived ? ' disabled' : ''}>Create task</button>
    </form>
    <form class="task-filter" method="get" action="/projects/${project.id}">
      ${taskViewFields(range, query)}
      <label for="task-filter">Task filter</label>
      <select id="task-filter" name="filter" onchange="this.form.requestSubmit()">
        ${['All', 'Open', 'Completed'].map(option => `<option${filter === option ? ' selected' : ''}>${option}</option>`).join('')}
      </select>
      <label for="priority-filter">Priority filter</label>
      <select id="priority-filter" name="priorityFilter" onchange="this.form.requestSubmit()">
        ${['All', ...taskPriorities].map(option => `<option${priority === option ? ' selected' : ''}>${option}</option>`).join('')}
      </select>
    </form>
    <form class="task-filter" method="post" action="/projects/${project.id}/due-range">
      <input type="hidden" name="filter" value="${filter}">
      <input type="hidden" name="priorityFilter" value="${priority}">
      ${searchField(query)}
      <input type="hidden" name="appliedDueFrom" value="${range.from}">
      <input type="hidden" name="appliedDueThrough" value="${range.through}">
      <label for="due-from">Due from</label>
      <input id="due-from" name="dueFrom" type="text" value="${range.from}" autocomplete="off">
      <label for="due-through">Due through</label>
      <input id="due-through" name="dueThrough" type="text" value="${range.through}" autocomplete="off">
      <button type="submit">Apply due range</button>
    </form>
    <form class="task-filter" method="get" action="/projects/${project.id}">
      <input type="hidden" name="filter" value="${filter}">
      <input type="hidden" name="priorityFilter" value="${priority}">
      <input type="hidden" name="dueFrom" value="${range.from}">
      <input type="hidden" name="dueThrough" value="${range.through}">
      <label for="task-search">Task search</label>
      <input id="task-search" name="search" type="text" value="${escapeHtml(query)}" autocomplete="off">
      <button type="submit">Search tasks</button>
    </form>
    <section aria-label="Tasks">
      ${tasks.length ? tasks.map(task => `
        <div class="task-row" data-testid="task-row">
          <form method="post" action="/projects/${project.id}/tasks/${task.id}">
            <input type="hidden" name="filter" value="${filter}">
            <input type="hidden" name="priorityFilter" value="${priority}">
            ${taskViewFields(range, query)}
            <label class="task-completion"><input type="checkbox" name="completed" value="1" aria-label="Complete ${escapeHtml(task.title)}"${task.completed ? ' checked' : ''}${project.archived ? ' disabled' : ''} onchange="this.form.requestSubmit()"><span>${escapeHtml(task.title)}</span></label>
          </form>
          <form class="create" method="post" action="/projects/${project.id}/tasks/${task.id}/rename">
            <input type="hidden" name="filter" value="${filter}">
            <input type="hidden" name="priorityFilter" value="${priority}">
            ${taskViewFields(range, query)}
            <label for="new-task-title-${task.id}">New task title</label>
            <input id="new-task-title-${task.id}" name="title" type="text" autocomplete="off"${project.archived ? ' disabled' : ''}>
            <button type="submit"${project.archived ? ' disabled' : ''}>Rename task</button>
          </form>
          <form class="create" method="post" action="/projects/${project.id}/tasks/${task.id}/priority">
            <input type="hidden" name="filter" value="${filter}">
            <input type="hidden" name="priorityFilter" value="${priority}">
            ${taskViewFields(range, query)}
            <label for="task-priority-${task.id}">Task priority</label>
            <select id="task-priority-${task.id}" name="priority"${project.archived ? ' disabled' : ''} onchange="this.form.requestSubmit()">
              ${taskPriorities.map(priority => `<option${task.priority === priority ? ' selected' : ''}>${priority}</option>`).join('')}
            </select>
          </form>
          <form class="create" method="post" action="/projects/${project.id}/tasks/${task.id}/due-date">
            <input type="hidden" name="filter" value="${filter}">
            <input type="hidden" name="priorityFilter" value="${priority}">
            ${taskViewFields(range, query)}
            <label for="task-due-date-${task.id}">Task due date</label>
            <input id="task-due-date-${task.id}" name="dueDate" type="text" value="${escapeHtml(task.due_date)}" autocomplete="off"${project.archived ? ' disabled' : ''}>
            <button type="submit"${project.archived ? ' disabled' : ''}>Save due date</button>
          </form>
          <form class="create" method="post" action="/projects/${project.id}/tasks/${task.id}/move">
            <input type="hidden" name="filter" value="${filter}">
            <input type="hidden" name="priorityFilter" value="${priority}">
            ${taskViewFields(range, query)}
            <label for="destination-project-${task.id}">Destination project</label>
            <select id="destination-project-${task.id}" name="destinationProject"${moveDisabled ? ' disabled' : ''}>
              ${destinations.map(destination => `<option value="${destination.id}">${escapeHtml(destination.name)}</option>`).join('')}
            </select>
            <button type="submit"${moveDisabled ? ' disabled' : ''}>Move task</button>
          </form>
        </div>`).join('') : '<p class="empty">No tasks to display.</p>'}
    </section>`);
}

function html(response, status, body) {
  response.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8' });
  response.end(body);
}

async function readForm(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 64 * 1024) {
      const error = new Error('Request body is too large');
      error.status = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  return new URLSearchParams(Buffer.concat(chunks).toString('utf8'));
}

const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://localhost');
    if (request.method === 'GET' && url.pathname === '/health') {
      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({ status: 'ok' }));
    } else if (request.method === 'GET' && url.pathname === '/') {
      html(response, 200, projectsPage('', projectFilter(url.searchParams.get('filter')), searchQuery(url.searchParams)));
    } else if (request.method === 'POST' && url.pathname === '/projects') {
      const form = await readForm(request);
      const name = (form.get('name') || '').trim();
      if (!name) {
        html(response, 400, projectsPage('Project name is required', projectFilter(form.get('filter')), searchQuery(form)));
        return;
      }
      createProject.run(name);
      response.writeHead(303, { Location: '/' });
      response.end();
    } else if (request.method === 'POST' && /^\/projects\/[1-9]\d*\/due-range$/.test(url.pathname)) {
      const project = findProject.get(url.pathname.split('/')[2]);
      if (!project) {
        html(response, 404, page('Not found', '<h1>Project not found</h1>'));
        return;
      }
      const form = await readForm(request);
      const filter = taskFilter(form.get('filter'));
      const priority = priorityFilter(form.get('priorityFilter'));
      const range = dueRange(form);
      const query = searchQuery(form);
      if (range.error) {
        const previousRange = dueRange(form, 'appliedDueFrom', 'appliedDueThrough');
        html(response, 400, projectPage(project, filter, range.error, priority, previousRange, query));
        return;
      }
      response.writeHead(303, { Location: projectPath(project.id, filter, priority, range, query) });
      response.end();
    } else if (request.method === 'POST' && /^\/projects\/[1-9]\d*\/(rename|default-task-priority)$/.test(url.pathname)) {
      const project = findProject.get(url.pathname.split('/')[2]);
      if (!project) {
        html(response, 404, page('Not found', '<h1>Project not found</h1>'));
        return;
      }
      const form = await readForm(request);
      const filter = taskFilter(form.get('filter'));
      const priority = priorityFilter(form.get('priorityFilter'));
      const range = dueRange(form);
      const query = searchQuery(form);
      if (project.archived) {
        html(response, 403, projectPage(project, filter, 'Archived project cannot be changed', priority, range, query));
        return;
      }
      if (url.pathname.endsWith('/default-task-priority')) {
        const newPriority = form.get('priority');
        if (!taskPriorities.includes(newPriority)) {
          html(response, 400, projectPage(project, filter, 'Invalid task priority', priority, range, query));
          return;
        }
        updateProjectDefaultPriority.run(newPriority, project.id);
      } else {
        const name = (form.get('name') || '').trim();
        if (!name) {
          html(response, 400, projectPage(project, filter, 'Project name is required', priority, range, query));
          return;
        }
        renameProject.run(name, project.id);
      }
      response.writeHead(303, { Location: projectPath(project.id, filter, priority, range, query) });
      response.end();
    } else if (request.method === 'POST' && /^\/projects\/[1-9]\d*\/(archive|restore)$/.test(url.pathname)) {
      const [, , projectId, action] = url.pathname.split('/');
      const project = findProject.get(projectId);
      if (!project) {
        html(response, 404, page('Not found', '<h1>Project not found</h1>'));
        return;
      }
      const query = searchQuery(await readForm(request));
      updateProjectArchive.run(action === 'archive' ? 1 : 0, project.id);
      const returnPath = action === 'archive' ? '/' : '/?filter=Archived';
      response.writeHead(303, { Location: returnPath + (query ? `${returnPath.includes('?') ? '&' : '?'}search=${encodeURIComponent(query)}` : '') });
      response.end();
    } else if (request.method === 'GET' && /^\/projects\/[1-9]\d*$/.test(url.pathname)) {
      const project = findProject.get(url.pathname.split('/')[2]);
      if (!project) {
        html(response, 404, page('Not found', '<h1>Project not found</h1><form action="/"><button>Projects</button></form>'));
        return;
      }
      const range = dueRange(url.searchParams);
      html(response, 200, projectPage(project, taskFilter(url.searchParams.get('filter')), range.error || '', priorityFilter(url.searchParams.get('priorityFilter')), range, searchQuery(url.searchParams)));
    } else if (request.method === 'POST' && /^\/projects\/[1-9]\d*\/tasks(?:\/[1-9]\d*(?:\/(?:rename|priority|due-date|move))?)?$/.test(url.pathname)) {
      const [, , projectId, , taskId, action] = url.pathname.split('/');
      const project = findProject.get(projectId);
      if (!project) {
        html(response, 404, page('Not found', '<h1>Project not found</h1>'));
        return;
      }
      const form = await readForm(request);
      const filter = taskFilter(form.get('filter'));
      const priority = priorityFilter(form.get('priorityFilter'));
      const range = dueRange(form);
      const query = searchQuery(form);
      if (project.archived) {
        html(response, 403, projectPage(project, filter, 'Archived project cannot be changed', priority, range, query));
        return;
      }
      if (taskId) {
        let result;
        if (action === 'move') {
          const destinationId = form.get('destinationProject') || '';
          const destination = /^[1-9]\d*$/.test(destinationId) ? findProject.get(destinationId) : null;
          if (!destination || destination.archived || destination.id === project.id) {
            html(response, 400, projectPage(project, filter, 'Choose an active destination project', priority, range, query));
            return;
          }
          result = transaction(() => {
            if (!findTask.get(taskId, project.id)) return { changes: 0 };
            rememberDestinationPosition.run(taskId, destination.id, destination.id);
            return moveTask.run(destination.id, taskId, destination.id, taskId, project.id);
          });
        } else if (action === 'rename') {
          const title = (form.get('title') || '').trim();
          if (!title) {
            html(response, 400, projectPage(project, filter, 'Task title is required', priority, range, query));
            return;
          }
          result = renameTask.run(title, taskId, project.id);
        } else if (action === 'priority') {
          const newPriority = form.get('priority');
          if (!taskPriorities.includes(newPriority)) {
            html(response, 400, projectPage(project, filter, 'Invalid task priority', priority, range, query));
            return;
          }
          result = updateTaskPriority.run(newPriority, taskId, project.id);
        } else if (action === 'due-date') {
          const dueDate = (form.get('dueDate') || '').trim();
          if (!validDueDate(dueDate)) {
            html(response, 400, projectPage(project, filter, 'Due date must be a valid YYYY-MM-DD date', priority, range, query));
            return;
          }
          result = updateTaskDueDate.run(dueDate, taskId, project.id);
        } else {
          result = updateTask.run(form.get('completed') === '1' ? 1 : 0, taskId, project.id);
        }
        if (!result.changes) {
          html(response, 404, page('Not found', '<h1>Task not found</h1>'));
          return;
        }
      } else {
        const title = (form.get('title') || '').trim();
        if (!title) {
          html(response, 400, projectPage(project, filter, 'Task title is required', priority, range, query));
          return;
        }
        transaction(() => {
          const result = createTask.run(project.id, title, project.default_task_priority, project.id);
          rememberCreatedTask.run(result.lastInsertRowid);
        });
      }
      response.writeHead(303, { Location: projectPath(project.id, filter, priority, range, query) });
      response.end();
    } else {
      html(response, 404, page('Not found', '<h1>Page not found</h1>'));
    }
  } catch (error) {
    console.error(error);
    html(response, error.status || 500, page('Error', '<h1>Unable to complete request</h1>'));
  }
});

server.listen(Number(process.env.PORT || 8080), '0.0.0.0', () => {
  console.log(`Workboard listening on port ${server.address().port}`);
});

function shutdown() {
  server.close(() => {
    database.close();
    process.exit(0);
  });
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
