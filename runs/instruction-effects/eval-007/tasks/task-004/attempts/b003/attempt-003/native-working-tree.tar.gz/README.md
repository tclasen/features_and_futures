# Workboard

Requires Node.js 22.22.1; no dependencies or install step.

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
```

Open http://localhost:8080. Defaults are port 8080 and `./data/workboard.sqlite`.
The server binds to `0.0.0.0`. `GET /health` returns `{"status":"ok"}`.

```sh
npm test
```

Project pages support task creation, completion checkboxes, and All/Open/Completed filtering. The project list provides Active/Archived filtering, archive/restore controls, and completion summaries. Active project pages also support renaming without changing project identity, order, or tasks. Archived project pages are read-only, including rename controls. Projects, names, tasks, and archive state are saved in SQLite; existing databases are migrated automatically.

Tests exercise health, project/task validation, creation order, project isolation, completion changes, detail routes, schema migration, archive/restore, read-only enforcement, summaries, rename validation and identity preservation, and SQLite persistence across process restarts using a temporary database.
