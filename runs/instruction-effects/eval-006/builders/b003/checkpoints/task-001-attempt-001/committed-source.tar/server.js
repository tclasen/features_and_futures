import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

const dbPath = process.env.DB_PATH || 'data/workboard.sqlite';
mkdirSync(dirname(dbPath), { recursive: true });
const db = new DatabaseSync(dbPath);
db.exec(`CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL
)`);
const listProjects = db.prepare('SELECT id, name FROM projects ORDER BY id ASC');
const getProject = db.prepare('SELECT id, name FROM projects WHERE id = ?');
const addProject = db.prepare('INSERT INTO projects (name) VALUES (?)');

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}

function page(title, content) {
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)} · Workboard</title>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; background: #f5f7fb; color: #17243a; font: 16px/1.5 system-ui, sans-serif; }
  main { max-width: 760px; margin: 64px auto; padding: 32px; background: white; border-radius: 12px; box-shadow: 0 4px 24px #17243a0d; }
  h1 { margin: 0 0 24px; overflow-wrap: anywhere; }
  label { display: block; margin-bottom: 8px; font-weight: 600; }
  .create { display: flex; flex-wrap: wrap; gap: 12px; }
  input { flex: 1; min-width: 180px; padding: 10px 12px; border: 1px solid #8794a9; border-radius: 6px; font: inherit; }
  button { padding: 10px 16px; border: 0; border-radius: 6px; background: #214fb0; color: white; font: inherit; cursor: pointer; }
  button:hover { background: #183d8c; }
  :focus-visible { outline: 3px solid #e19520; outline-offset: 3px; }
  ul { list-style: none; padding: 0; margin: 28px 0 0; }
  li { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 16px 0; border-top: 1px solid #e2e7ef; }
  li span { overflow-wrap: anywhere; min-width: 0; }
  li form { flex-shrink: 0; }
  [role=alert] { color: #9e2020; margin: 12px 0; }
  @media (max-width: 600px) { main { margin: 16px; padding: 24px; } }
</style></head><body><main>${content}</main></body></html>`;
}

function projectList(error = '', value = '') {
  const projects = listProjects.all();
  return page('Projects', `<h1>Workboard</h1>
<form method="post" action="/projects">
<label for="project-name">Project name</label>
<div class="create"><input id="project-name" name="name" value="${escapeHtml(value)}" type="text"><button type="submit">Create project</button></div>
${error ? `<p role="alert">${escapeHtml(error)}</p>` : ''}
</form>
${projects.length ? `<ul>${projects.map(project => `<li data-testid="project-row"><span>${escapeHtml(project.name)}</span><form method="get" action="/projects/${project.id}"><button type="submit">Open project</button></form></li>`).join('')}</ul>` : '<p>No projects yet.</p>'}`);
}

function sendHtml(res, status, html) {
  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(html);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (req.method === 'GET' && url.pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ status: 'ok' }));
    }
    if (req.method === 'GET' && url.pathname === '/') {
      return sendHtml(res, 200, projectList());
    }
    if (req.method === 'POST' && url.pathname === '/projects') {
      const chunks = [];
      let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 1024 * 1024) {
          return sendHtml(res, 413, page('Request too large', '<h1>Request too large</h1>'));
        }
        chunks.push(chunk);
      }
      const name = (new URLSearchParams(Buffer.concat(chunks).toString()).get('name') || '').trim();
      if (!name) return sendHtml(res, 400, projectList('Project name is required'));
      addProject.run(name);
      res.writeHead(303, { Location: '/' });
      return res.end();
    }
    const match = url.pathname.match(/^\/projects\/([1-9]\d*)$/);
    if (req.method === 'GET' && match) {
      const project = getProject.get(match[1]);
      if (project) return sendHtml(res, 200, page(project.name, `<h1>${escapeHtml(project.name)}</h1><form method="get" action="/"><button type="submit">Projects</button></form>`));
    }
    sendHtml(res, 404, page('Not found', '<h1>Not found</h1><a href="/">Projects</a>'));
  } catch (error) {
    console.error(error);
    if (!res.headersSent) sendHtml(res, 500, page('Server error', '<h1>Server error</h1>'));
    else res.end();
  }
});

server.listen(Number(process.env.PORT || 8080), '0.0.0.0', () => {
  console.log(`Workboard listening on port ${server.address().port}`);
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => { db.close(); process.exit(0); }));
}
