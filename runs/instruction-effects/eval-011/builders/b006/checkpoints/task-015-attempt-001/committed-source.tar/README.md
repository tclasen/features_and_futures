# Workboard

Requires Node.js 22.22.1. No application dependencies are needed.

```sh
npm start
```

The server listens on `0.0.0.0:8080` by default. Set `PORT` and `DB_PATH` to configure the port and persistent SQLite file:

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
```

Visit `/` to create and open projects. `GET /health` returns `{"status":"ok"}`.

Within a project, create tasks, check or uncheck completion, and use Task filter
to show All, Open, or Completed tasks. Projects, tasks, and completion persist in
the configured SQLite file across restarts.

Use Project filter to view Active or Archived projects. Archive and restore
projects from their rows; summaries count all completed and total tasks.
Archived project pages allow viewing and filtering tasks, with creation and
completion controls disabled. Existing databases are upgraded automatically.

On an active project page, use New project name and Rename project to change
its name while preserving its URL, creation order, tasks, and summary. Archived
projects must be restored before renaming.

Each task row provides New task title and Rename task. Renaming preserves task
order, project ownership, completion, and summary counts, and updates the
completion checkbox label. Archived projects must be restored before task
renaming is enabled.

Each task has a Task priority selector with Low, Normal, and High options.
Existing tasks retain their priorities; new tasks inherit their project's
default. Priorities persist independently of task titles and completion; archived projects disable priority changes until
restored.

Use Priority filter to show All, Low, Normal, or High priorities together with
Task filter. Tasks must match both filters and keep their creation order.
Completion and priority edits immediately refresh the matching rows while
preserving both filter selections. Both filters work in archived projects;
filtering leaves saved tasks and completion summaries unchanged.

Each project has a Default task priority selector with Low, Normal, and High
options, initially Normal. Changes apply only to subsequently created tasks in
that project and preserve both task filters. Defaults persist across restarts,
renaming, archival, and restoration; archived projects disable the selector.

Each task has an optional Task due date textbox and Save due date button. Dates
must be real Gregorian calendar dates in YYYY-MM-DD format, with years 0001
through 9999. Surrounding whitespace is trimmed, and an empty value clears the
date. Invalid values show an alert and leave the saved date unchanged. Dates
persist across restarts and renaming without changing task filters or other
task data. Archived projects disable both due-date controls until restored.

Run the integration and UI checks with `npm test`.

Use Due from and Due through, then Apply due range, to intersect an inclusive
calendar-date range with Task filter and Priority filter. Blank boundaries are
unbounded; any nonblank boundary excludes undated tasks. Both blank includes
all dates and undated tasks. Invalid dates or reversed boundaries show an alert
and preserve the previously applied range. Task edits immediately refresh the
matching rows while retaining all filters. Range controls also work in archived
projects. Reopening a project starts with empty range boundaries.

Use Destination project and Move task in a task row to move it to another
active project. Destinations use current project names in project creation
order. On its first arrival, the task appends after all positions established
in the destination. Returning to a previous project restores its remembered
position relative to that project's other tasks, even when several tasks
return in a different order. Positions persist separately per project across
restarts, project renaming, archival, and restoration, preserving current task
identity, title, completion, priority, and due date. The source page stays open
with all filters retained, and both project summaries reflect the move.
Archived projects cannot send or receive tasks. Move controls are disabled
when the source is archived or no eligible destination exists.

Use Project search and Search projects to match project names, together with
Project filter. Use Task search and Search tasks to match task titles, together
with completion, priority, and the applied due range. Searches trim surrounding
query whitespace, treat each run of ASCII spaces and horizontal tabs as one
space for matching, and ignore ASCII letter case. Stored names and titles keep
their original internal whitespace and case.
Blank queries match everything allowed by the other filters. Editing or moving
tasks retains the applied query and filters and immediately refreshes matching
rows. Search also works in archived projects without enabling task edits.
Opening either page starts with an empty search query; returning through
Projects resets project search. Searches leave saved data and summary counts
unchanged.

Every task row provides Task notes and Save notes. Notes are optional multiline
plain text: saving preserves spaces, line breaks, Unicode, and literal markup;
saving empty text clears them. Notes persist through restarts, renames, moves,
and return-order restoration. They do not participate in search or affect
filters or completion summaries. Archived projects show notes with editing
disabled; restoration enables editing again. Existing databases initialize
only the new notes field to empty while retaining prior task data.
