const listView = document.querySelector('#project-list');
const detailView = document.querySelector('#project-detail');
const alert = document.querySelector('#alert');
let activeProjectId = null;
let appliedDueRange = { from: '', through: '' };
const normalizeSearch = value => value.trim().replace(/[ \t]+/g, ' ').replace(/[A-Z]/g, character => character.toLowerCase());

async function loadProjects() {
  const response = await fetch('/api/projects');
  if (!response.ok) throw new Error('Could not load projects');
  const projects = await response.json();
  const filter = document.querySelector('#project-filter').value;
  const query = normalizeSearch(document.querySelector('#project-search').value.trim());
  const container = document.querySelector('#projects');
  container.replaceChildren();
  for (const project of projects.filter(item => item.archived === (filter === 'Archived') && normalizeSearch(item.name).includes(query))) {
    const row = document.createElement('div'); row.dataset.testid = 'project-row'; row.className = 'project-row';
    const name = document.createElement('span'); name.textContent = project.name;
    const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Open project';
    button.addEventListener('click', () => { location.href = `/projects/${project.id}`; });
    const summary = document.createElement('span'); summary.dataset.testid = 'project-summary'; summary.textContent = `${project.completed_count}/${project.total_count} completed`;
    row.append(name, summary, button);
    const stateButton = document.createElement('button'); stateButton.type = 'button'; stateButton.textContent = project.archived ? 'Restore project' : 'Archive project';
    stateButton.addEventListener('click', async () => { const action = project.archived ? 'restore' : 'archive'; const result = await fetch(`/api/projects/${project.id}/${action}`, { method: 'POST' }); if (result.ok) await loadProjects(); });
    row.append(stateButton); container.append(row);
  }
}

async function loadTasks() {
  const response = await fetch(`/api/projects/${activeProjectId}/tasks`);
  if (!response.ok) throw new Error('Could not load tasks');
  const tasks = await response.json();
  const projectsResponse = await fetch('/api/projects');
  const activeProjects = projectsResponse.ok ? (await projectsResponse.json()).filter(project => !project.archived && String(project.id) !== String(activeProjectId)) : [];
  const filter = document.querySelector('#task-filter').value;
  const priorityFilter = document.querySelector('#priority-filter').value;
  const { from, through } = appliedDueRange;
  const query = normalizeSearch(document.querySelector('#task-search').value.trim());
  const shown = tasks.filter(task => {
    const completionMatches = filter === 'Deleted' ? Boolean(task.deleted) : !task.deleted && (filter === 'All' || (filter === 'Completed') === task.completed);
    const priorityMatches = priorityFilter === 'All' || task.priority === priorityFilter;
    const dateMatches = !from && !through ? true : Boolean(task.due_date) && (!from || task.due_date >= from) && (!through || task.due_date <= through);
    return completionMatches && priorityMatches && dateMatches && normalizeSearch(task.title).includes(query);
  });
  const container = document.querySelector('#tasks'); container.replaceChildren();
  for (const task of shown) {
    const row = document.createElement('div'); row.dataset.testid = 'task-row'; row.className = 'project-row';
    const locked = Boolean(window.currentProjectArchived) || Boolean(task.deleted);
    const title = document.createElement('span'); title.textContent = task.title;
    const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = task.completed; checkbox.disabled = locked; checkbox.setAttribute('aria-label', `Complete ${task.title}`);
    checkbox.addEventListener('change', async () => {
      const result = await fetch(`/api/tasks/${task.id}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ completed: checkbox.checked }) });
      if (result.ok) await loadTasks(); else checkbox.checked = task.completed;
    });
    row.append(title, checkbox);
    const renameInput = document.createElement('input'); renameInput.type = 'text'; renameInput.value = task.title; renameInput.setAttribute('aria-label', 'New task title'); renameInput.disabled = locked;
    const renameButton = document.createElement('button'); renameButton.type = 'button'; renameButton.textContent = 'Rename task'; renameButton.disabled = locked;
    renameButton.addEventListener('click', async () => {
      const newTitle = renameInput.value.trim();
      const message = document.querySelector('#task-alert');
      if (!newTitle) { message.textContent = 'Task title is required'; message.hidden = false; return; }
      const result = await fetch(`/api/tasks/${task.id}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ title: newTitle }) });
      if (!result.ok) { message.textContent = result.status === 400 ? 'Task title is required' : 'Unable to rename task'; message.hidden = false; return; }
      message.hidden = true; await loadTasks();
    });
    row.append(renameInput, renameButton);
    const priority = document.createElement('select'); priority.setAttribute('aria-label', 'Task priority'); priority.disabled = locked;
    for (const value of ['Low', 'Normal', 'High']) { const option = document.createElement('option'); option.value = value; option.textContent = value; priority.append(option); }
    priority.value = task.priority || 'Normal';
    priority.addEventListener('change', async () => {
      const result = await fetch(`/api/tasks/${task.id}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ priority: priority.value }) });
      if (!result.ok) priority.value = task.priority || 'Normal';
      else await loadTasks();
    });
    row.append(priority);
    const dueDate = document.createElement('input'); dueDate.type = 'text'; dueDate.value = task.due_date || ''; dueDate.setAttribute('aria-label', 'Task due date'); dueDate.placeholder = 'YYYY-MM-DD'; dueDate.disabled = locked;
    const saveDate = document.createElement('button'); saveDate.type = 'button'; saveDate.textContent = 'Save due date'; saveDate.disabled = locked;
    saveDate.addEventListener('click', async () => {
      const message = document.querySelector('#task-alert');
      const result = await fetch(`/api/tasks/${task.id}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ due_date: dueDate.value }) });
      if (!result.ok) { message.textContent = result.status === 400 ? 'Due date must be a valid YYYY-MM-DD date' : 'Unable to save due date'; message.hidden = false; return; }
      message.hidden = true; await loadTasks();
    });
    row.append(dueDate, saveDate);
    const destination = document.createElement('select'); destination.setAttribute('aria-label', 'Destination project');
    for (const project of activeProjects) { const option = document.createElement('option'); option.value = project.id; option.textContent = project.name; destination.append(option); }
    const moveButton = document.createElement('button'); moveButton.type = 'button'; moveButton.textContent = 'Move task';
    destination.disabled = moveButton.disabled = locked || activeProjects.length === 0;
    moveButton.addEventListener('click', async () => {
      const result = await fetch(`/api/tasks/${task.id}/move`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ destination_project_id: destination.value }) });
      if (result.ok) await loadTasks();
    });
    row.append(destination, moveButton);
    const notes = document.createElement('textarea'); notes.setAttribute('aria-label', 'Task notes'); notes.value = task.notes || ''; notes.disabled = locked;
    const saveNotes = document.createElement('button'); saveNotes.type = 'button'; saveNotes.textContent = 'Save notes'; saveNotes.disabled = locked;
    saveNotes.addEventListener('click', async () => {
      const message = document.querySelector('#task-alert');
      const result = await fetch(`/api/tasks/${task.id}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ notes: notes.value }) });
      if (!result.ok) { message.textContent = 'Unable to save notes'; message.hidden = false; return; }
      message.hidden = true; await loadTasks();
    });
    row.append(notes, saveNotes);
    const stateButton = document.createElement('button'); stateButton.type = 'button'; stateButton.textContent = task.deleted ? 'Restore task' : 'Delete task';
    stateButton.disabled = Boolean(window.currentProjectArchived);
    stateButton.addEventListener('click', async () => { const action = task.deleted ? 'restore' : 'delete'; const result = await fetch(`/api/tasks/${task.id}/${action}`, { method: 'POST' }); if (result.ok) await loadTasks(); });
    row.append(stateButton); container.append(row);
  }
}

async function showPage() {
  const match = location.pathname.match(/^\/projects\/(\d+)\/?$/);
  if (!match) { detailView.hidden = true; listView.hidden = false; await loadProjects(); return; }
  activeProjectId = match[1]; listView.hidden = true; detailView.hidden = false;
  const response = await fetch(`/api/projects/${activeProjectId}`);
  if (!response.ok) { document.querySelector('#project-title').textContent = 'Project not found'; return; }
  const project = await response.json(); window.currentProjectArchived = project.archived;
  document.querySelector('#project-title').textContent = project.name;
  const renameInput = document.querySelector('#new-project-name');
  renameInput.value = project.name;
  renameInput.disabled = project.archived;
  document.querySelector('#rename-form button').disabled = project.archived;
  document.querySelector('#archived-notice').hidden = !project.archived;
  document.querySelector('#task-title').disabled = project.archived;
  document.querySelector('#task-form button').disabled = project.archived;
  const defaultPriority = document.querySelector('#default-task-priority');
  defaultPriority.value = project.default_priority || 'Normal';
  defaultPriority.disabled = project.archived;
  await loadTasks();
}

document.querySelector('#create-form').addEventListener('submit', async event => {
  event.preventDefault(); const input = document.querySelector('#project-name'); const name = input.value.trim();
  if (!name) { alert.textContent = 'Project name is required'; alert.hidden = false; return; }
  const response = await fetch('/api/projects', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name }) });
  if (!response.ok) { alert.textContent = 'Project name is required'; alert.hidden = false; return; }
  input.value = ''; alert.hidden = true; await loadProjects();
});

document.querySelector('#rename-form').addEventListener('submit', async event => {
  event.preventDefault();
  const input = document.querySelector('#new-project-name');
  const name = input.value.trim();
  const message = document.querySelector('#rename-alert');
  if (!name) { message.textContent = 'Project name is required'; message.hidden = false; return; }
  const response = await fetch(`/api/projects/${activeProjectId}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name }) });
  if (!response.ok) { message.textContent = response.status === 400 ? 'Project name is required' : 'Unable to rename project'; message.hidden = false; return; }
  message.hidden = true;
  await showPage();
});

document.querySelector('#task-form').addEventListener('submit', async event => {
  event.preventDefault(); const input = document.querySelector('#task-title'); const title = input.value.trim(); const message = document.querySelector('#task-alert');
  if (!title) { message.textContent = 'Task title is required'; message.hidden = false; return; }
  const response = await fetch(`/api/projects/${activeProjectId}/tasks`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ title }) });
  if (!response.ok) { message.textContent = 'Task title is required'; message.hidden = false; return; }
  input.value = ''; message.hidden = true; await loadTasks();
});
document.querySelector('#default-task-priority').addEventListener('change', async event => {
  const response = await fetch(`/api/projects/${activeProjectId}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ default_priority: event.target.value }) });
  if (!response.ok) { await showPage(); }
});
document.querySelector('#task-filter').addEventListener('change', loadTasks);
document.querySelector('#priority-filter').addEventListener('change', loadTasks);
document.querySelector('#apply-due-range').addEventListener('click', () => {
  const from = document.querySelector('#due-from').value.trim();
  const through = document.querySelector('#due-through').value.trim();
  const message = document.querySelector('#due-range-alert');
  const validDate = value => {
    if (!value) return true;
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    if (!match) return false;
    const year = Number(match[1]), month = Number(match[2]), day = Number(match[3]);
    if (year < 1 || month < 1 || month > 12) return false;
    const days = [31, year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    return day >= 1 && day <= days[month - 1];
  };
  if (!validDate(from) || !validDate(through)) { message.textContent = 'Due range must use valid YYYY-MM-DD dates'; message.hidden = false; return; }
  if (from && through && from > through) { message.textContent = 'Due from must not be after Due through'; message.hidden = false; return; }
  appliedDueRange = { from, through };
  message.hidden = true;
  loadTasks();
});
document.querySelector('#project-search-form').addEventListener('submit', event => { event.preventDefault(); loadProjects(); });
document.querySelector('#task-search-form').addEventListener('submit', event => { event.preventDefault(); loadTasks(); });
document.querySelector('#project-filter').addEventListener('change', loadProjects);
document.querySelector('#back-button').addEventListener('click', () => { location.href = '/'; });
showPage().catch(() => { alert.textContent = 'Unable to load Workboard'; alert.hidden = false; listView.hidden = false; });
