import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import net from 'node:net';
import { DatabaseSync } from 'node:sqlite';

async function availablePort() {
  const socket = net.createServer();
  socket.listen(0, '127.0.0.1');
  await once(socket, 'listening');
  const port = socket.address().port;
  await new Promise(resolve => socket.close(resolve));
  return port;
}

async function start(port, database) {
  const child = spawn(process.execPath, ['server.js'], {
    env: { ...process.env, PORT: String(port), DB_PATH: database },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let output = '';
  child.stderr.on('data', chunk => { output += chunk; });
  const base = `http://127.0.0.1:${port}`;
  for (let attempt = 0; attempt < 100; attempt++) {
    if (child.exitCode !== null) throw new Error(output);
    try {
      const response = await fetch(`${base}/health`);
      if (response.ok) return { child, base };
    } catch { /* Wait for the server to bind. */ }
    await new Promise(resolve => setTimeout(resolve, 20));
  }
  child.kill();
  throw new Error(`Server did not start: ${output}`);
}

async function stop(child) {
  const exit = once(child, 'exit');
  child.kill('SIGTERM');
  await exit;
}

test('remembered positions migrate, reserve absent slots, and restore reverse-order returns after restart', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-positions-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  // Simulate Task 011 data whose current order differs from task ID order.
  const legacy = new DatabaseSync(database);
  legacy.exec(`CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL);
    CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
      title TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, position INTEGER NOT NULL DEFAULT 0);
    INSERT INTO projects (name) VALUES ('Original'), ('Second'), ('Third');
    INSERT INTO tasks (project_id, title, position) VALUES (1, 'Later', 20), (1, 'Earlier', 10);`);
  legacy.close();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = async (path, method, body) => {
      const response = await fetch(`${running.base}${path}`, {
        method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      assert.equal(response.ok, true, await response.clone().text());
      return response.json();
    };
    const tasks = project => `/api/projects/${project}/tasks`;
    const move = (source, id, destination) => mutate(`${tasks(source)}/${id}/move`, 'POST', {
      destination_project_id: destination,
    });
    const ids = async project => (await get(tasks(project))).map(task => task.id);
    assert.deepEqual(await ids(1), [2, 1]);
    await move(1, 2, 2);
    await move(1, 1, 2);
    const newTask = await mutate(tasks(1), 'POST', { title: 'After reserved positions' });
    await mutate('/api/projects/1', 'PATCH', { name: 'Renamed original' });
    await mutate('/api/projects/1', 'PATCH', { archived: true });
    await stop(running.child);
    running = await start(port, database);
    const rejected = await fetch(`${running.base}${tasks(2)}/1/move`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ destination_project_id: 1 }),
    });
    assert.equal(rejected.status, 409);
    await mutate('/api/projects/1', 'PATCH', { archived: false });
    await mutate(`${tasks(2)}/1`, 'PATCH', { title: 'Latest title' });
    await mutate(`${tasks(2)}/1`, 'PATCH', { completed: true });
    await mutate(`${tasks(2)}/1`, 'PATCH', { priority: 'High' });
    await mutate(`${tasks(2)}/1`, 'PATCH', { due_date: '2028-02-29' });
    // Return in reverse order, with another project visited along the way.
    await move(2, 1, 3);
    await move(3, 1, 1);
    await move(2, 2, 1);
    assert.deepEqual(await ids(1), [2, 1, newTask.id]);
    assert.deepEqual((await get(tasks(1)))[1], {
      id: 1, title: 'Latest title', completed: true, priority: 'High', due_date: '2028-02-29', notes: '', deleted: false,
    });
    // Each destination remembers its own order, even if all tasks leave it.
    const secondNew = await mutate(tasks(2), 'POST', { title: 'Second new' });
    await move(1, 1, 2);
    await move(1, 2, 2);
    assert.deepEqual(await ids(2), [2, 1, secondNew.id]);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await ids(2), [2, 1, secondNew.id]);
    await move(2, 1, 1);
    await move(2, 2, 1);
    assert.deepEqual(await ids(1), [2, 1, newTask.id]);
    assert.equal((await get('/api/projects/1')).completed, 1);
    assert.equal((await get('/api/projects/2')).total, 1);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('moves append on first arrival, restore prior positions, and preserve task data and summaries', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-move-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = (path, method, body) => fetch(`${running.base}${path}`, {
      method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    const create = async (path, body) => (await mutate(path, 'POST', body)).json();
    const source = await create('/api/projects', { name: 'Source' });
    const destination = await create('/api/projects', { name: 'Destination' });
    const archived = await create('/api/projects', { name: 'Archived' });
    const sourcePath = `/api/projects/${source.id}`;
    const destinationPath = `/api/projects/${destination.id}`;
    const archivedPath = `/api/projects/${archived.id}`;
    const sourceTasks = `${sourcePath}/tasks`;
    const destinationTasks = `${destinationPath}/tasks`;
    // The oldest task must append after newer tasks, not sort by its ID.
    const first = await create(sourceTasks, { title: 'Oldest' });
    const remaining = await create(sourceTasks, { title: 'Remaining' });
    const existing = await create(destinationTasks, { title: 'Existing' });
    for (const changes of [{ completed: true }, { priority: 'High' }, { due_date: '0001-01-01' }]) {
      await mutate(`${sourceTasks}/${first.id}`, 'PATCH', changes);
    }
    const saved = { ...first, completed: true, priority: 'High', due_date: '0001-01-01' };
    await mutate(destinationPath, 'PATCH', { default_priority: 'Low' });
    await mutate(archivedPath, 'PATCH', { archived: true });
    const move = (path, id, destinationId) => mutate(`${path}/${id}/move`, 'POST', { destination_project_id: destinationId });
    for (const invalid of [source.id, null, '2', 1.5]) {
      assert.equal((await move(sourceTasks, first.id, invalid)).status, 400);
    }
    assert.equal((await move(sourceTasks, first.id, 99999)).status, 404);
    assert.equal((await move(sourceTasks, first.id, archived.id)).status, 409);
    assert.equal((await move(destinationTasks, first.id, source.id)).status, 404);
    assert.equal((await move(sourceTasks, 99999, destination.id)).status, 404);
    assert.deepEqual(await get(sourceTasks), [saved, remaining]);
    await mutate(sourcePath, 'PATCH', { archived: true });
    assert.equal((await move(sourceTasks, first.id, destination.id)).status, 409);
    await mutate(sourcePath, 'PATCH', { archived: false });
    const response = await move(sourceTasks, first.id, destination.id);
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), saved);
    assert.deepEqual(await get(sourceTasks), [remaining]);
    assert.deepEqual(await get(destinationTasks), [existing, saved]);
    assert.deepEqual(await get(sourcePath), { ...source, total: 1 });
    assert.deepEqual(await get(destinationPath), { ...destination, default_priority: 'Low', total: 2, completed: 1 });
    assert.equal((await mutate(`${sourceTasks}/${first.id}`, 'PATCH', { title: 'Wrong source' })).status, 404);
    const newlyCreated = await create(destinationTasks, { title: 'After move' });
    assert.equal(newlyCreated.priority, 'Low');
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(destinationTasks), [existing, saved, newlyCreated]);
    assert.deepEqual(await get(sourceTasks), [remaining]);
    await move(destinationTasks, first.id, source.id);
    await move(destinationTasks, existing.id, source.id);
    assert.deepEqual(await get(sourceTasks), [saved, remaining, existing]);
    assert.deepEqual(await get(destinationTasks), [newlyCreated]);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(sourceTasks), [saved, remaining, existing]);
    assert.deepEqual(await get(sourcePath), { ...source, total: 3, completed: 1 });
    assert.deepEqual(await get(destinationPath), { ...destination, default_priority: 'Low', total: 1 });
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('due dates validate, remain independent, and persist through edits, archive and restart', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-dates-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = (path, method, body) => fetch(`${running.base}${path}`, {
      method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    const project = await (await mutate('/api/projects', 'POST', { name: 'Dates' })).json();
    const other = await (await mutate('/api/projects', 'POST', { name: 'Other' })).json();
    const projectPath = `/api/projects/${project.id}`;
    const tasksPath = `${projectPath}/tasks`;
    const task = await (await mutate(tasksPath, 'POST', { title: 'First' })).json();
    const second = await (await mutate(tasksPath, 'POST', { title: 'Second' })).json();
    const taskPath = `${tasksPath}/${task.id}`;
    assert.equal(task.due_date, '');
    let saved = { ...task };
    for (const due_date of [' 0001-01-01 ', '9999-12-31', '2000-02-29', '2024-02-29']) {
      const response = await mutate(taskPath, 'PATCH', { due_date });
      assert.equal(response.status, 200);
      saved = { ...saved, due_date: due_date.trim() };
      assert.deepEqual(await response.json(), saved);
      assert.deepEqual(await get(tasksPath), [saved, second]);
    }
    for (const due_date of ['0000-01-01', '10000-01-01', '1900-02-29', '2023-02-29',
      '2024-04-31', '2024-00-01', '2024-13-01', '2024-01-00', '2024-01-32',
      '2024-1-01', '2024-01-1', '2024-01-01T00:00:00Z', 'not a date', null, 42]) {
      const response = await mutate(taskPath, 'PATCH', { due_date });
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Due date must be a valid YYYY-MM-DD date' });
      assert.deepEqual(await get(tasksPath), [saved, second]);
    }
    assert.equal((await mutate(taskPath, 'PATCH', { due_date: '', completed: true })).status, 400);
    assert.equal((await mutate(`/api/projects/${other.id}/tasks/${task.id}`, 'PATCH', { due_date: '' })).status, 404);
    await mutate(taskPath, 'PATCH', { title: 'Renamed' });
    await mutate(taskPath, 'PATCH', { completed: true });
    await mutate(taskPath, 'PATCH', { priority: 'High' });
    saved = { ...saved, title: 'Renamed', completed: true, priority: 'High' };
    const summary = { ...project, total: 2, completed: 1 };
    assert.deepEqual(await get(projectPath), summary);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [saved, second]);
    await mutate(projectPath, 'PATCH', { archived: true });
    assert.equal((await mutate(taskPath, 'PATCH', { due_date: '' })).status, 409);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [saved, second]);
    assert.equal((await mutate(taskPath, 'PATCH', { due_date: '2025-01-01' })).status, 409);
    await mutate(projectPath, 'PATCH', { archived: false });
    for (const due_date of ['', ' \t\n ']) {
      const response = await mutate(taskPath, 'PATCH', { due_date });
      assert.equal(response.status, 200);
      saved = { ...saved, due_date: '' };
      assert.deepEqual(await response.json(), saved);
    }
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [saved, second]);
    assert.deepEqual(await get(projectPath), summary);
    assert.deepEqual(await get(`/api/projects/${other.id}/tasks`), []);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('renaming preserves identity, order, tasks and summaries across restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-rename-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = (path, method, body) => fetch(`${running.base}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const first = await (await mutate('/api/projects', 'POST', { name: 'Original' })).json();
    const second = await (await mutate('/api/projects', 'POST', { name: 'Second' })).json();
    const path = `/api/projects/${first.id}`;
    const tasksPath = `${path}/tasks`;
    const task = await (await mutate(tasksPath, 'POST', { title: 'Keep this task' })).json();
    await mutate(`${tasksPath}/${task.id}`, 'PATCH', { completed: true });
    const original = { ...first, completed: 1, total: 1 };
    for (const name of ['', ' \t\n ', null, 42]) {
      const response = await mutate(path, 'PATCH', { name });
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Project name is required' });
      assert.deepEqual(await get(path), original);
    }
    const renamed = { ...original, name: 'Renamed project' };
    const response = await mutate(path, 'PATCH', { name: '  Renamed project  ' });
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), renamed);
    assert.deepEqual(await get('/api/projects'), [renamed, second]);
    assert.deepEqual(await get(tasksPath), [{ ...task, completed: true }]);
    assert.equal((await fetch(`${running.base}/projects/${first.id}`)).status, 200);
    assert.equal((await mutate('/api/projects/99999', 'PATCH', { name: 'Missing' })).status, 404);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get('/api/projects'), [renamed, second]);
    await mutate(path, 'PATCH', { archived: true });
    assert.equal((await mutate(path, 'PATCH', { name: 'Forbidden' })).status, 409);
    assert.equal((await mutate(path, 'PATCH', { name: 'Forbidden', archived: false })).status, 400);
    assert.deepEqual(await get(path), { ...renamed, archived: true });
    await stop(running.child);
    running = await start(port, database);
    assert.equal((await mutate(path, 'PATCH', { name: 'Still forbidden' })).status, 409);
    await mutate(path, 'PATCH', { archived: false });
    const restored = { ...renamed, name: 'Restored and renamed' };
    assert.deepEqual(await (await mutate(path, 'PATCH', { name: ' Restored and renamed ' })).json(), restored);
    assert.deepEqual(await get(tasksPath), [{ ...task, completed: true }]);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get('/api/projects'), [restored, second]);
    assert.deepEqual(await get(tasksPath), [{ ...task, completed: true }]);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('task renaming preserves completion, ownership, order and summaries across restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-task-rename-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = (path, method, body) => fetch(`${running.base}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const project = await (await mutate('/api/projects', 'POST', { name: 'First' })).json();
    const other = await (await mutate('/api/projects', 'POST', { name: 'Other' })).json();
    const projectPath = `/api/projects/${project.id}`;
    const tasksPath = `${projectPath}/tasks`;
    const otherTasksPath = `/api/projects/${other.id}/tasks`;
    const task = await (await mutate(tasksPath, 'POST', { title: 'Original' })).json();
    const second = await (await mutate(tasksPath, 'POST', { title: 'Second' })).json();
    const taskPath = `${tasksPath}/${task.id}`;
    await mutate(taskPath, 'PATCH', { completed: true });
    const completed = { ...task, completed: true };
    const summary = { ...project, completed: 1, total: 2 };
    for (const title of ['', ' \t\n ', null, 42]) {
      const response = await mutate(taskPath, 'PATCH', { title });
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Task title is required' });
      assert.deepEqual(await get(tasksPath), [completed, second]);
    }
    assert.equal((await mutate(`${otherTasksPath}/${task.id}`, 'PATCH', { title: 'Wrong project' })).status, 404);
    assert.equal((await mutate(`${tasksPath}/99999`, 'PATCH', { title: 'Missing' })).status, 404);
    assert.equal((await mutate(taskPath, 'PATCH', { title: 'Mixed', completed: false })).status, 400);
    const renamed = { ...completed, title: 'Renamed task' };
    const response = await mutate(taskPath, 'PATCH', { title: '  Renamed task  ' });
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), renamed);
    assert.deepEqual(await get(tasksPath), [renamed, second]);
    assert.deepEqual(await get(otherTasksPath), []);
    assert.deepEqual(await get('/api/projects'), [summary, other]);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [renamed, second]);
    await mutate(projectPath, 'PATCH', { archived: true });
    assert.equal((await mutate(taskPath, 'PATCH', { title: 'Forbidden' })).status, 409);
    assert.deepEqual(await get(tasksPath), [renamed, second]);
    await stop(running.child);
    running = await start(port, database);
    assert.equal((await mutate(taskPath, 'PATCH', { title: 'Still forbidden' })).status, 409);
    await mutate(projectPath, 'PATCH', { archived: false });
    const restored = { ...renamed, title: 'Restored task' };
    assert.deepEqual(await (await mutate(taskPath, 'PATCH', { title: ' Restored task ' })).json(), restored);
    const renamedOpen = { ...second, title: 'Renamed open task' };
    assert.deepEqual(await (await mutate(`${tasksPath}/${second.id}`, 'PATCH', { title: ' Renamed open task ' })).json(), renamedOpen);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [restored, renamedOpen]);
    assert.deepEqual(await get('/api/projects'), [summary, other]);
    assert.deepEqual(await get(otherTasksPath), []);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('priorities are independent and preserve task data through edits and restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-priority-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = (path, method, body) => fetch(`${running.base}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const project = await (await mutate('/api/projects', 'POST', { name: 'First' })).json();
    const other = await (await mutate('/api/projects', 'POST', { name: 'Other' })).json();
    const projectPath = `/api/projects/${project.id}`;
    const tasksPath = `${projectPath}/tasks`;
    const otherPath = `/api/projects/${other.id}/tasks`;
    const first = await (await mutate(tasksPath, 'POST', { title: 'First task' })).json();
    const second = await (await mutate(tasksPath, 'POST', { title: 'Second task' })).json();
    const otherTask = await (await mutate(otherPath, 'POST', { title: 'Other task' })).json();
    assert.equal(first.priority, 'Normal');
    assert.equal(second.priority, 'Normal');
    assert.equal(otherTask.priority, 'Normal');
    const firstPath = `${tasksPath}/${first.id}`;
    await mutate(firstPath, 'PATCH', { completed: true });
    const summary = await get(projectPath);
    for (const priority of ['High', 'Low', 'Normal', 'High']) {
      const response = await mutate(firstPath, 'PATCH', { priority });
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), { ...first, completed: true, priority });
      assert.deepEqual(await get(tasksPath), [{ ...first, completed: true, priority }, second]);
      assert.deepEqual(await get(otherPath), [otherTask]);
      assert.deepEqual(await get(projectPath), summary);
    }
    for (const priority of ['', 'high', ' High ', null, 42, true]) {
      assert.equal((await mutate(firstPath, 'PATCH', { priority })).status, 400);
    }
    assert.equal((await mutate(firstPath, 'PATCH', { priority: 'Low', completed: false })).status, 400);
    assert.equal((await mutate(firstPath, 'PATCH', { priority: 'Low', title: 'Mixed' })).status, 400);
    assert.equal((await mutate(`${otherPath}/${first.id}`, 'PATCH', { priority: 'Low' })).status, 404);
    assert.equal((await mutate(`${tasksPath}/99999`, 'PATCH', { priority: 'Low' })).status, 404);
    const renamed = { ...first, title: 'Renamed', completed: true, priority: 'High' };
    assert.deepEqual(await (await mutate(firstPath, 'PATCH', { title: ' Renamed ' })).json(), renamed);
    const low = { ...second, priority: 'Low' };
    assert.deepEqual(await (await mutate(`${tasksPath}/${second.id}`, 'PATCH', { priority: 'Low' })).json(), low);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [renamed, low]);
    await mutate(projectPath, 'PATCH', { archived: true });
    assert.equal((await mutate(firstPath, 'PATCH', { priority: 'Normal' })).status, 409);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [renamed, low]);
    assert.equal((await mutate(firstPath, 'PATCH', { priority: 'Normal' })).status, 409);
    await mutate(projectPath, 'PATCH', { archived: false });
    assert.deepEqual(await get(tasksPath), [renamed, low]);
    const normal = { ...renamed, priority: 'Normal' };
    assert.deepEqual(await (await mutate(firstPath, 'PATCH', { priority: 'Normal' })).json(), normal);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [normal, low]);
    assert.deepEqual(await get(projectPath), summary);
    assert.deepEqual(await get(otherPath), [otherTask]);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('project defaults affect only future tasks and survive rename, archive and restart', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-default-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = (path, method, body) => fetch(`${running.base}${path}`, {
      method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    const project = await (await mutate('/api/projects', 'POST', { name: 'First' })).json();
    const other = await (await mutate('/api/projects', 'POST', { name: 'Other' })).json();
    assert.equal(project.default_priority, 'Normal');
    assert.equal(other.default_priority, 'Normal');
    const path = `/api/projects/${project.id}`;
    const tasksPath = `${path}/tasks`;
    const createTask = async title => (await mutate(tasksPath, 'POST', { title })).json();
    const original = await createTask('Original');
    await mutate(`${tasksPath}/${original.id}`, 'PATCH', { completed: true });
    const saved = { ...original, completed: true };
    for (const priority of ['High', 'Low', 'Normal', 'High']) {
      const response = await mutate(path, 'PATCH', { default_priority: priority });
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), { ...project, completed: 1, total: 1, default_priority: priority });
      assert.deepEqual(await get(tasksPath), [saved]);
      assert.deepEqual(await get(`/api/projects/${other.id}`), other);
    }
    for (const priority of ['', 'high', ' High ', null, 42, true]) {
      assert.equal((await mutate(path, 'PATCH', { default_priority: priority })).status, 400);
    }
    assert.equal((await mutate(path, 'PATCH', { default_priority: 'Low', archived: true })).status, 400);
    assert.equal((await mutate(path, 'PATCH', { default_priority: 'Low', name: 'Mixed' })).status, 400);
    assert.equal((await mutate('/api/projects/99999', 'PATCH', { default_priority: 'Low' })).status, 404);
    const high = await createTask('Inherited high');
    assert.equal(high.priority, 'High');
    assert.equal(high.completed, false);
    await mutate(path, 'PATCH', { default_priority: 'Low' });
    await mutate(path, 'PATCH', { name: 'Renamed project' });
    await stop(running.child);
    running = await start(port, database);
    assert.equal((await get(path)).default_priority, 'Low');
    assert.equal((await get(path)).name, 'Renamed project');
    assert.deepEqual(await get(tasksPath), [saved, high]);
    await mutate(path, 'PATCH', { archived: true });
    assert.equal((await mutate(path, 'PATCH', { default_priority: 'Normal' })).status, 409);
    await stop(running.child);
    running = await start(port, database);
    assert.equal((await get(path)).default_priority, 'Low');
    assert.equal((await mutate(path, 'PATCH', { default_priority: 'High' })).status, 409);
    await mutate(path, 'PATCH', { archived: false });
    const low = await createTask('Inherited low');
    assert.equal(low.priority, 'Low');
    assert.deepEqual(await get(tasksPath), [saved, high, low]);
    const otherTask = await (await mutate(`/api/projects/${other.id}/tasks`, 'POST', { title: 'Other task' })).json();
    assert.equal(otherTask.priority, 'Normal');
    await mutate(path, 'PATCH', { default_priority: 'Normal' });
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(tasksPath), [saved, high, low]);
    assert.deepEqual(await get(path), { ...project, name: 'Renamed project', completed: 1, total: 3 });
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('legacy databases migrate without losing project IDs or tasks', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-migration-'));
  const database = join(directory, 'legacy.sqlite');
  const db = new DatabaseSync(database);
  db.exec(`CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL);
    CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER NOT NULL REFERENCES projects(id), title TEXT NOT NULL,
      completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1)));
    INSERT INTO projects (id, name) VALUES (42, 'Existing project');
    INSERT INTO tasks (project_id, title, completed) VALUES (42, 'Existing task', 1);`);
  db.close();
  let running;
  try {
    running = await start(await availablePort(), database);
    const projects = await (await fetch(`${running.base}/api/projects`)).json();
    assert.deepEqual(projects, [{ id: 42, name: 'Existing project', archived: false, default_priority: 'Normal', completed: 1, total: 1 }]);
    const tasks = await (await fetch(`${running.base}/api/projects/42/tasks`)).json();
    assert.deepEqual(tasks, [{ id: 1, title: 'Existing task', completed: true, priority: 'Normal', due_date: '', notes: '', deleted: false }]);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('projects and tasks validate, preserve ownership and order, and survive restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-'));
  const port = await availablePort();
  const database = join(directory, 'nested', 'projects.sqlite');
  let running;
  try {
    running = await start(port, database);
    const get = path => fetch(`${running.base}${path}`);
    const create = name => fetch(`${running.base}/api/projects`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });
    const health = await get('/health');
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { status: 'ok' });
    assert.deepEqual(await (await get('/api/projects')).json(), []);
    for (const name of ['', ' \t\n ', null]) {
      const response = await create(name);
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Project name is required' });
    }
    const firstResponse = await create('  First project  ');
    assert.equal(firstResponse.status, 201);
    const first = await firstResponse.json();
    assert.equal(first.name, 'First project');
    assert.equal(first.archived, false);
    assert.equal(first.completed, 0);
    assert.equal(first.total, 0);
    const second = await (await create('<Second project>')).json();
    assert.notEqual(first.id, second.id);
    assert.deepEqual(await (await get('/api/projects')).json(), [first, second]);
    assert.deepEqual(await (await get(`/api/projects/${first.id}`)).json(), first);
    assert.equal((await get('/api/projects/99999')).status, 404);
    for (const path of ['/', `/projects/${first.id}`, '/app.js', '/style.css', '/date-validation.js']) {
      assert.equal((await get(path)).status, 200);
    }
    const validator = await get('/date-validation.js');
    assert.match(validator.headers.get('content-type'), /text\/javascript/);
    assert.match(await validator.text(), /export function isValidDueDate/);
    const tasksPath = `/api/projects/${first.id}/tasks`;
    const otherTasksPath = `/api/projects/${second.id}/tasks`;
    const createTask = title => fetch(`${running.base}${tasksPath}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    });
    const completeTask = (path, completed) => fetch(`${running.base}${path}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed }),
    });
    assert.deepEqual(await (await get(tasksPath)).json(), []);
    for (const title of ['', ' \t\n ', null, 12]) {
      const response = await createTask(title);
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Task title is required' });
    }
    assert.deepEqual(await (await get(tasksPath)).json(), []);
    const taskResponse = await createTask('  First task  ');
    assert.equal(taskResponse.status, 201);
    const task = await taskResponse.json();
    assert.equal(task.title, 'First task');
    assert.equal(task.completed, false);
    const secondTask = await (await createTask('<Second task>')).json();
    assert.deepEqual(await (await get(tasksPath)).json(), [task, secondTask]);
    assert.deepEqual(await (await get(otherTasksPath)).json(), []);
    assert.equal((await get('/api/projects/99999/tasks')).status, 404);
    assert.equal((await completeTask(`${otherTasksPath}/${task.id}`, true)).status, 404);
    assert.equal((await completeTask(`${tasksPath}/99999`, true)).status, 404);
    assert.equal((await completeTask(`${tasksPath}/${task.id}`, 'true')).status, 400);
    assert.deepEqual(await (await get(tasksPath)).json(), [task, secondTask]);
    const completed = { ...task, completed: true };
    assert.deepEqual(await (await completeTask(`${tasksPath}/${task.id}`, true)).json(), completed);
    assert.deepEqual(await (await completeTask(`${tasksPath}/${task.id}`, false)).json(), task);
    assert.deepEqual(await (await completeTask(`${tasksPath}/${task.id}`, true)).json(), completed);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await (await get(tasksPath)).json(), [completed, secondTask]);
    assert.deepEqual(await (await get(otherTasksPath)).json(), []);
    assert.equal((await get(`/projects/${first.id}`)).status, 200);
    const summary = { ...first, completed: 1, total: 2 };
    assert.deepEqual(await (await get('/api/projects')).json(), [summary, second]);
    assert.deepEqual(await (await get(`/api/projects/${first.id}`)).json(), summary);
    const setArchived = archived => fetch(`${running.base}/api/projects/${first.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ archived }),
    });
    assert.equal((await setArchived('true')).status, 400);
    const archived = { ...summary, archived: true };
    assert.deepEqual(await (await setArchived(true)).json(), archived);
    assert.equal((await createTask('Forbidden')).status, 409);
    assert.equal((await completeTask(`${tasksPath}/${task.id}`, false)).status, 409);
    assert.deepEqual(await (await get(tasksPath)).json(), [completed, secondTask]);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await (await get('/api/projects')).json(), [archived, second]);
    assert.deepEqual(await (await get(`/api/projects/${first.id}`)).json(), archived);
    assert.deepEqual(await (await setArchived(false)).json(), summary);
    assert.deepEqual(await (await get(tasksPath)).json(), [completed, secondTask]);
    assert.deepEqual(await (await completeTask(`${tasksPath}/${task.id}`, false)).json(), task);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await (await get('/api/projects')).json(), [{ ...summary, completed: 0 }, second]);
    const malformed = await fetch(`${running.base}/api/projects`, { method: 'POST', body: '{' });
    assert.equal(malformed.status, 400);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('notes migrate without data loss and persist independently through edits, moves and archive', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-notes-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  const legacy = new DatabaseSync(database);
  legacy.exec(`CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL);
    CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
      title TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, priority TEXT NOT NULL DEFAULT 'Normal',
      due_date TEXT NOT NULL DEFAULT '', position INTEGER NOT NULL DEFAULT 0);
    INSERT INTO projects (name) VALUES ('Source'), ('Destination');
    INSERT INTO tasks VALUES (1, 1, 'Original', 1, 'High', '2028-02-29', 1);`);
  legacy.close();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = async (path, method, body, status = 200) => {
      const response = await fetch(`${running.base}${path}`, {
        method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      assert.equal(response.status, status, await response.clone().text());
      return response.json();
    };
    const original = { id: 1, title: 'Original', completed: true, priority: 'High', due_date: '2028-02-29', notes: '', deleted: false };
    assert.deepEqual(await get('/api/projects/1/tasks'), [original]);
    const second = await mutate('/api/projects/1/tasks', 'POST', { title: 'Second' }, 201);
    assert.equal(second.notes, '');
    const notes = '  Leading\n\nUnicode: 雪 🌍\t\n<script>alert("literal")</script>  ';
    let saved = await mutate('/api/projects/1/tasks/1', 'PATCH', { notes });
    assert.deepEqual(saved, { ...original, notes });
    for (const invalid of [null, 12, false, []]) {
      await mutate('/api/projects/1/tasks/1', 'PATCH', { notes: invalid }, 400);
    }
    await mutate('/api/projects/1/tasks/1', 'PATCH', { notes: '', title: 'Bad' }, 400);
    assert.deepEqual(await get('/api/projects/1/tasks'), [saved, second]);
    await mutate('/api/projects/2/tasks/1', 'PATCH', { notes: 'Wrong owner' }, 404);
    saved = await mutate('/api/projects/1/tasks/1', 'PATCH', { title: 'Renamed' });
    assert.equal(saved.notes, notes);
    assert.deepEqual(await mutate('/api/projects/1/tasks/1/move', 'POST', { destination_project_id: 2 }), saved);
    await mutate('/api/projects/2', 'PATCH', { archived: true });
    await mutate('/api/projects/2/tasks/1', 'PATCH', { notes: 'Forbidden' }, 409);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get('/api/projects/2/tasks'), [saved]);
    await mutate('/api/projects/2', 'PATCH', { archived: false });
    await mutate('/api/projects/2/tasks/1/move', 'POST', { destination_project_id: 1 });
    assert.deepEqual(await get('/api/projects/1/tasks'), [saved, second]);
    const summary = await get('/api/projects/1');
    saved = await mutate('/api/projects/1/tasks/1', 'PATCH', { notes: ' \t\n ' });
    assert.equal(saved.notes, ' \t\n ');
    saved = await mutate('/api/projects/1/tasks/1', 'PATCH', { notes: '' });
    assert.deepEqual(saved, { ...original, title: 'Renamed' });
    assert.deepEqual(await get('/api/projects/1'), summary);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get('/api/projects/1/tasks'), [saved, second]);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});

test('soft deletion migrates live data and preserves fields, summaries, and return positions across restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-deletion-'));
  const database = join(directory, 'projects.sqlite');
  const port = await availablePort();
  const legacy = new DatabaseSync(database);
  legacy.exec(`CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL);
    CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
      title TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, priority TEXT NOT NULL DEFAULT 'Normal',
      due_date TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', position INTEGER NOT NULL DEFAULT 0);
    INSERT INTO projects (name) VALUES ('Source'), ('Destination');
    INSERT INTO tasks VALUES (1, 1, 'Original', 1, 'High', '0001-01-01', '  Notes 雪\n<literal>  ', 1);`);
  legacy.close();
  let running;
  try {
    running = await start(port, database);
    const get = async path => (await fetch(`${running.base}${path}`)).json();
    const mutate = async (path, method, body, status = 200) => {
      const response = await fetch(`${running.base}${path}`, {
        method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      assert.equal(response.status, status, await response.clone().text());
      return response.json();
    };
    const source = '/api/projects/1';
    const destination = '/api/projects/2';
    const task = `${source}/tasks/1`;
    const original = (await get(`${source}/tasks`))[0];
    assert.deepEqual(original, { id: 1, title: 'Original', completed: true, priority: 'High',
      due_date: '0001-01-01', notes: '  Notes 雪\n<literal>  ', deleted: false });
    const second = await mutate(`${source}/tasks`, 'POST', { title: 'Second' }, 201);
    assert.equal(second.deleted, false);
    const existing = await mutate(`${destination}/tasks`, 'POST', { title: 'Existing' }, 201);
    const deleted = await mutate(task, 'PATCH', { deleted: true });
    assert.deepEqual(deleted, { ...original, deleted: true });
    for (const changes of [{ title: 'Forbidden' }, { completed: false }, { priority: 'Low' },
      { due_date: '' }, { notes: '' }]) {
      await mutate(task, 'PATCH', changes, 409);
    }
    await mutate(`${task}/move`, 'POST', { destination_project_id: 2 }, 409);
    for (const invalid of ['true', 1, null]) await mutate(task, 'PATCH', { deleted: invalid }, 400);
    await mutate(task, 'PATCH', { deleted: false, title: 'Combined' }, 400);
    await mutate(`${destination}/tasks/1`, 'PATCH', { deleted: false }, 404);
    await mutate(`${source}/tasks/9999`, 'PATCH', { deleted: true }, 404);
    assert.deepEqual(await get(`${source}/tasks`), [deleted, second]);
    assert.equal((await get(source)).total, 1);
    assert.equal((await get(source)).completed, 0);
    await mutate(`${source}/tasks/${second.id}`, 'PATCH', { deleted: true });
    assert.equal((await get(source)).total, 0);
    assert.equal((await get(source)).completed, 0);
    await mutate(source, 'PATCH', { archived: true });
    await mutate(task, 'PATCH', { deleted: false }, 409);
    await mutate(task, 'PATCH', { deleted: true }, 409);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual((await get(`${source}/tasks`))[0], deleted);
    assert.equal((await get(source)).total, 0);
    await mutate(source, 'PATCH', { archived: false });
    assert.equal((await get(`${source}/tasks`))[0].deleted, true);
    await mutate(source, 'PATCH', { default_priority: 'Low' });
    const later = await mutate(`${source}/tasks`, 'POST', { title: 'Later' }, 201);
    assert.equal(later.priority, 'Low');
    // Reverse restoration preserves reserved slots, not restoration order.
    await mutate(`${source}/tasks/${second.id}`, 'PATCH', { deleted: false });
    assert.deepEqual(await mutate(task, 'PATCH', { deleted: false }), original);
    assert.deepEqual(await get(`${source}/tasks`), [original, second, later]);
    assert.equal((await get(source)).total, 3);
    assert.equal((await get(source)).completed, 1);
    await mutate(`${task}/move`, 'POST', { destination_project_id: 2 });
    assert.deepEqual(await get(`${destination}/tasks`), [existing, original]);
    await mutate(`${destination}/tasks/1`, 'PATCH', { deleted: true });
    assert.equal((await get(destination)).total, 1);
    assert.equal((await get(destination)).completed, 0);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(`${destination}/tasks`), [existing, deleted]);
    await mutate(`${destination}/tasks/1`, 'PATCH', { deleted: false });
    await mutate(`${destination}/tasks/1/move`, 'POST', { destination_project_id: 1 });
    assert.deepEqual(await get(`${source}/tasks`), [original, second, later]);
    await stop(running.child);
    running = await start(port, database);
    assert.deepEqual(await get(`${source}/tasks`), [original, second, later]);
    assert.equal((await get(source)).completed, 1);
    assert.equal((await get(destination)).total, 1);
  } finally {
    if (running && running.child.exitCode === null) await stop(running.child);
    await rm(directory, { recursive: true, force: true });
  }
});
