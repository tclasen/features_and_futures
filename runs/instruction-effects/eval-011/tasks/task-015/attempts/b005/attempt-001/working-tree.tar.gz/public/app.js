import { isValidDueDate } from '/date-validation.js';

const app = document.querySelector('#app');

function element(tag, text) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  return node;
}

function showError(message) {
  let alert = app.querySelector('[role="alert"]');
  if (!alert) {
    alert = element('p');
    alert.setAttribute('role', 'alert');
    app.append(alert);
  }
  alert.textContent = message;
}

async function request(path, options) {
  const response = await fetch(path, options);
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || 'Request failed');
  return body;
}

// Normalize only for matching; keep saved and displayed text unchanged.
function searchMatches(text, query) {
  const normalize = value => value.replace(/[ \t]+/g, ' ')
    .replace(/[A-Z]/g, letter => letter.toLowerCase());
  return normalize(text).includes(normalize(query));
}

function searchForm(kind, onSearch) {
  const form = element('form');
  const label = element('label', `${kind} search`);
  const input = element('input');
  input.id = `${kind.toLowerCase()}-search`;
  input.type = 'text';
  label.htmlFor = input.id;
  const submit = element('button', kind === 'Project' ? 'Search projects' : 'Search tasks');
  submit.type = 'submit';
  form.append(label, input, submit);
  form.addEventListener('submit', event => {
    event.preventDefault();
    const query = input.value.trim();
    input.value = query;
    onSearch(query);
  });
  return form;
}

function projectsButton() {
  const button = element('button', 'Projects');
  button.type = 'button';
  button.addEventListener('click', () => location.assign('/'));
  return button;
}

function projectRow(project, onArchive) {
  const row = element('li');
  row.dataset.testid = 'project-row';
  const button = element('button', 'Open project');
  button.type = 'button';
  button.addEventListener('click', () => location.assign(`/projects/${project.id}`));
  const summary = element('span', `${project.completed}/${project.total} completed`);
  summary.dataset.testid = 'project-summary';
  const archive = element('button', project.archived ? 'Restore project' : 'Archive project');
  archive.type = 'button';
  archive.addEventListener('click', async () => {
    archive.disabled = true;
    try {
      const updated = await request(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archived: !project.archived }),
      });
      Object.assign(project, updated);
      app.querySelector('[role="alert"]')?.remove();
      onArchive();
    } catch (error) {
      showError(error.message);
    } finally {
      archive.disabled = false;
    }
  });
  row.append(element('span', project.name), summary, button, archive);
  return row;
}

function renderRename(project, heading) {
  const form = element('form');
  const label = element('label', 'New project name');
  label.htmlFor = 'new-project-name';
  const input = element('input');
  input.id = 'new-project-name';
  input.name = 'name';
  input.type = 'text';
  input.disabled = project.archived;
  const submit = element('button', 'Rename project');
  submit.type = 'submit';
  submit.disabled = project.archived;
  form.append(label, input, submit);
  app.append(form);

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (project.archived) return;
    if (!input.value.trim()) {
      showError('Project name is required');
      return;
    }
    submit.disabled = true;
    try {
      const updated = await request(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: input.value }),
      });
      Object.assign(project, updated);
      heading.textContent = project.name;
      document.title = `${project.name} · Workboard`;
      input.value = '';
      app.querySelector('[role="alert"]')?.remove();
      input.focus();
    } catch (error) {
      showError(error.message);
    } finally {
      submit.disabled = project.archived;
    }
  });
}

function taskRenameForm(project, task, endpoint, onRename) {
  const form = element('form');
  const label = element('label', 'New task title');
  const input = element('input');
  input.id = `new-task-title-${task.id}`;
  label.htmlFor = input.id;
  input.name = 'title';
  input.type = 'text';
  input.disabled = project.archived;
  const submit = element('button', 'Rename task');
  submit.type = 'submit';
  submit.disabled = project.archived;
  form.append(label, input, submit);

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (project.archived) return;
    if (!input.value.trim()) {
      showError('Task title is required');
      return;
    }
    submit.disabled = true;
    try {
      const updated = await request(`${endpoint}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: input.value }),
      });
      task.title = updated.title;
      app.querySelector('[role="alert"]')?.remove();
      onRename();
    } catch (error) {
      showError(error.message);
    } finally {
      submit.disabled = project.archived;
    }
  });
  return form;
}

function taskPriorityControl(project, task, endpoint, onPriorityChange) {
  const label = element('label', 'Task priority');
  const select = element('select');
  select.id = `task-priority-${task.id}`;
  label.htmlFor = select.id;
  select.disabled = project.archived;
  for (const priority of ['Low', 'Normal', 'High']) {
    const option = element('option', priority);
    option.value = priority;
    select.append(option);
  }
  select.value = task.priority;
  select.addEventListener('change', async () => {
    select.disabled = true;
    try {
      const updated = await request(`${endpoint}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priority: select.value }),
      });
      task.priority = updated.priority;
      app.querySelector('[role="alert"]')?.remove();
      onPriorityChange();
    } catch (error) {
      showError(error.message);
    } finally {
      select.value = task.priority;
      select.disabled = project.archived;
    }
  });
  const controls = element('div');
  controls.append(label, select);
  return controls;
}

function taskDueDateForm(project, task, endpoint, onDueDateChange) {
  const form = element('form');
  const label = element('label', 'Task due date');
  const input = element('input');
  input.id = `task-due-date-${task.id}`;
  label.htmlFor = input.id;
  input.type = 'text';
  input.name = 'due_date';
  input.value = task.due_date ?? '';
  input.disabled = project.archived;
  const submit = element('button', 'Save due date');
  submit.type = 'submit';
  submit.disabled = project.archived;
  form.append(label, input, submit);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (project.archived) return;
    submit.disabled = true;
    try {
      const updated = await request(`${endpoint}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ due_date: input.value }),
      });
      task.due_date = updated.due_date;
      input.value = task.due_date;
      app.querySelector('[role="alert"]')?.remove();
      onDueDateChange();
    } catch (error) {
      input.value = task.due_date ?? '';
      showError(error.message);
    } finally {
      submit.disabled = project.archived;
    }
  });
  return form;
}

function taskNotesForm(project, task, endpoint, onNotesChange) {
  const form = element('form');
  const label = element('label', 'Task notes');
  const textarea = element('textarea');
  textarea.id = `task-notes-${task.id}`;
  label.htmlFor = textarea.id;
  textarea.name = 'notes';
  textarea.rows = 4;
  textarea.value = task.notes ?? '';
  textarea.disabled = project.archived;
  const submit = element('button', 'Save notes');
  submit.type = 'submit';
  submit.disabled = project.archived;
  form.append(label, textarea, submit);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (project.archived) return;
    submit.disabled = true;
    try {
      const updated = await request(`${endpoint}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes: textarea.value }),
      });
      task.notes = updated.notes;
      app.querySelector('[role="alert"]')?.remove();
      onNotesChange();
    } catch (error) {
      showError(error.message);
    } finally {
      submit.disabled = project.archived;
    }
  });
  return form;
}

function taskMoveForm(project, task, endpoint, destinations, onMove) {
  const form = element('form');
  const label = element('label', 'Destination project');
  const select = element('select');
  select.id = `destination-project-${task.id}`;
  label.htmlFor = select.id;
  for (const destination of destinations) {
    const option = element('option', destination.name);
    option.value = String(destination.id);
    select.append(option);
  }
  const disabled = project.archived || destinations.length === 0;
  select.disabled = disabled;
  const submit = element('button', 'Move task');
  submit.type = 'submit';
  submit.disabled = disabled;
  form.append(label, select, submit);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (disabled) return;
    submit.disabled = true;
    select.disabled = true;
    try {
      await request(`${endpoint}/${task.id}/move`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destination_project_id: Number(select.value) }),
      });
      app.querySelector('[role="alert"]')?.remove();
      onMove();
    } catch (error) {
      showError(error.message);
    } finally {
      submit.disabled = disabled;
      select.disabled = disabled;
    }
  });
  return form;
}

function defaultPriorityControl(project) {
  const controls = element('div');
  const label = element('label', 'Default task priority');
  const select = element('select');
  select.id = 'default-task-priority';
  label.htmlFor = select.id;
  select.disabled = project.archived;
  for (const priority of ['Low', 'Normal', 'High']) {
    const option = element('option', priority);
    option.value = priority;
    select.append(option);
  }
  select.value = project.default_priority;
  select.addEventListener('change', async () => {
    if (project.archived) return;
    select.disabled = true;
    try {
      const updated = await request(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ default_priority: select.value }),
      });
      Object.assign(project, updated);
      app.querySelector('[role="alert"]')?.remove();
    } catch (error) {
      showError(error.message);
    } finally {
      select.value = project.default_priority;
      select.disabled = project.archived;
    }
  });
  controls.append(label, select);
  return controls;
}

async function renderTasks(project) {
  const endpoint = `/api/projects/${project.id}/tasks`;
  const form = element('form');
  const titleLabel = element('label', 'Task title');
  titleLabel.htmlFor = 'task-title';
  const input = element('input');
  input.id = 'task-title';
  input.name = 'title';
  input.type = 'text';
  const submit = element('button', 'Create task');
  submit.type = 'submit';
  submit.disabled = project.archived;
  form.append(titleLabel, input, submit);

  const filterLabel = element('label', 'Task filter');
  filterLabel.htmlFor = 'task-filter';
  const filter = element('select');
  filter.id = 'task-filter';
  for (const name of ['All', 'Open', 'Completed']) {
    const option = element('option', name);
    option.value = name;
    filter.append(option);
  }
  const priorityFilterLabel = element('label', 'Priority filter');
  priorityFilterLabel.htmlFor = 'priority-filter';
  const priorityFilter = element('select');
  priorityFilter.id = 'priority-filter';
  for (const name of ['All', 'Low', 'Normal', 'High']) {
    const option = element('option', name);
    option.value = name;
    priorityFilter.append(option);
  }
  const filterControls = element('div');
  filterControls.className = 'task-filter';
  filterControls.append(filterLabel, filter, priorityFilterLabel, priorityFilter);
  const dueRangeForm = element('form');
  const dueFromLabel = element('label', 'Due from');
  const dueFrom = element('input');
  dueFrom.id = 'due-from';
  dueFrom.type = 'text';
  dueFromLabel.htmlFor = dueFrom.id;
  const dueThroughLabel = element('label', 'Due through');
  const dueThrough = element('input');
  dueThrough.id = 'due-through';
  dueThrough.type = 'text';
  dueThroughLabel.htmlFor = dueThrough.id;
  const applyDueRange = element('button', 'Apply due range');
  applyDueRange.type = 'submit';
  dueRangeForm.append(dueFromLabel, dueFrom, dueThroughLabel, dueThrough, applyDueRange);
  // Draft fields are separate from the applied range so invalid submissions
  // and unapplied edits cannot change visible membership.
  let appliedFrom = '';
  let appliedThrough = '';
  const list = element('ul');
  list.setAttribute('aria-label', 'Tasks');
  let appliedSearch = '';
  const taskSearch = searchForm('Task', query => {
    appliedSearch = query;
    displayTasks();
  });
  app.append(defaultPriorityControl(project), form, filterControls, dueRangeForm, taskSearch, list);
  const [tasks, projects] = await Promise.all([request(endpoint), request('/api/projects')]);
  const destinations = projects.filter(destination => !destination.archived && destination.id !== project.id);

  function displayTasks() {
    list.replaceChildren();
    for (const task of tasks) {
      if (!searchMatches(task.title, appliedSearch)) continue;
      if (filter.value === 'Open' && task.completed) continue;
      if (filter.value === 'Completed' && !task.completed) continue;
      if (priorityFilter.value !== 'All' && task.priority !== priorityFilter.value) continue;
      if (appliedFrom || appliedThrough) {
        if (!task.due_date) continue;
        if (appliedFrom && task.due_date < appliedFrom) continue;
        if (appliedThrough && task.due_date > appliedThrough) continue;
      }
      const row = element('li');
      row.dataset.testid = 'task-row';
      const checkbox = element('input');
      checkbox.type = 'checkbox';
      checkbox.checked = task.completed;
      checkbox.disabled = project.archived;
      checkbox.setAttribute('aria-label', `Complete ${task.title}`);
      checkbox.addEventListener('change', async () => {
        checkbox.disabled = true;
        try {
          const updated = await request(`${endpoint}/${task.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completed: checkbox.checked }),
          });
          task.completed = updated.completed;
          app.querySelector('[role="alert"]')?.remove();
          displayTasks();
        } catch (error) {
          checkbox.checked = task.completed;
          showError(error.message);
        } finally {
          checkbox.disabled = project.archived;
        }
      });
      row.append(element('span', task.title), checkbox,
        taskRenameForm(project, task, endpoint, displayTasks),
        taskPriorityControl(project, task, endpoint, displayTasks),
        taskDueDateForm(project, task, endpoint, displayTasks),
        taskNotesForm(project, task, endpoint, displayTasks),
        taskMoveForm(project, task, endpoint, destinations, () => {
          tasks.splice(tasks.indexOf(task), 1);
          displayTasks();
        }));
      list.append(row);
    }
  }
  dueRangeForm.addEventListener('submit', event => {
    event.preventDefault();
    const from = dueFrom.value.trim();
    const through = dueThrough.value.trim();
    if ((from && !isValidDueDate(from)) || (through && !isValidDueDate(through))) {
      showError('Due range must use valid YYYY-MM-DD dates');
      return;
    }
    if (from && through && from > through) {
      showError('Due from must not be after Due through');
      return;
    }
    appliedFrom = from;
    appliedThrough = through;
    dueFrom.value = from;
    dueThrough.value = through;
    app.querySelector('[role="alert"]')?.remove();
    displayTasks();
  });
  filter.addEventListener('change', displayTasks);
  priorityFilter.addEventListener('change', displayTasks);
  displayTasks();

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (project.archived) return;
    if (!input.value.trim()) {
      showError('Task title is required');
      return;
    }
    submit.disabled = true;
    try {
      const task = await request(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: input.value }),
      });
      tasks.push(task);
      displayTasks();
      input.value = '';
      app.querySelector('[role="alert"]')?.remove();
      input.focus();
    } catch (error) {
      showError(error.message);
    } finally {
      submit.disabled = project.archived;
    }
  });
}

async function render() {
  const match = location.pathname.match(/^\/projects\/(\d+)$/);
  if (match) {
    app.append(projectsButton());
    const project = await request(`/api/projects/${match[1]}`);
    document.title = `${project.name} · Workboard`;
    const heading = element('h1', project.name);
    app.append(heading);
    if (project.archived) app.append(element('p', 'Archived project'));
    renderRename(project, heading);
    await renderTasks(project);
    return;
  }

  app.append(element('h1', 'Workboard'));
  const form = element('form');
  const label = element('label', 'Project name');
  label.htmlFor = 'project-name';
  const input = element('input');
  input.id = 'project-name';
  input.name = 'name';
  input.type = 'text';
  const submit = element('button', 'Create project');
  submit.type = 'submit';
  form.append(label, input, submit);
  const list = element('ul');
  list.setAttribute('aria-label', 'Projects');
  const filterLabel = element('label', 'Project filter');
  filterLabel.htmlFor = 'project-filter';
  const filter = element('select');
  filter.id = 'project-filter';
  for (const name of ['Active', 'Archived']) {
    const option = element('option', name);
    option.value = name;
    filter.append(option);
  }
  const filterControls = element('div');
  filterControls.className = 'task-filter';
  filterControls.append(filterLabel, filter);
  let appliedSearch = '';
  const projectSearch = searchForm('Project', query => {
    appliedSearch = query;
    displayProjects();
  });
  app.append(form, filterControls, projectSearch, list);
  const projects = await request('/api/projects');
  function displayProjects() {
    list.replaceChildren();
    for (const project of projects) {
      if (project.archived === (filter.value === 'Archived') && searchMatches(project.name, appliedSearch)) {
        list.append(projectRow(project, displayProjects));
      }
    }
  }
  filter.addEventListener('change', displayProjects);
  displayProjects();

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!input.value.trim()) {
      showError('Project name is required');
      return;
    }
    submit.disabled = true;
    try {
      const project = await request('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: input.value }),
      });
      projects.push(project);
      displayProjects();
      input.value = '';
      app.querySelector('[role="alert"]')?.remove();
      input.focus();
    } catch (error) {
      showError(error.message);
    } finally {
      submit.disabled = false;
    }
  });
}

render().catch(error => showError(error.message)).finally(() => {
  app.setAttribute('aria-busy', 'false');
});
