import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import { resolve } from 'node:path';
import { DatabaseSync } from 'node:sqlite';

test('projects and tasks: validation, ownership, filters, archive, rename, priority, and restart persistence', async () => {
  await mkdir('data', { recursive: true });
  const directory = await mkdtemp(resolve('data/test-'));
  // Start from the Task 002 schema to exercise the archive migration.
  const legacy = new DatabaseSync(resolve(directory, 'projects.sqlite'));
  legacy.exec(`CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL);
    CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER NOT NULL REFERENCES projects(id), title TEXT NOT NULL,
      completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1)));
    INSERT INTO projects (name) VALUES ('Legacy project');
    INSERT INTO tasks (project_id, title, completed) VALUES (1, 'Legacy task', 1);`);
  legacy.close();
  let child;
  async function start() {
    child = spawn(process.execPath, ['server.js'], {
      env: { ...process.env, PORT: '0', DB_PATH: resolve(directory, 'projects.sqlite') },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let output = '';
    const port = await new Promise((resolvePort, reject) => {
      const timeout = setTimeout(() => reject(new Error('Server did not start')), 5000);
      child.once('error', (error) => { clearTimeout(timeout); reject(error); });
      child.once('exit', (code) => { clearTimeout(timeout); reject(new Error(`Server exited: ${code}`)); });
      child.stdout.on('data', (chunk) => {
        output += chunk;
        const match = output.match(/listening on port (\d+)/);
        if (match) { clearTimeout(timeout); resolvePort(match[1]); }
      });
    });
    return `http://127.0.0.1:${port}`;
  }
  async function stop() {
    if (child && child.exitCode === null) {
      const exited = once(child, 'exit');
      child.kill('SIGTERM');
      await exited;
    }
  }
  try {
    let base = await start();
    const migrated = new DatabaseSync(resolve(directory, 'projects.sqlite'));
    assert.deepEqual({ ...migrated.prepare('SELECT title, completed, priority FROM tasks').get() }, {
      title: 'Legacy task', completed: 1, priority: 'Normal',
    });
    assert.equal(migrated.prepare('SELECT default_priority FROM projects').get().default_priority, 'Normal');
    const legacyPage = await (await fetch(`${base}/projects/1`)).text();
    assert.match(legacyPage, /<option>Low<\/option><option selected>Normal<\/option><option>High<\/option>/);
    migrated.exec('DELETE FROM tasks; DELETE FROM projects;');
    migrated.close();
    const health = await fetch(`${base}/health`);
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { status: 'ok' });
    const initial = await (await fetch(base)).text();
    assert.match(initial, /<h1>Workboard<\/h1>/);
    assert.match(initial, /<label for="project-name">Project name<\/label>/);
    assert.match(initial, />Create project<\/button>/);
    assert.equal((initial.match(/data-testid="project-row"/g) || []).length, 0);
    assert.match(initial, /<label for="project-filter">Project filter<\/label>/);
    assert.match(initial, /<option selected>Active<\/option><option>Archived<\/option>/);
    const create = (name) => fetch(`${base}/projects`, {
      method: 'POST', body: new URLSearchParams({ name }), redirect: 'manual',
    });
    for (const name of ['', ' \t\n ']) {
      const response = await create(name);
      assert.equal(response.status, 422);
      const html = await response.text();
      assert.match(html, /role="alert">Project name is required/);
      assert.doesNotMatch(html, /data-testid="project-row"/);
    }
    for (const name of ['  First project  ', '<Second & project>']) {
      const response = await create(name);
      assert.equal(response.status, 303);
      assert.equal(response.headers.get('location'), '/');
    }
    const listing = await (await fetch(base)).text();
    assert.equal((listing.match(/data-testid="project-row"/g) || []).length, 2);
    assert.equal((listing.match(/data-testid="project-summary">0\/0 completed/g) || []).length, 2);
    assert.match(listing, /<h3>First project<\/h3>/);
    assert.ok(listing.indexOf('First project') < listing.indexOf('&lt;Second &amp; project&gt;'));
    const ids = [...listing.matchAll(/action="\/projects\/(\d+)"/g)].map((match) => match[1]);
    assert.equal(ids.length, 2);
    assert.notEqual(ids[0], ids[1]);
    const detail = await (await fetch(`${base}/projects/${ids[0]}`)).text();
    assert.match(detail, /<h1>First project<\/h1>/);
    assert.match(detail, /action="\/" method="get"/);
    assert.match(detail, />Projects<\/button>/);
    assert.equal((await fetch(`${base}/projects/999999`)).status, 404);
    assert.equal(await (await fetch(base)).text(), listing);
    const taskPage = (projectId = ids[0], filter = 'All') =>
      fetch(`${base}/projects/${projectId}?filter=${filter}`).then((response) => response.text());
    const createTask = (title, projectId = ids[0]) => fetch(`${base}/projects/${projectId}/tasks`, {
      method: 'POST', body: new URLSearchParams({ title }), redirect: 'manual',
    });
    const rows = (html) => [...html.matchAll(/<article class="task-row"[\s\S]*?<\/article>/g)].map((match) => match[0]);
    assert.match(detail, /<label for="task-title">Task title<\/label>/);
    assert.match(detail, />Create task<\/button>/);
    assert.match(detail, /<label for="task-filter">Task filter<\/label>/);
    assert.match(detail, /<option selected>All<\/option><option>Open<\/option><option>Completed<\/option>/);
    for (const title of ['', ' \t\n ']) {
      const response = await createTask(title);
      assert.equal(response.status, 422);
      const html = await response.text();
      assert.match(html, /role="alert">Task title is required/);
      assert.equal(rows(html).length, 0);
    }
    for (const title of ['  First task  ', '<Second & "task">']) {
      const response = await createTask(title);
      assert.equal(response.status, 303);
      assert.equal(response.headers.get('location'), `/projects/${ids[0]}`);
    }
    const openTasks = await taskPage();
    const taskRows = rows(openTasks);
    assert.equal(taskRows.length, 2);
    assert.match(taskRows[0], /aria-label="Complete First task"/);
    assert.match(taskRows[0], /<span>First task<\/span>/);
    assert.match(taskRows[1], /aria-label="Complete &lt;Second &amp; &quot;task&quot;&gt;"/);
    assert.doesNotMatch(openTasks, / checked/);
    assert.equal(rows(await taskPage(ids[0], 'Open')).length, 2);
    assert.equal(rows(await taskPage(ids[0], 'Completed')).length, 0);
    assert.equal(rows(await taskPage(ids[1])).length, 0);
    const taskIds = taskRows.map((row) => row.match(/\/tasks\/(\d+)\/completion/)[1]);
    const complete = (taskId, completed, projectId = ids[0], filter = 'All') => fetch(
      `${base}/projects/${projectId}/tasks/${taskId}/completion`, {
        method: 'POST', body: new URLSearchParams({ ...(completed ? { completed: '1' } : {}), filter }), redirect: 'manual',
      });
    assert.equal((await complete(taskIds[0], true, ids[1])).status, 404);
    assert.doesNotMatch(await taskPage(), / checked/);
    const completion = await complete(taskIds[0], true, ids[0], 'Open');
    assert.equal(completion.status, 303);
    assert.equal(completion.headers.get('location'), `/projects/${ids[0]}?filter=Open`);
    assert.match(rows(await taskPage())[0], / checked/);
    assert.doesNotMatch(rows(await taskPage())[1], / checked/);
    assert.match(rows(await taskPage(ids[0], 'Completed'))[0], /<span>First task<\/span>/);
    assert.equal(rows(await taskPage(ids[0], 'Completed')).length, 1);
    assert.equal(rows(await taskPage(ids[0], 'Open')).length, 1);
    assert.match(rows(await taskPage(ids[0], 'Open'))[0], /Second/);
    assert.equal((await complete(taskIds[0], false)).status, 303);
    assert.equal(await taskPage(), openTasks);
    assert.equal((await complete(taskIds[1], true)).status, 303);
    assert.equal((await createTask('Other project task', ids[1])).status, 303);
    assert.equal(rows(await taskPage(ids[1])).length, 1);
    assert.doesNotMatch(await taskPage(), /Other project task/);
    const savedTasks = await taskPage();
    const savedOtherTasks = await taskPage(ids[1]);
    const invalid = await createTask('   ');
    assert.equal(invalid.status, 422);
    assert.equal(rows(await invalid.text()).length, 2);
    assert.equal(await taskPage(), savedTasks);
    const savedListing = await (await fetch(base)).text();
    assert.match(savedListing, /data-testid="project-summary">1\/2 completed/);
    assert.match(savedListing, /data-testid="project-summary">0\/1 completed/);
    await stop();
    base = await start();
    assert.equal(await (await fetch(base)).text(), savedListing);
    assert.match(await (await fetch(`${base}/projects/${ids[0]}`)).text(), /<h1>First project<\/h1>/);
    assert.match(await (await fetch(`${base}/projects/${ids[1]}`)).text(), /<h1>&lt;Second &amp; project&gt;<\/h1>/);
    assert.equal(await taskPage(), savedTasks);
    assert.equal(await taskPage(ids[1]), savedOtherTasks);
    assert.equal(rows(await taskPage(ids[0], 'Completed')).length, 1);
    assert.match(rows(await taskPage(ids[0], 'Completed'))[0], /Second/);
    const projectRows = (html) => [...html.matchAll(/<article class="project-row"[\s\S]*?<\/article>/g)].map((match) => match[0]);
    const projectList = (filter = 'Active') => fetch(`${base}/?filter=${filter}`).then((response) => response.text());
    const archive = (action, id = ids[0]) => fetch(`${base}/projects/${id}/${action}`, {
      method: 'POST', redirect: 'manual',
    });
    assert.equal((await archive('archive', '999999')).status, 404);
    assert.equal((await archive('archive')).status, 303);
    assert.equal(projectRows(await projectList()).length, 1);
    assert.doesNotMatch(await projectList(), /First project/);
    const archivedListing = await projectList('Archived');
    assert.equal(projectRows(archivedListing).length, 1);
    assert.match(archivedListing, />Restore project<\/button>/);
    assert.match(archivedListing, />Open project<\/button>/);
    assert.doesNotMatch(archivedListing, />Archive project<\/button>/);
    assert.match(archivedListing, /data-testid="project-summary">1\/2 completed/);
    const archivedPage = await taskPage();
    assert.match(archivedPage, /Archived project/);
    assert.match(archivedPage, /<button type="submit" disabled>Create task<\/button>/);
    assert.equal(rows(archivedPage).length, 2);
    for (const row of rows(archivedPage)) assert.match(row, /disabled/);
    assert.match(rows(archivedPage)[1], / checked/);
    assert.equal(rows(await taskPage(ids[0], 'Completed')).length, 1);
    assert.equal(rows(await taskPage(ids[0], 'Open')).length, 1);
    assert.equal((await createTask('Cannot create')).status, 403);
    assert.equal((await complete(taskIds[0], true)).status, 403);
    assert.equal((await complete(taskIds[1], false)).status, 403);
    assert.equal(await taskPage(), archivedPage);
    assert.equal(await taskPage(ids[1]), savedOtherTasks);
    await stop();
    base = await start();
    assert.equal(await projectList('Archived'), archivedListing);
    assert.equal(await taskPage(), archivedPage);
    assert.equal((await archive('restore')).status, 303);
    assert.equal(projectRows(await projectList('Archived')).length, 0);
    assert.equal(await projectList(), savedListing);
    assert.equal(await taskPage(), savedTasks);
    assert.equal((await complete(taskIds[0], true)).status, 303);
    assert.match(await projectList(), /data-testid="project-summary">2\/2 completed/);
    assert.equal((await complete(taskIds[0], false)).status, 303);
    await stop();
    base = await start();
    assert.equal(await projectList(), savedListing);
    assert.equal(await taskPage(), savedTasks);
    const rename = (name, id = ids[0], filter = 'All') => fetch(`${base}/projects/${id}/rename`, {
      method: 'POST', body: new URLSearchParams({ name, filter }), redirect: 'manual',
    });
    assert.match(savedTasks, /<label for="new-project-name">New project name<\/label>/);
    assert.match(savedTasks, /<button type="submit">Rename project<\/button>/);
    assert.equal((await rename('Missing', '999999')).status, 404);
    for (const name of ['', ' \t\n ']) {
      const response = await rename(name);
      assert.equal(response.status, 422);
      const html = await response.text();
      assert.match(html, /role="alert">Project name is required/);
      assert.match(html, /<h1>First project<\/h1>/);
      assert.equal(await taskPage(), savedTasks);
      assert.equal(await projectList(), savedListing);
    }
    const renamed = await rename('  Renamed <project & "name">  ', ids[0], 'Completed');
    assert.equal(renamed.status, 303);
    assert.equal(renamed.headers.get('location'), `/projects/${ids[0]}?filter=Completed`);
    const renamedPage = await taskPage();
    const renamedListing = await projectList();
    assert.match(renamedPage, /<h1>Renamed &lt;project &amp; &quot;name&quot;&gt;<\/h1>/);
    assert.match(renamedPage, /value="Renamed &lt;project &amp; &quot;name&quot;&gt;"/);
    assert.deepEqual(rows(renamedPage), rows(savedTasks));
    assert.equal(await taskPage(ids[1]), savedOtherTasks);
    const renamedRows = projectRows(renamedListing);
    assert.match(renamedRows[0], /<h3>Renamed &lt;project &amp; &quot;name&quot;&gt;<\/h3>/);
    assert.match(renamedRows[0], new RegExp(`action="/projects/${ids[0]}"`));
    assert.match(renamedRows[0], /data-testid="project-summary">1\/2 completed/);
    assert.equal(renamedRows[1], projectRows(savedListing)[1]);
    await stop();
    base = await start();
    assert.equal(await taskPage(), renamedPage);
    assert.equal(await projectList(), renamedListing);
    assert.equal((await archive('archive')).status, 303);
    const archivedRenamedPage = await taskPage();
    assert.match(archivedRenamedPage, /id="new-project-name"[^>]* disabled/);
    assert.match(archivedRenamedPage, /<button type="submit" disabled>Rename project<\/button>/);
    assert.equal((await rename('Cannot rename')).status, 403);
    assert.equal(await taskPage(), archivedRenamedPage);
    await stop();
    base = await start();
    assert.equal(await taskPage(), archivedRenamedPage);
    assert.equal((await archive('restore')).status, 303);
    assert.equal(await taskPage(), renamedPage);
    assert.equal(await projectList(), renamedListing);
    assert.equal((await rename(' Restored project ')).status, 303);
    const restoredRenamedPage = await taskPage();
    assert.match(restoredRenamedPage, /<h1>Restored project<\/h1>/);
    assert.deepEqual(rows(restoredRenamedPage), rows(savedTasks));
    const restoredListing = await projectList();
    await stop();
    base = await start();
    assert.equal(await taskPage(), restoredRenamedPage);
    assert.equal(await projectList(), restoredListing);
    const renameTask = (title, taskId = taskIds[1], projectId = ids[0], filter = 'All') =>
      fetch(`${base}/projects/${projectId}/tasks/${taskId}/rename`, {
        method: 'POST', body: new URLSearchParams({ title, filter }), redirect: 'manual',
      });
    for (const row of rows(await taskPage())) {
      assert.match(row, /<label for="new-task-title-\d+">New task title<\/label>/);
      assert.match(row, /<button type="submit">Rename task<\/button>/);
    }
    assert.equal((await renameTask('Wrong project', taskIds[1], ids[1])).status, 404);
    assert.equal((await renameTask('Missing task', '999999')).status, 404);
    assert.equal((await renameTask('Missing project', taskIds[1], '999999')).status, 404);
    for (const title of ['', ' \t\n ']) {
      const response = await renameTask(title, taskIds[1], ids[0], 'Completed');
      assert.equal(response.status, 422);
      const html = await response.text();
      assert.match(html, /role="alert">Task title is required/);
      assert.equal(rows(html).length, 1);
      assert.match(html, /<option selected>Completed<\/option>/);
      assert.equal(await taskPage(), restoredRenamedPage);
      assert.equal(await projectList(), restoredListing);
    }
    const taskRename = await renameTask('  Renamed <task & "title">  ', taskIds[1], ids[0], 'Completed');
    assert.equal(taskRename.status, 303);
    assert.equal(taskRename.headers.get('location'), `/projects/${ids[0]}?filter=Completed`);
    const taskRenamedPage = await taskPage();
    const taskRenamedRows = rows(taskRenamedPage);
    assert.equal(taskRenamedRows[0], rows(restoredRenamedPage)[0]);
    assert.match(taskRenamedRows[1], /<span>Renamed &lt;task &amp; &quot;title&quot;&gt;<\/span>/);
    assert.match(taskRenamedRows[1], /aria-label="Complete Renamed &lt;task &amp; &quot;title&quot;&gt;" checked/);
    assert.match(taskRenamedRows[1], /value="Renamed &lt;task &amp; &quot;title&quot;&gt;"/);
    assert.match(taskRenamedRows[1], new RegExp(`/tasks/${taskIds[1]}/rename`));
    assert.deepEqual(rows(await taskPage(ids[0], 'Completed')), [taskRenamedRows[1].replaceAll('name="filter" value="All"', 'name="filter" value="Completed"')]);
    assert.equal(rows(await taskPage(ids[0], 'Open')).length, 1);
    assert.equal(await taskPage(ids[1]), savedOtherTasks);
    assert.equal(await projectList(), restoredListing);
    assert.equal((await renameTask(' Renamed open task ', taskIds[0])).status, 303);
    assert.match(rows(await taskPage(ids[0], 'Open'))[0], /aria-label="Complete Renamed open task"/);
    assert.doesNotMatch(rows(await taskPage())[0], / checked/);
    const bothRenamedPage = await taskPage();
    await stop();
    base = await start();
    assert.equal(await taskPage(), bothRenamedPage);
    assert.equal(await projectList(), restoredListing);
    assert.equal((await archive('archive')).status, 303);
    const archivedTasksPage = await taskPage();
    for (const row of rows(archivedTasksPage)) {
      assert.match(row, /id="new-task-title-\d+"[^>]* disabled/);
      assert.match(row, /<button type="submit" disabled>Rename task<\/button>/);
    }
    assert.equal((await renameTask('Forbidden')).status, 403);
    assert.equal(await taskPage(), archivedTasksPage);
    await stop();
    base = await start();
    assert.equal(await taskPage(), archivedTasksPage);
    assert.equal((await archive('restore')).status, 303);
    assert.equal(await taskPage(), bothRenamedPage);
    assert.equal(await projectList(), restoredListing);
    assert.equal((await renameTask(' Restored task ')).status, 303);
    assert.match(rows(await taskPage())[1], /aria-label="Complete Restored task" checked/);
    const finalPage = await taskPage();
    await stop();
    base = await start();
    assert.equal(await taskPage(), finalPage);
    assert.equal(await projectList(), restoredListing);
    const priority = (value, taskId = taskIds[0], projectId = ids[0], filter = 'All') =>
      fetch(`${base}/projects/${projectId}/tasks/${taskId}/priority`, {
        method: 'POST', body: new URLSearchParams({ priority: value, filter }), redirect: 'manual',
      });
    const selectedPriority = (row) => row.match(/<select id="task-priority-\d+"[\s\S]*?<\/select>/)[0];
    for (const row of rows(finalPage)) {
      assert.match(row, /<label for="task-priority-\d+">Task priority<\/label>/);
      assert.match(selectedPriority(row), /<option>Low<\/option><option selected>Normal<\/option><option>High<\/option>/);
      assert.doesNotMatch(selectedPriority(row), /disabled/);
    }
    assert.equal((await priority('High', taskIds[0], ids[1])).status, 404);
    assert.equal((await priority('High', '999999')).status, 404);
    assert.equal((await priority('High', taskIds[0], '999999')).status, 404);
    for (const value of ['', 'Urgent', 'high']) assert.equal((await priority(value)).status, 422);
    assert.equal(await taskPage(), finalPage);
    const changed = await priority('High', taskIds[0], ids[0], 'Open');
    assert.equal(changed.status, 303);
    assert.equal(changed.headers.get('location'), `/projects/${ids[0]}?filter=Open`);
    const highRows = rows(await taskPage());
    assert.equal(highRows[0], rows(finalPage)[0].replace('<option selected>Normal</option><option>High</option>', '<option>Normal</option><option selected>High</option>'));
    assert.equal(highRows[1], rows(finalPage)[1]);
    assert.equal(await taskPage(ids[1]), savedOtherTasks);
    assert.equal(await projectList(), restoredListing);
    assert.equal(rows(await taskPage(ids[0], 'Open')).length, 1);
    assert.equal(rows(await taskPage(ids[0], 'Completed')).length, 1);
    assert.equal((await priority('Low', taskIds[1])).status, 303);
    assert.match(selectedPriority(rows(await taskPage())[0]), /<option selected>High/);
    assert.match(selectedPriority(rows(await taskPage())[1]), /<option selected>Low/);
    assert.equal((await renameTask(' Priority preserved ')).status, 303);
    assert.match(rows(await taskPage())[1], /aria-label="Complete Priority preserved" checked/);
    assert.match(selectedPriority(rows(await taskPage())[1]), /<option selected>Low/);
    const prioritiesPage = await taskPage();
    await stop();
    base = await start();
    assert.equal(await taskPage(), prioritiesPage);
    assert.equal(await projectList(), restoredListing);
    assert.equal((await archive('archive')).status, 303);
    const archivedPrioritiesPage = await taskPage();
    for (const row of rows(archivedPrioritiesPage)) assert.match(selectedPriority(row), / disabled/);
    assert.equal((await priority('Normal')).status, 403);
    assert.equal((await priority('High', taskIds[1])).status, 403);
    assert.equal(await taskPage(), archivedPrioritiesPage);
    await stop();
    base = await start();
    assert.equal(await taskPage(), archivedPrioritiesPage);
    assert.equal((await archive('restore')).status, 303);
    assert.equal(await taskPage(), prioritiesPage);
    assert.equal((await priority('Normal')).status, 303);
    assert.match(selectedPriority(rows(await taskPage())[0]), /<option selected>Normal/);
    assert.match(selectedPriority(rows(await taskPage())[1]), /<option selected>Low/);
    assert.equal((await createTask('New normal task')).status, 303);
    const newRows = rows(await taskPage());
    assert.equal(newRows.length, 3);
    assert.match(selectedPriority(newRows[2]), /<option selected>Normal/);
    assert.doesNotMatch(newRows[2], / checked/);
    assert.match(await projectList(), /data-testid="project-summary">1\/3 completed/);
    const finalPrioritiesPage = await taskPage();
    await stop();
    base = await start();
    assert.equal(await taskPage(), finalPrioritiesPage);

    // Exercise every intersection with tasks in distinct priority/completion states.
    await priority('High', taskIds[0]);
    const combinedPage = (filter = 'All', priorityFilter = 'All') => fetch(
      `${base}/projects/${ids[0]}?${new URLSearchParams({ filter, priorityFilter })}`,
    ).then((response) => response.text());
    const visibleTitles = (html) => rows(html).map((row) => row.match(/<span>(.*?)<\/span>/)[1]);
    const expectedTasks = [
      { title: 'Renamed open task', completed: false, priority: 'High' },
      { title: 'Priority preserved', completed: true, priority: 'Low' },
      { title: 'New normal task', completed: false, priority: 'Normal' },
    ];
    const assertFilters = (html, filter, priorityFilter) => {
      const filterForm = html.match(/<form[^>]*class="filter-form">[\s\S]*?<\/form>/)[0];
      for (const [id, value] of [['task-filter', filter], ['priority-filter', priorityFilter]]) {
        const select = filterForm.match(new RegExp(`<select id="${id}"[\\s\\S]*?</select>`))[0];
        assert.match(select, new RegExp(`<option selected>${value}</option>`));
        assert.doesNotMatch(select, /disabled/);
      }
    };
    const defaultPage = await taskPage();
    assertFilters(defaultPage, 'All', 'All');
    assert.match(defaultPage, /<label for="priority-filter">Priority filter<\/label>/);
    assert.match(defaultPage, /<option selected>All<\/option><option>Low<\/option><option>Normal<\/option><option>High<\/option>/);
    const summaryBeforeFilters = await projectList();
    for (const filter of ['All', 'Open', 'Completed']) {
      for (const priorityFilter of ['All', 'Low', 'Normal', 'High']) {
        const html = await combinedPage(filter, priorityFilter);
        assertFilters(html, filter, priorityFilter);
        for (const row of rows(html)) {
          for (const form of row.matchAll(/<form[\s\S]*?<\/form>/g)) {
            assert.match(form[0], new RegExp(`name="filter" value="${filter}"`));
            assert.match(form[0], new RegExp(`name="priorityFilter" value="${priorityFilter}"`));
          }
        }
        assert.deepEqual(visibleTitles(html), expectedTasks.filter((task) =>
          (filter === 'All' || task.completed === (filter === 'Completed')) &&
          (priorityFilter === 'All' || task.priority === priorityFilter),
        ).map((task) => task.title));
      }
    }
    assert.equal(await projectList(), summaryBeforeFilters);
    const editWithFilters = (action, taskId, values, filter, priorityFilter) => fetch(
      `${base}/projects/${ids[0]}/tasks/${taskId}/${action}`, {
        method: 'POST', redirect: 'manual',
        body: new URLSearchParams({ ...values, filter, priorityFilter }),
      });
    const followEdit = async (action, taskId, values, filter, priorityFilter, status = 303) => {
      const response = await editWithFilters(action, taskId, values, filter, priorityFilter);
      assert.equal(response.status, status);
      const html = status === 303
        ? await (await fetch(new URL(response.headers.get('location'), base))).text()
        : await response.text();
      assertFilters(html, filter, priorityFilter);
      return html;
    };
    let filtered = await followEdit('rename', taskIds[0], { title: '  Filtered task  ' }, 'Open', 'High');
    assert.deepEqual(visibleTitles(filtered), ['Filtered task']);
    assert.match(filtered, /aria-label="Complete Filtered task"/);
    assert.match(selectedPriority(rows(filtered)[0]), /<option selected>High/);
    assert.equal(await projectList(), summaryBeforeFilters);
    filtered = await followEdit('rename', taskIds[0], { title: '   ' }, 'Open', 'High', 422);
    assert.match(filtered, /role="alert">Task title is required/);
    assert.deepEqual(visibleTitles(filtered), ['Filtered task']);
    filtered = await followEdit('priority', taskIds[0], { priority: 'Invalid' }, 'Open', 'High', 422);
    assert.deepEqual(visibleTitles(filtered), ['Filtered task']);
    filtered = await followEdit('priority', taskIds[0], { priority: 'Low' }, 'Open', 'High');
    assert.deepEqual(visibleTitles(filtered), []);
    assert.deepEqual(visibleTitles(await combinedPage('Open', 'Low')), ['Filtered task']);
    assert.equal(await projectList(), summaryBeforeFilters);
    filtered = await followEdit('completion', taskIds[0], { completed: '1' }, 'Open', 'Low');
    assert.deepEqual(visibleTitles(filtered), []);
    assert.deepEqual(visibleTitles(await combinedPage('Completed', 'Low')), ['Filtered task', 'Priority preserved']);
    filtered = await followEdit('completion', taskIds[0], {}, 'Completed', 'Low');
    assert.deepEqual(visibleTitles(filtered), ['Priority preserved']);
    assert.equal(await projectList(), summaryBeforeFilters);
    const savedCombinedPage = await taskPage();
    await stop();
    base = await start();
    assert.equal(await taskPage(), savedCombinedPage);
    assert.deepEqual(visibleTitles(await combinedPage('Open', 'Low')), ['Filtered task']);
    assert.equal(await projectList(), summaryBeforeFilters);
    await archive('archive');
    const archivedCombinedPage = await combinedPage('Completed', 'Low');
    assertFilters(archivedCombinedPage, 'Completed', 'Low');
    assert.deepEqual(visibleTitles(archivedCombinedPage), ['Priority preserved']);
    assert.match(archivedCombinedPage, /Archived project/);
    for (const row of rows(archivedCombinedPage)) {
      assert.match(row, /type="checkbox"[\s\S]*?disabled/);
      assert.match(row, /id="new-task-title-\d+"[^>]* disabled/);
      assert.match(row, /<button type="submit" disabled>Rename task/);
      assert.match(selectedPriority(row), /disabled/);
    }
    await followEdit('priority', taskIds[1], { priority: 'High' }, 'Completed', 'Low', 403);
    await stop();
    base = await start();
    assert.equal(await combinedPage('Completed', 'Low'), archivedCombinedPage);
    await archive('restore');
    assert.equal(await taskPage(), savedCombinedPage);
    assert.equal(await projectList(), summaryBeforeFilters);

    // Defaults affect only future tasks in their own project, preserving filters and all existing data.
    const defaultSelect = (html) => html.match(/<select id="default-task-priority"[\s\S]*?<\/select>/)[0];
    const setDefault = (value, projectId = ids[0], filter = 'Open', priorityFilter = 'Low') => fetch(
      `${base}/projects/${projectId}/default-priority`, {
        method: 'POST', redirect: 'manual',
        body: new URLSearchParams({ priority: value, filter, priorityFilter }),
      });
    assert.match(await taskPage(), /<label for="default-task-priority">Default task priority<\/label>/);
    assert.match(defaultSelect(await taskPage()), /<option>Low<\/option><option selected>Normal<\/option><option>High<\/option>/);
    assert.equal((await setDefault('High', '999999')).status, 404);
    for (const value of ['', 'Urgent', 'high']) assert.equal((await setDefault(value)).status, 422);
    assert.equal(await taskPage(), savedCombinedPage);
    const beforeDefaultRows = rows(await combinedPage('Open', 'Low'));
    const changedDefault = await setDefault('High');
    assert.equal(changedDefault.status, 303);
    assert.equal(changedDefault.headers.get('location'), `/projects/${ids[0]}?filter=Open&priorityFilter=Low`);
    const defaultChangedPage = await (await fetch(new URL(changedDefault.headers.get('location'), base))).text();
    assertFilters(defaultChangedPage, 'Open', 'Low');
    assert.deepEqual(rows(defaultChangedPage), beforeDefaultRows);
    assert.deepEqual(rows(await taskPage()), rows(savedCombinedPage));
    assert.equal(await projectList(), summaryBeforeFilters);
    assert.equal(await taskPage(ids[1]), savedOtherTasks);
    assert.match(defaultSelect(defaultChangedPage), /<option selected>High/);
    await stop();
    base = await start();
    assert.match(defaultSelect(await taskPage()), /<option selected>High/);
    await createTask('Inherited high');
    let inheritedRows = rows(await taskPage());
    assert.match(selectedPriority(inheritedRows[3]), /<option selected>High/);
    assert.match(inheritedRows[3], /<span>Inherited high<\/span>/);
    assert.doesNotMatch(inheritedRows[3], / checked/);
    const inheritedId = inheritedRows[3].match(/\/tasks\/(\d+)\/completion/)[1];
    await setDefault('Low');
    assert.deepEqual(rows(await taskPage()), inheritedRows);
    await createTask('Inherited low');
    inheritedRows = rows(await taskPage());
    assert.match(selectedPriority(inheritedRows[3]), /<option selected>High/);
    assert.match(selectedPriority(inheritedRows[4]), /<option selected>Low/);
    await setDefault('High', ids[1]);
    assert.match(defaultSelect(await taskPage()), /<option selected>Low/);
    assert.match(defaultSelect(await taskPage(ids[1])), /<option selected>High/);
    await createTask('Other inherited high', ids[1]);
    assert.match(selectedPriority(rows(await taskPage(ids[1]))[1]), /<option selected>High/);
    await rename('Default preserved');
    await renameTask('Inherited renamed', inheritedId);
    assert.match(defaultSelect(await taskPage()), /<option selected>Low/);
    assert.match(selectedPriority(rows(await taskPage())[3]), /<option selected>High/);
    const defaultsSavedPage = await taskPage();
    const defaultsSavedList = await projectList();
    assert.match(defaultsSavedList, /data-testid="project-summary">1\/5 completed/);
    await archive('archive');
    const archivedDefaultPage = await combinedPage('Open', 'Low');
    assertFilters(archivedDefaultPage, 'Open', 'Low');
    assert.match(defaultSelect(archivedDefaultPage), /disabled/);
    assert.match(defaultSelect(archivedDefaultPage), /<option selected>Low/);
    assert.equal((await setDefault('Normal')).status, 403);
    assert.equal(await combinedPage('Open', 'Low'), archivedDefaultPage);
    await stop();
    base = await start();
    assert.equal(await combinedPage('Open', 'Low'), archivedDefaultPage);
    assert.match(defaultSelect(await taskPage(ids[1])), /<option selected>High/);
    await archive('restore');
    assert.equal(await taskPage(), defaultsSavedPage);
    assert.equal(await projectList(), defaultsSavedList);
    assert.doesNotMatch(defaultSelect(await taskPage()), /disabled/);
    await createTask('Restored inherited low');
    assert.match(selectedPriority(rows(await taskPage())[5]), /<option selected>Low/);
    await setDefault('Normal');
    await createTask('Inherited normal again');
    assert.match(selectedPriority(rows(await taskPage())[6]), /<option selected>Normal/);
    const finalDefaultsPage = await taskPage();
    await stop();
    base = await start();
    assert.equal(await taskPage(), finalDefaultsPage);
  } finally {
    await stop();
    await rm(directory, { recursive: true, force: true });
  }
});
