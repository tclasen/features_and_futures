const app = document.querySelector('#app');

function element(tag, text, attributes = {}) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, value);
  return node;
}
async function request(path, options) {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Unable to complete request');
  return data;
}
function alertMessage(message) {
  let alert = app.querySelector('[role="alert"]');
  if (!alert) {
    alert = element('p', '', { role: 'alert' });
    app.append(alert);
  }
  alert.textContent = message;
}
function projectRow(project, onUpdate) {
  const row = element('div', '', { 'data-testid': 'project-row', class: 'project-row' });
  const open = element('button', 'Open project', { type: 'button' });
  open.addEventListener('click', () => { window.location.href = `/projects/${project.id}`; });
  const archive = element('button', project.archived ? 'Restore project' : 'Archive project', { type: 'button' });
  archive.addEventListener('click', async () => {
    archive.disabled = true;
    try {
      const saved = await request(`/api/projects/${project.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archived: !project.archived }),
      });
      onUpdate(saved);
      app.querySelector('[role="alert"]')?.remove();
    } catch (error) { alertMessage(error.message); }
    finally { archive.disabled = false; }
  });
  row.append(element('span', project.name),
    element('span', `${project.completed}/${project.total} completed`, { 'data-testid': 'project-summary' }),
    open, archive);
  return row;
}
function renderRename(project, heading) {
  const form = element('form');
  const input = element('input', '', { id: 'new-project-name', type: 'text', autocomplete: 'off' });
  const rename = element('button', 'Rename project', { type: 'submit' });
  input.value = project.name;
  input.disabled = Boolean(project.archived);
  rename.disabled = Boolean(project.archived);
  form.append(element('label', 'New project name', { for: 'new-project-name' }), input, rename);
  app.append(form);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (project.archived) return;
    const name = input.value.trim();
    if (!name) { alertMessage('Project name is required'); return; }
    rename.disabled = true;
    try {
      const saved = await request(`/api/projects/${project.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      project.name = saved.name;
      heading.textContent = saved.name;
      document.title = `${saved.name} — Workboard`;
      input.value = saved.name;
      app.querySelector('[role="alert"]')?.remove();
    } catch (error) { alertMessage(error.message); }
    finally { rename.disabled = Boolean(project.archived); }
  });
}
function matchesSearch(value, query) {
  const fold = text => text.replace(/[ \t]+/g, ' ').replace(/[A-Z]/g, letter => letter.toLowerCase());
  return fold(value).includes(fold(query));
}
function searchForm(label, buttonLabel, id, onApply) {
  const form = element('form');
  const input = element('input', '', { id, type: 'text', autocomplete: 'off' });
  form.append(element('label', label, { for: id }), input,
    element('button', buttonLabel, { type: 'submit' }));
  form.addEventListener('submit', event => {
    event.preventDefault();
    input.value = input.value.trim();
    onApply(input.value);
  });
  return form;
}
function validDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return year >= 1 && month >= 1 && month <= 12 && day >= 1 && day <= days[month - 1];
}
async function renderTasks(project) {
  const path = `/api/projects/${project.id}/tasks`;
  const archived = Boolean(project.archived);
  let tasks = [];
  let destinations = [];
  const defaultPriority = element('select', '', { id: 'default-task-priority' });
  for (const value of ['Low', 'Normal', 'High']) defaultPriority.append(element('option', value, { value }));
  defaultPriority.value = project.default_priority;
  defaultPriority.disabled = archived;
  const defaults = element('div', '', { class: 'task-filters' });
  defaults.append(element('label', 'Default task priority', { for: defaultPriority.id }), defaultPriority);
  app.append(defaults);
  defaultPriority.addEventListener('change', async () => {
    if (archived) return;
    defaultPriority.disabled = true;
    try {
      const saved = await request(`/api/projects/${project.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ default_priority: defaultPriority.value }),
      });
      project.default_priority = saved.default_priority;
      app.querySelector('[role="alert"]')?.remove();
    } catch (error) { alertMessage(error.message); }
    finally {
      defaultPriority.value = project.default_priority;
      defaultPriority.disabled = archived;
    }
  });
  const form = element('form');
  const input = element('input', '', { id: 'task-title', type: 'text', autocomplete: 'off' });
  const create = element('button', 'Create task', { type: 'submit' });
  form.append(element('label', 'Task title', { for: 'task-title' }), input, create);
  const filter = element('select', '', { id: 'task-filter' });
  for (const value of ['All', 'Open', 'Completed']) filter.append(element('option', value, { value }));
  const priorityFilter = element('select', '', { id: 'priority-filter' });
  for (const value of ['All', 'Low', 'Normal', 'High']) priorityFilter.append(element('option', value, { value }));
  const filters = element('div', '', { class: 'task-filters' });
  filters.append(element('label', 'Task filter', { for: 'task-filter' }), filter,
    element('label', 'Priority filter', { for: 'priority-filter' }), priorityFilter);
  const list = element('section', '', { 'aria-label': 'Tasks' });
  const rangeForm = element('form');
  const dueFrom = element('input', '', { id: 'due-from', type: 'text', autocomplete: 'off' });
  const dueThrough = element('input', '', { id: 'due-through', type: 'text', autocomplete: 'off' });
  const applyRange = element('button', 'Apply due range', { type: 'submit' });
  let appliedFrom = '';
  let appliedThrough = '';
  rangeForm.append(element('label', 'Due from', { for: dueFrom.id }), dueFrom,
    element('label', 'Due through', { for: dueThrough.id }), dueThrough, applyRange);
  rangeForm.addEventListener('submit', event => {
    event.preventDefault();
    const from = dueFrom.value.trim();
    const through = dueThrough.value.trim();
    if ((from && !validDate(from)) || (through && !validDate(through))) {
      alertMessage('Due range must use valid YYYY-MM-DD dates');
      return;
    }
    if (from && through && from > through) {
      alertMessage('Due from must not be after Due through');
      return;
    }
    appliedFrom = from;
    appliedThrough = through;
    dueFrom.value = from;
    dueThrough.value = through;
    app.querySelector('[role="alert"]')?.remove();
    draw();
  });
  let appliedSearch = '';
  const search = searchForm('Task search', 'Search tasks', 'task-search', query => {
    appliedSearch = query;
    draw();
  });
  app.append(form, filters, rangeForm, search, list);
  function draw() {
    list.replaceChildren();
    for (const task of tasks) {
      if (!matchesSearch(task.title, appliedSearch)) continue;
      if (filter.value === 'Open' && task.completed) continue;
      if (filter.value === 'Completed' && !task.completed) continue;
      if (priorityFilter.value !== 'All' && task.priority !== priorityFilter.value) continue;
      if (appliedFrom || appliedThrough) {
        if (!task.due_date) continue;
        if (appliedFrom && task.due_date < appliedFrom) continue;
        if (appliedThrough && task.due_date > appliedThrough) continue;
      }
      const row = element('div', '', { 'data-testid': 'task-row', class: 'task-row' });
      const checkbox = element('input', '', { type: 'checkbox', 'aria-label': `Complete ${task.title}` });
      checkbox.checked = task.completed;
      checkbox.disabled = archived;
      checkbox.addEventListener('change', async () => {
        checkbox.disabled = true;
        try {
          const saved = await request(`${path}/${task.id}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completed: checkbox.checked }),
          });
          task.completed = saved.completed;
          app.querySelector('[role="alert"]')?.remove();
          draw();
        } catch (error) {
          checkbox.checked = task.completed;
          alertMessage(error.message);
        } finally { checkbox.disabled = false; }
      });
      const title = element('span', task.title);
      const renameForm = element('form');
      const renameInput = element('input', '', { id: `new-task-title-${task.id}`, type: 'text', autocomplete: 'off' });
      const rename = element('button', 'Rename task', { type: 'submit' });
      renameInput.value = task.title;
      renameInput.disabled = archived;
      rename.disabled = archived;
      renameForm.append(element('label', 'New task title', { for: renameInput.id }), renameInput, rename);
      renameForm.addEventListener('submit', async event => {
        event.preventDefault();
        if (archived) return;
        const newTitle = renameInput.value.trim();
        if (!newTitle) { alertMessage('Task title is required'); return; }
        rename.disabled = true;
        try {
          const saved = await request(`${path}/${task.id}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: newTitle }),
          });
          task.title = saved.title;
          title.textContent = saved.title;
          checkbox.setAttribute('aria-label', `Complete ${saved.title}`);
          renameInput.value = saved.title;
          app.querySelector('[role="alert"]')?.remove();
          draw();
        } catch (error) { alertMessage(error.message); }
        finally { rename.disabled = archived; }
      });
      const priority = element('select', '', { id: `task-priority-${task.id}` });
      for (const value of ['Low', 'Normal', 'High']) priority.append(element('option', value, { value }));
      priority.value = task.priority;
      priority.disabled = archived;
      priority.addEventListener('change', async () => {
        priority.disabled = true;
        try {
          const saved = await request(`${path}/${task.id}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ priority: priority.value }),
          });
          task.priority = saved.priority;
          app.querySelector('[role="alert"]')?.remove();
          draw();
        } catch (error) { alertMessage(error.message); }
        finally {
          priority.value = task.priority;
          priority.disabled = archived;
        }
      });
      const dueForm = element('form');
      const dueInput = element('input', '', { id: `task-due-date-${task.id}`, type: 'text', autocomplete: 'off' });
      const saveDue = element('button', 'Save due date', { type: 'submit' });
      dueInput.value = task.due_date || '';
      dueInput.disabled = archived;
      saveDue.disabled = archived;
      dueForm.append(element('label', 'Task due date', { for: dueInput.id }), dueInput, saveDue);
      dueForm.addEventListener('submit', async event => {
        event.preventDefault();
        if (archived) return;
        saveDue.disabled = true;
        try {
          const saved = await request(`${path}/${task.id}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ due_date: dueInput.value }),
          });
          task.due_date = saved.due_date;
          dueInput.value = saved.due_date;
          app.querySelector('[role="alert"]')?.remove();
          draw();
        } catch (error) {
          dueInput.value = task.due_date || '';
          alertMessage(error.message);
        } finally { saveDue.disabled = archived; }
      });
      const notesForm = element('form');
      const notesInput = element('textarea', '', { id: `task-notes-${task.id}`, rows: '4' });
      const saveNotes = element('button', 'Save notes', { type: 'submit' });
      notesInput.value = task.notes || '';
      notesInput.disabled = archived;
      saveNotes.disabled = archived;
      notesForm.append(element('label', 'Task notes', { for: notesInput.id }), notesInput, saveNotes);
      notesForm.addEventListener('submit', async event => {
        event.preventDefault();
        if (archived) return;
        saveNotes.disabled = true;
        try {
          const saved = await request(`${path}/${task.id}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ notes: notesInput.value }),
          });
          task.notes = saved.notes;
          app.querySelector('[role="alert"]')?.remove();
          draw();
        } catch (error) { alertMessage(error.message); }
        finally { saveNotes.disabled = archived; }
      });
      const destination = element('select', '', { id: `destination-project-${task.id}` });
      for (const project of destinations) {
        destination.append(element('option', project.name, { value: String(project.id) }));
      }
      const move = element('button', 'Move task', { type: 'button' });
      destination.disabled = archived || destinations.length === 0;
      move.disabled = destination.disabled;
      move.addEventListener('click', async () => {
        if (archived || !destination.value) return;
        move.disabled = true;
        destination.disabled = true;
        try {
          await request(`${path}/${task.id}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ destination_project_id: Number(destination.value) }),
          });
          tasks = tasks.filter(item => item.id !== task.id);
          app.querySelector('[role="alert"]')?.remove();
          draw();
        } catch (error) { alertMessage(error.message); }
        finally {
          destination.disabled = archived || destinations.length === 0;
          move.disabled = destination.disabled;
        }
      });
      row.append(checkbox, title, renameForm,
        element('label', 'Task priority', { for: priority.id }), priority, dueForm, notesForm,
        element('label', 'Destination project', { for: destination.id }), destination, move);
      list.append(row);
    }
  }
  filter.addEventListener('change', draw);
  priorityFilter.addEventListener('change', draw);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (archived) return;
    const title = input.value.trim();
    if (!title) { alertMessage('Task title is required'); return; }
    create.disabled = true;
    try {
      tasks.push(await request(path, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title }),
      }));
      draw();
      input.value = '';
      app.querySelector('[role="alert"]')?.remove();
      input.focus();
    } catch (error) { alertMessage(error.message); }
    finally { create.disabled = archived; }
  });
  create.disabled = true;
  try {
    const [savedTasks, projects] = await Promise.all([request(path), request('/api/projects')]);
    tasks = savedTasks;
    destinations = projects.filter(item => !item.archived && item.id !== project.id);
    draw();
  }
  catch (error) { alertMessage(error.message); }
  finally { create.disabled = archived; }
}
async function render() {
  const match = window.location.pathname.match(/^\/projects\/(\d+)$/);
  if (match) {
    const back = element('button', 'Projects', { type: 'button', class: 'back' });
    back.addEventListener('click', () => { window.location.href = '/'; });
    app.append(back);
    try {
      const project = await request(`/api/projects/${match[1]}`);
      document.title = `${project.name} — Workboard`;
      const heading = element('h1', project.name);
      app.append(heading);
      if (project.archived) app.append(element('p', 'Archived project'));
      renderRename(project, heading);
      await renderTasks(project);
    } catch (error) { alertMessage(error.message); }
    return;
  }
  app.append(element('h1', 'Workboard'));
  const form = element('form');
  const label = element('label', 'Project name', { for: 'project-name' });
  const input = element('input', '', { id: 'project-name', name: 'name', type: 'text', autocomplete: 'off' });
  const create = element('button', 'Create project', { type: 'submit' });
  form.append(label, input, create);
  const list = element('section', '', { 'aria-label': 'Projects', class: 'projects' });
  const filter = element('select', '', { id: 'project-filter' });
  for (const value of ['Active', 'Archived']) filter.append(element('option', value, { value }));
  const filters = element('div', '', { class: 'task-filters' });
  filters.append(element('label', 'Project filter', { for: 'project-filter' }), filter);
  let projects = [];
  let appliedSearch = '';
  const search = searchForm('Project search', 'Search projects', 'project-search', query => {
    appliedSearch = query;
    drawProjects();
  });
  function drawProjects() {
    list.replaceChildren();
    for (const project of projects) {
      if (!matchesSearch(project.name, appliedSearch)) continue;
      if (Boolean(project.archived) !== (filter.value === 'Archived')) continue;
      list.append(projectRow(project, saved => {
        projects = projects.map(item => item.id === saved.id ? saved : item);
        drawProjects();
      }));
    }
  }
  filter.addEventListener('change', drawProjects);
  app.append(form, filters, search, list);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const name = input.value.trim();
    if (!name) { alertMessage('Project name is required'); return; }
    create.disabled = true;
    try {
      const project = await request('/api/projects', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }),
      });
      projects.push(project);
      drawProjects();
      input.value = '';
      app.querySelector('[role="alert"]')?.remove();
      input.focus();
    } catch (error) { alertMessage(error.message); }
    finally { create.disabled = false; }
  });
  create.disabled = true;
  try {
    projects = await request('/api/projects');
    drawProjects();
  } catch (error) { alertMessage(error.message); }
  finally { create.disabled = false; }
}
render();
