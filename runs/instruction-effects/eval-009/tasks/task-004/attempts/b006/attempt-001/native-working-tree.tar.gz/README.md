# Workboard

Requires Node.js 22.22.1. No dependency installation is needed.

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
```

Open `http://localhost:8080`. The server binds to `0.0.0.0`; `PORT` defaults to
8080 and `DB_PATH` defaults to `./data/workboard.sqlite`. Keep the database file
to preserve projects, archive state, tasks, and completion state across server
restarts. Existing databases are migrated automatically. Each project supports
task creation, completion, and All/Open/Completed filters. The project list has
Active/Archived filters and completion summaries. Archive projects to make their
tasks read-only; restore them from the Archived list to resume editing.
Active project pages also support renaming. Names are trimmed and required;
renaming preserves the project's URL, position, tasks, and completion state.
Archived projects cannot be renamed until restored. Renamed project names
persist in the same SQLite database.
`GET /health` returns
`{"status":"ok"}`.

Run the integration checks, including a server restart using a temporary SQLite
database:

```sh
npm test
```
