const app = document.querySelector('#app');

function element(tag, options = {}) {
  const node = document.createElement(tag);
  if (options.text !== undefined) node.textContent = options.text;
  if (options.testId) node.dataset.testid = options.testId;
  if (options.className) node.className = options.className;
  return node;
}

async function request(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}

async function renderList(archived = false) {
  app.replaceChildren();
  app.append(element('h1', { text: 'Workboard' }));
  const form = element('form', { className: 'create-form' });
  const label = element('label', { text: 'Project name' });
  const input = element('input');
  input.type = 'text'; input.id = 'project-name'; input.autocomplete = 'off'; label.htmlFor = input.id;
  const create = element('button', { text: 'Create project' }); create.type = 'submit';
  const alert = element('p', { className: 'alert' }); alert.setAttribute('role', 'alert'); alert.hidden = true;
  form.append(label, input, create, alert);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    try {
      await request('/api/projects', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: input.value }) });
      await renderList();
    } catch (error) { alert.textContent = error.message; alert.hidden = false; }
  });
  app.append(form);
  const filterLabel = element('label', { text: 'Project filter' }); filterLabel.htmlFor = 'project-filter';
  const filter = element('select'); filter.id = 'project-filter';
  for (const [value, text] of [['false', 'Active'], ['true', 'Archived']]) { const option = element('option', { text }); option.value = value; filter.append(option); }
  filter.value = String(archived);
  filter.addEventListener('change', () => renderList(filter.value === 'true'));
  app.append(filterLabel, filter);
  const list = element('section', { className: 'project-list' });
  for (const project of await request(`/api/projects?archived=${archived}`)) {
    const row = element('article', { testId: 'project-row', className: 'project-row' });
    row.append(element('span', { text: project.name }));
    const summary = element('span', { text: `${project.completedCount}/${project.totalCount} completed`, testId: 'project-summary' });
    row.append(summary);
    const open = element('button', { text: 'Open project' }); open.type = 'button';
    open.addEventListener('click', () => { location.href = `/projects/${project.id}`; });
    row.append(open);
    const archive = element('button', { text: archived ? 'Restore project' : 'Archive project' }); archive.type = 'button';
    archive.addEventListener('click', async () => {
      await request(`/api/projects/${project.id}/archive`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ archived: !archived }) });
      await renderList(archived);
    });
    row.append(archive); list.append(row);
  }
  app.append(list);
}

async function renderProject(id) {
  const project = await request(`/api/projects/${encodeURIComponent(id)}`);
  app.replaceChildren();
  const back = element('button', { text: 'Projects' }); back.type = 'button';
  back.addEventListener('click', () => { location.href = '/'; });
  app.append(back, element('h1', { text: project.name }));
  if (project.archived) app.append(element('p', { text: 'Archived project' }));
  const renameForm = element('form', { className: 'create-form' });
  const renameLabel = element('label', { text: 'New project name' }); renameLabel.htmlFor = 'new-project-name';
  const renameInput = element('input'); renameInput.type = 'text'; renameInput.id = 'new-project-name'; renameInput.value = project.name; renameInput.disabled = Boolean(project.archived);
  const renameButton = element('button', { text: 'Rename project' }); renameButton.type = 'submit'; renameButton.disabled = Boolean(project.archived);
  const renameAlert = element('p', { className: 'alert' }); renameAlert.setAttribute('role', 'alert'); renameAlert.hidden = true;
  renameForm.append(renameLabel, renameInput, renameButton, renameAlert);
  renameForm.addEventListener('submit', async event => {
    event.preventDefault();
    try {
      await request(`/api/projects/${encodeURIComponent(id)}/rename`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: renameInput.value }) });
      await renderProject(id);
    } catch (error) { renameAlert.textContent = error.message; renameAlert.hidden = false; }
  });

  const defaultLabel = element('label', { text: 'Default task priority' }); defaultLabel.htmlFor = 'default-task-priority';
  const defaultPriority = element('select'); defaultPriority.id = defaultLabel.htmlFor;
  for (const value of ['Low', 'Normal', 'High']) { const option = element('option', { text: value }); option.value = value; defaultPriority.append(option); }
  defaultPriority.value = project.defaultPriority;
  defaultPriority.disabled = Boolean(project.archived);
  let defaultPrioritySave = Promise.resolve();
  defaultPriority.addEventListener('change', () => {
    const selectedPriority = defaultPriority.value;
    defaultPrioritySave = defaultPrioritySave
      .then(() => request(`/api/projects/${encodeURIComponent(id)}/default-priority`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ priority: selectedPriority }) }))
      .catch(error => { alert.textContent = error.message; alert.hidden = false; });
  });
  const form = element('form', { className: 'create-form' });
  const label = element('label', { text: 'Task title' });
  const input = element('input'); input.type = 'text'; input.id = 'task-title'; input.autocomplete = 'off'; label.htmlFor = input.id;
  const create = element('button', { text: 'Create task' }); create.type = 'submit'; create.disabled = Boolean(project.archived);
  const alert = element('p', { className: 'alert' }); alert.setAttribute('role', 'alert'); alert.hidden = true;
  form.append(label, input, create, alert);
  const filterLabel = element('label', { text: 'Task filter' }); filterLabel.htmlFor = 'task-filter';
  const filter = element('select'); filter.id = 'task-filter';
  for (const value of ['All', 'Open', 'Completed']) { const option = element('option', { text: value }); option.value = value; filter.append(option); }
  const priorityFilterLabel = element('label', { text: 'Priority filter' }); priorityFilterLabel.htmlFor = 'priority-filter';
  const priorityFilter = element('select'); priorityFilter.id = 'priority-filter';
  for (const value of ['All', 'Low', 'Normal', 'High']) { const option = element('option', { text: value }); option.value = value; priorityFilter.append(option); }
  const list = element('section', { className: 'task-list' });
  async function refreshTasks() {
    list.replaceChildren();
    const tasks = await request(`/api/projects/${encodeURIComponent(id)}/tasks`);
    for (const task of tasks) {
      if (filter.value === 'Open' && task.completed || filter.value === 'Completed' && !task.completed || priorityFilter.value !== 'All' && priorityFilter.value !== task.priority) continue;
      const row = element('article', { testId: 'task-row', className: 'task-row' });
      const checkbox = element('input'); checkbox.type = 'checkbox'; checkbox.checked = Boolean(task.completed);
      checkbox.setAttribute('aria-label', `Complete ${task.title}`); checkbox.disabled = Boolean(project.archived);
      checkbox.addEventListener('change', async () => {
        try {
          await request(`/api/projects/${encodeURIComponent(id)}/tasks/${task.id}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ completed: checkbox.checked }) });
          await refreshTasks();
        } catch (error) { alert.textContent = error.message; alert.hidden = false; }
      });
      const priorityLabel = element('label', { text: 'Task priority' });
      const priority = element('select'); priorityLabel.htmlFor = `task-priority-${task.id}`; priority.id = priorityLabel.htmlFor;
      for (const value of ['Low', 'Normal', 'High']) { const option = element('option', { text: value }); option.value = value; priority.append(option); }
      priority.value = task.priority;
      priority.disabled = Boolean(project.archived);
      priority.addEventListener('change', async () => {
        try {
          await request(`/api/projects/${encodeURIComponent(id)}/tasks/${task.id}/priority`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ priority: priority.value }) });
          await refreshTasks();
        } catch (error) { alert.textContent = error.message; alert.hidden = false; }
      });
      const renameForm = element('form', { className: 'create-form' });
      const renameLabel = element('label', { text: 'New task title' });
      const renameInput = element('input'); renameInput.type = 'text'; renameInput.value = task.title;
      renameLabel.htmlFor = `new-task-title-${task.id}`; renameInput.id = renameLabel.htmlFor; renameInput.disabled = Boolean(project.archived);
      const renameButton = element('button', { text: 'Rename task' }); renameButton.type = 'submit'; renameButton.disabled = Boolean(project.archived);
      const renameAlert = element('p', { className: 'alert' }); renameAlert.setAttribute('role', 'alert'); renameAlert.hidden = true;
      renameForm.append(renameLabel, renameInput, renameButton, renameAlert);
      renameForm.addEventListener('submit', async event => {
        event.preventDefault();
        try {
          await request(`/api/projects/${encodeURIComponent(id)}/tasks/${task.id}/rename`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ title: renameInput.value }) });
          await refreshTasks();
        } catch (error) { renameAlert.textContent = error.message; renameAlert.hidden = false; }
      });
      const dueForm = element('form', { className: 'create-form' });
      const dueLabel = element('label', { text: 'Task due date' });
      const dueInput = element('input'); dueInput.type = 'text'; dueInput.value = task.dueDate || ''; dueInput.disabled = Boolean(project.archived);
      dueLabel.htmlFor = `task-due-date-${task.id}`; dueInput.id = dueLabel.htmlFor;
      const dueButton = element('button', { text: 'Save due date' }); dueButton.type = 'submit'; dueButton.disabled = Boolean(project.archived);
      dueForm.append(dueLabel, dueInput, dueButton);
      dueForm.addEventListener('submit', async event => {
        event.preventDefault();
        try {
          await request(`/api/projects/${encodeURIComponent(id)}/tasks/${task.id}/due-date`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ dueDate: dueInput.value }) });
          await refreshTasks();
        } catch (error) { alert.textContent = error.message; alert.hidden = false; }
      });
      row.append(checkbox, element('span', { text: task.title }), priorityLabel, priority, renameForm, dueForm); list.append(row);
    }
  }
  form.addEventListener('submit', async event => {
    event.preventDefault();
    try {
      await defaultPrioritySave;
      await request(`/api/projects/${encodeURIComponent(id)}/tasks`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ title: input.value }) });
      await refreshTasks(); input.value = ''; alert.hidden = true;
    } catch (error) { alert.textContent = error.message; alert.hidden = false; }
  });
  filter.addEventListener('change', refreshTasks);
  priorityFilter.addEventListener('change', refreshTasks);
  app.append(renameForm, defaultLabel, defaultPriority, form, filterLabel, filter, priorityFilterLabel, priorityFilter, list);
  await refreshTasks();
}

const match = location.pathname.match(/^\/projects\/(\d+)\/?$/);
if (match) renderProject(match[1]).catch(() => { location.href = '/'; });
else renderList().catch(error => { app.replaceChildren(element('p', { text: error.message, className: 'alert' })); });
