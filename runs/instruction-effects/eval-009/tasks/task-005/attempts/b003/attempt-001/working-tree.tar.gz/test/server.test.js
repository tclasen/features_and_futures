import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';

test('projects and scoped tasks are validated, ordered, and persisted across restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-test-'));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const base = `http://127.0.0.1:${port}`;
  // Start with the prior schema to exercise an in-place migration.
  const legacy = new DatabaseSync(join(directory, 'projects.sqlite'));
  legacy.exec('CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)');
  legacy.close();
  let child;
  async function start() {
    child = spawn(process.execPath, ['server.js'], {
      env: { ...process.env, PORT: String(port), DB_PATH: join(directory, 'projects.sqlite') },
      stdio: ['ignore', 'ignore', 'inherit'],
    });
    for (let attempt = 0; attempt < 100; attempt++) {
      try { if ((await fetch(`${base}/health`)).ok) return; } catch {}
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    throw new Error('Server did not become healthy');
  }
  async function stop() {
    const exited = once(child, 'exit');
    child.kill('SIGTERM');
    await exited;
    child = undefined;
  }
  async function create(name) {
    return fetch(`${base}/api/projects`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }),
    });
  }
  try {
    await start();
    const health = await fetch(`${base}/health`);
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { status: 'ok' });
    const invalid = await create('   ');
    assert.equal(invalid.status, 400);
    assert.match((await invalid.json()).error, /Project name is required/);
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), []);
    const firstResponse = await create('  First project  ');
    assert.equal(firstResponse.status, 201);
    const first = await firstResponse.json();
    assert.equal(first.name, 'First project');
    assert.equal(first.archived, 0);
    assert.equal(first.total, 0);
    assert.equal(first.completed, 0);
    const second = await (await create('Second project')).json();
    assert.notEqual(first.id, second.id);
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), [first, second]);
    assert.equal((await fetch(`${base}/projects/${first.id}`)).status, 200);
    assert.match(await (await fetch(base)).text(), /id="app"/);
    const taskPath = `${base}/api/projects/${first.id}/tasks`;
    async function addTask(title) {
      return fetch(taskPath, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title }),
      });
    }
    async function complete(projectId, taskId, completed) {
      return fetch(`${base}/api/projects/${projectId}/tasks/${taskId}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ completed }),
      });
    }
    const blankTask = await addTask(' \t ');
    assert.equal(blankTask.status, 400);
    assert.match((await blankTask.json()).error, /Task title is required/);
    assert.deepEqual(await (await fetch(taskPath)).json(), []);
    const taskResponse = await addTask('  First task  ');
    assert.equal(taskResponse.status, 201);
    const task = await taskResponse.json();
    assert.equal(task.title, 'First task');
    assert.equal(task.completed, false);
    assert.equal(task.project_id, first.id);
    const secondTask = await (await addTask('Second task')).json();
    assert.deepEqual(await (await fetch(taskPath)).json(), [task, secondTask]);
    assert.deepEqual(await (await fetch(`${base}/api/projects/${second.id}/tasks`)).json(), []);
    assert.equal((await complete(second.id, task.id, true)).status, 404);
    assert.equal((await complete(first.id, task.id, 'true')).status, 400);
    assert.equal((await complete(first.id, task.id, true)).status, 200);
    task.completed = true;
    assert.deepEqual(await (await fetch(taskPath)).json(), [task, secondTask]);
    async function renameTask(projectId, taskId, title) {
      return fetch(`${base}/api/projects/${projectId}/tasks/${taskId}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title }),
      });
    }
    const blankRename = await renameTask(first.id, task.id, ' \t ');
    assert.equal(blankRename.status, 400);
    assert.match((await blankRename.json()).error, /Task title is required/);
    assert.deepEqual(await (await fetch(taskPath)).json(), [task, secondTask]);
    assert.equal((await renameTask(second.id, task.id, 'Wrong project')).status, 404);
    const renamedTask = await renameTask(first.id, task.id, '  Renamed task  ');
    assert.equal(renamedTask.status, 200);
    task.title = 'Renamed task';
    assert.deepEqual(await renamedTask.json(), task);
    assert.deepEqual(await (await fetch(taskPath)).json(), [task, secondTask]);
    first.total = 2;
    first.completed = 1;
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), [first, second]);
    async function rename(name) {
      return fetch(`${base}/api/projects/${first.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }),
      });
    }
    const invalidRename = await rename(' \t ');
    assert.equal(invalidRename.status, 400);
    assert.match((await invalidRename.json()).error, /Project name is required/);
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    const renamed = await rename('  Renamed project  ');
    assert.equal(renamed.status, 200);
    first.name = 'Renamed project';
    assert.deepEqual(await renamed.json(), first);
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), [first, second]);
    assert.deepEqual(await (await fetch(taskPath)).json(), [task, secondTask]);
    async function archive(archived) {
      return fetch(`${base}/api/projects/${first.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ archived }),
      });
    }
    assert.equal((await archive('true')).status, 400);
    assert.equal((await archive(true)).status, 200);
    first.archived = 1;
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    assert.equal((await rename('Forbidden rename')).status, 409);
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    assert.equal((await renameTask(first.id, task.id, 'Forbidden title')).status, 409);
    assert.equal((await addTask('Forbidden')).status, 409);
    assert.equal((await complete(first.id, task.id, false)).status, 409);
    assert.deepEqual(await (await fetch(taskPath)).json(), [task, secondTask]);
    await stop();
    await start();
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), [first, second]);
    assert.equal((await fetch(`${base}/projects/${first.id}`)).status, 200);
    assert.deepEqual(await (await fetch(taskPath)).json(), [task, secondTask]);
    assert.equal((await archive(false)).status, 200);
    first.archived = 0;
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    assert.equal((await rename(' Restored project ')).status, 200);
    first.name = 'Restored project';
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    const restoredRename = await renameTask(first.id, task.id, ' Restored task ');
    assert.equal(restoredRename.status, 200);
    task.title = 'Restored task';
    assert.deepEqual(await restoredRename.json(), task);
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    const reopened = await complete(first.id, task.id, false);
    assert.equal((await reopened.json()).completed, false);
    task.completed = false;
    first.completed = 0;
    await stop();
    await start();
    assert.deepEqual(await (await fetch(taskPath)).json(), [task, secondTask]);
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), [first, second]);
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    assert.equal((await fetch(`${base}/api/projects/999999`)).status, 404);
  } finally {
    if (child) await stop();
    await rm(directory, { recursive: true, force: true });
  }
});
