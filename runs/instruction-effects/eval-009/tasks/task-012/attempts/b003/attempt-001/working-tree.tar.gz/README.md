# Workboard

Requires Node.js 22.22.1; no external dependencies.

## Run

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
```

Open http://localhost:8080. The server binds to `0.0.0.0`. Defaults are port 8080 and `./data/workboard.sqlite`. Use the same database path across restarts to retain projects, archive state, tasks, and completion state.

`GET /health` returns `{"status":"ok"}`.

## Verify

```sh
npm test
```

Project pages let you create tasks, toggle completion, and filter by All, Open, or Completed. Tasks stay within their project.

The project list filters Active or Archived projects and shows completion summaries. Archive/restore preserves tasks; archived project pages are read-only but still support task filtering.

Active project pages also support renaming. Names are trimmed and required; renaming preserves the project's URL, list position, tasks, and completion summary. Archived projects cannot be renamed until restored.

Each task row supports renaming its title. Titles are trimmed and required; renaming preserves ownership, order, completion, and summary counts. Archived projects disable task renaming until restored. Task titles persist across restarts.

Each task has a Task priority selector with Low, Normal, and High options. Existing tasks default to Normal on migration; new tasks inherit their project's saved default. Priorities persist independently across renaming and restarts; archived projects disable priority editing until restored.

Project pages also have a Priority filter with All, Low, Normal, and High options. Both filters start at All and combine to show matching tasks in creation order. Editing completion or priority immediately re-evaluates the rows without resetting either filter; renaming preserves selections. Both filters remain usable for archived projects and never change saved data or summary counts.

Each project has a Default task priority selector with Low, Normal, and High options, initially Normal. Changes persist independently per project and affect only subsequently created tasks. Existing tasks and both filter selections remain unchanged. Archived projects display the saved default but disable editing until restored.

Each task has a Task due date textbox and Save due date button. Empty or whitespace-only input clears the date; otherwise dates must be real Gregorian calendar days in YYYY-MM-DD format (years 0001–9999). Dates are trimmed and stored without timezone conversion. Invalid input displays an alert without changing saved data. Dates persist independently across renaming, reloads, and restarts; archived projects disable both controls until restored. Saving dates preserves filter selections and summary counts, and re-evaluates visible rows against the applied due range.

Project pages have Due from and Due through textboxes and an Apply due range button. Trimmed, valid calendar dates set inclusive bounds; a blank boundary is unbounded. Any bound excludes undated tasks, while two blank bounds include them. Invalid dates or reversed ranges display an alert and retain the last applied range. The range intersects completion and priority filters without resetting them, and remains applied across edits and task creation. All range controls work on archived projects. Reopening a project starts with blank bounds.

Each task row has a Destination project selector listing other active projects in project creation order and a Move task button. First-time moves append tasks after all positions already established in the destination. Returning tasks recover their remembered position relative to that project's other tasks, even when tasks return in a different order. Positions are saved independently per project and survive renaming, archival, restoration, and server restarts. Existing tasks retain their current order during migration. Moves preserve identity and current title, completion, priority, and due date. The source stays open with all filters unchanged, and both summaries reflect current ownership. Moves persist across restarts. Archived projects cannot send or receive tasks; controls are disabled when archived or no destinations exist.

The built-in Node tests verify task moves, ordering migration, remembered return positions, reverse-order returns, reserved positions in empty projects, inclusive due ranges, invalid-range retention, combined filtering and live edit membership, due-date validation and persistence, project defaults, health, validation and trimming, creation order, project isolation, completion summaries, archive/restore, renaming, priorities, read-only enforcement, migration from the prior schema, and SQLite persistence across server restarts. A dependency-free DOM harness exercises the browser code's combined filters and edit handlers. Tests use temporary databases outside the repository.
