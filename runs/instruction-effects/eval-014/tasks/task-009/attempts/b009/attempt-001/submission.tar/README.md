# Workboard

Requires Node.js 22.22.1. Uses built-in HTTP and SQLite with no external dependencies.

Start the application:

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
```

Open `http://localhost:8080`. Both variables are optional and default to the values above. The server binds to `0.0.0.0`. SQLite stores projects, tasks, completion state, and archive state across restarts. Existing databases migrate automatically. Open a project to create tasks, toggle completion, or filter by All, Open, and Completed. Use the Project filter to view Active or Archived projects. Archive or restore a project from its row; archived project tasks remain readable and filterable, with editing disabled. Each row shows completed and total task counts. `GET /health` returns `{"status":"ok"}`.

Run the integration checks:

```sh
npm test
```

On an active project page, enter a New project name and select Rename project. Names are trimmed and saved without changing the project URL, creation order, tasks, or completion counts. Blank names show an alert. Archived projects cannot be renamed until restored.

Each task row provides New task title and Rename task controls. Task titles are trimmed and saved while preserving ownership, creation order, completion state, filter membership, and completion counts. Blank titles show an alert. Archived projects disable task renaming until restored.

Each task row also has a Task priority selector with Low, Normal, and High options. Existing tasks default to Normal during migration. Priority changes save independently without changing task order, completion, or summaries; renaming preserves priority. Archived projects disable priority editing until restored. Priorities persist across reloads and server restarts.

Each project has a Default task priority selector with Low, Normal, and High options, initially Normal. New tasks inherit the project's saved default. Changing it preserves existing tasks and both task filter selections. Defaults are independent per project and persist through renaming, restarts, archival, and restoration. Archived projects display the saved default with editing disabled.

Each task has a Task due date textbox and Save due date button. Dates are optional; blank input clears them. Nonempty input is trimmed and must be a real Gregorian date in YYYY-MM-DD format, with a year from 0001 through 9999. Invalid dates show an alert and leave the saved date unchanged. Dates persist without timezone conversion, independently of other task data and both filter selections. Archived projects disable due-date editing until restored.

Tests start isolated server processes and remove their temporary database directories after checking validation, creation order, navigation, task filters, project isolation, and restart persistence for both completed and open tasks, database migration, archive/restore, editing protection, completion summaries, and project and task renaming with preserved identity.
