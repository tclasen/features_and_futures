# Workboard

Requires Node.js 22.22.1. Uses built-in HTTP and SQLite with no external dependencies.

Start the application:

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
```

Open `http://localhost:8080`. Both variables are optional and default to the values above. The server binds to `0.0.0.0`. SQLite stores projects, tasks, completion state, and archive state across restarts. Existing databases migrate automatically. Open a project to create tasks, toggle completion, or filter by All, Open, Completed, and Deleted. Use the Project filter to view Active or Archived projects. Archive or restore a project from its row; archived project tasks remain readable and filterable, with editing disabled. Each row shows completed and total task counts. `GET /health` returns `{"status":"ok"}`.

Run the integration checks:

```sh
npm test
```

On an active project page, enter a New project name and select Rename project. Names are trimmed and saved without changing the project URL, creation order, tasks, or completion counts. Blank names show an alert. Archived projects cannot be renamed until restored.

Each task row provides New task title and Rename task controls. Task titles are trimmed and saved while preserving ownership, creation order, completion state, filter membership, and completion counts. Blank titles show an alert. Archived projects disable task renaming until restored.

Each task row also has a Task priority selector with Low, Normal, and High options. Existing tasks default to Normal during migration. Priority changes save independently without changing task order, completion, or summaries; renaming preserves priority. Archived projects disable priority editing until restored. Priorities persist across reloads and server restarts.

Each project has a Default task priority selector with Low, Normal, and High options, initially Normal. New tasks inherit the project's saved default. Changing it preserves existing tasks and both task filter selections. Defaults are independent per project and persist through renaming, restarts, archival, and restoration. Archived projects display the saved default with editing disabled.

Each task has a Task due date textbox and Save due date button. Dates are optional; blank input clears them. Nonempty input is trimmed and must be a real Gregorian date in YYYY-MM-DD format, with a year from 0001 through 9999. Invalid dates show an alert and leave the saved date unchanged. Dates persist without timezone conversion, independently of other task data and both filter selections. Archived projects disable due-date editing until restored.

Each project page provides Due from and Due through textboxes and Apply due range. Boundaries are inclusive, optional, trimmed, and validated using the same calendar rules as task due dates. Any nonblank boundary excludes undated tasks. The applied range intersects completion and priority filters, retains their selections, and remains applied through edits and validation errors. Invalid or reversed ranges show an alert and preserve the previous membership. Range controls remain usable when archived. Opening a project from the list resets all task filters and range boundaries. Filtering never changes saved tasks or all-task completion summaries.

Each task row has a Destination project selector and Move task button. Destinations are active projects other than the current project, listed by project creation order using their current names. A first-time move appends the task after all positions already established in the destination. Returning to a previous project restores its remembered position relative to other tasks, even when multiple tasks return in a different order. Each project's position history persists independently, while the task keeps its current ID, title, completion, priority, and due date. The source stays open with its filters and due range retained; both projects' summaries reflect their current tasks. Archived projects cannot send or receive tasks. Moving is disabled when no eligible destination exists. Saved task order migrates automatically and persists through repeated moves and restarts.

Tests start isolated server processes and remove their temporary database directories after checking validation, creation order, navigation, task filters, project isolation, restart persistence, database migration, archive/restore, editing protection, completion summaries, renaming, and moves with preserved task data, first-time append order, and remembered return positions across projects and restarts.

Project search and Search projects match a trimmed substring of project names, ignoring ASCII letter case and treating runs of spaces and tabs as a single space. Search intersects the Active/Archived filter, and changing that filter retains the applied query. Opening the list or returning via Projects starts with an empty query.

Task search and Search tasks use the same matching rules and intersect completion, priority, and applied due-range filters. Search, filter changes, task edits, creation, movement, project renaming, and default-priority changes retain the other applied view settings and re-evaluate matching rows without changing saved task data or summaries. Task search remains usable in archived projects. Opening a project from the list resets its search. Integration checks cover search matching, filter intersections, edit retention, archive restrictions, saved data, and remembered movement order across restart.

Each task row has a multiline Task notes textarea and Save notes button. Notes save as plain text without trimming, preserving spaces, line breaks, Unicode, and literal markup. Empty text clears them. Existing databases initialize only the new notes field to empty. Notes persist across reloads and restarts and travel with tasks through moves and remembered return positions. Saving notes retains all applied filters and search settings; searches still match only project names or task titles. Archived projects show saved notes with both notes controls disabled until restoration.

Live task rows provide Delete task; the Deleted task filter shows saved deleted tasks with Restore task. Deleted tasks are excluded from live filters and completion summaries. Deletion retains every saved field and remembered project position, and restoration returns the task to its reserved position. All other deleted-task controls are disabled, and archived projects also disable deletion and restoration. The Deleted filter intersects priority, due range, and title search. Deletion and restoration retain the applied view and persist through restarts; existing tasks migrate as live.

Every project page provides Download project, including archived and empty projects. It downloads UTF-8 `workboard-project.json` with format `workboard-project`, version 1, and the project's current name, archive state, default priority, and all live and deleted tasks in stored order. Task fields include title, completion, explicit priority, due date, notes, and deletion state. Notes line endings are represented as LF in the export; stored notes remain unchanged. Downloading ignores page filters and searches and preserves all saved data, remembered task positions, and the current view.

The home page provides Project JSON, Imported project name, and Import project. Import validates every required version 1 field and Gregorian date before writing anything, then creates a separate project and tasks in one transaction and opens it. The trimmed override name is required; rejected imports show an alert, retain both submitted fields, and leave all saved data unchanged. Imported titles remain exact, notes use LF line endings, and archive/deletion states, priorities, dates, completion, and task order persist independently of the original project. Extra properties cannot supply internal IDs or positions. Imported tasks participate in the existing move/return-position rules.

Task directory on the home page opens `/directory`, a view across projects with read-only result rows. Project scope (Active/Archived), Task filter (All/Open/Completed/Deleted), Priority filter, Directory search, and inclusive due ranges intersect while retaining each other's settings. Search matches only task titles using the existing normalization rules. Results show original titles, owner names, completion, priority, due dates, and literal multiline notes in project creation order and saved task order. Open project starts the owner's detail page with its usual default filters. Projects returns home; each fresh directory opening resets its filters, search, and range. Viewing and filtering never changes saved data, including archived and deleted tasks.

Complete visible tasks and Reopen visible tasks save completion for all matching live tasks across active projects in one transaction. Both retain the current directory settings and refresh matching rows; summaries reflect the saved state. Each action is disabled when no visible task needs that change, and both are disabled for Archived scope or Deleted tasks. Other task fields, ownership, and remembered ordering remain unchanged across moves and restarts. Empty resolved results show No matching tasks; this announcement is hidden while a directory form update is loading.

Directory order offers Original, Priority, Due date, and Title, starting at Original on each fresh opening. Priority sorts High before Normal before Low; Due date sorts ascending with undated tasks last; Title sorts literal titles by Unicode code point after folding only ASCII uppercase letters. Equal keys retain original owner/task order. Ordering spans the entire filtered result, including archived and deleted views, and remains selected through search, filter, range, and bulk completion actions. It changes only presentation: project task order, exports, saved fields, and remembered return positions remain intact.
