import test from 'node:test';
import assert from 'node:assert/strict';
import { runInNewContext } from 'node:vm';
import { renderProject } from '../views.js';

const project = { id: 'project', name: 'Range intersections', default_task_priority: 'Normal', archived: false };
const task = { id: 'task', title: 'Range completed', completed: true, priority: 'High', due_date: '2029-01-15', notes: '', deleted: false };

function completionPage() {
  return renderProject(project, [task], 'Completed', '', 'High', { from: '2029-01-01', through: '2029-01-31' });
}

const flush = () => new Promise((resolve) => setImmediate(resolve));

function browserHarness() {
  const timers = new Map();
  const requests = [];
  const navigations = [];
  const submissions = [];
  const alerts = [];
  let onSubmit;
  let nextTimer = 0;
  const context = {
    URLSearchParams,
    FormData: class {
      constructor(form) { this.fields = Object.entries(form.fields); }
      [Symbol.iterator]() { return this.fields[Symbol.iterator](); }
    },
    fetch(action, options) {
      return new Promise((resolve) => requests.push({ action, options, resolve }));
    },
    HTMLFormElement: { prototype: { submit() { submissions.push(this.action); } } },
    document: {
      addEventListener(type, listener) { assert.equal(type, 'submit'); onSubmit = listener; },
      createElement() { return { setAttribute() {} }; },
      querySelector(selector) {
        if (selector === '.tasks') return null;
        return { prepend(alert) { alerts.push(alert.textContent); } };
      },
    },
    window: { location: { assign(url) { navigations.push(url); } } },
    setTimeout(callback, delay) {
      assert.equal(delay, 150);
      timers.set(++nextTimer, callback);
      return nextTimer;
    },
    clearTimeout(timer) { timers.delete(timer); },
  };
  runInNewContext(completionPage().match(/<script>([\s\S]*?)<\/script>/)[1], context);
  return {
    context, timers, requests, navigations, submissions, alerts,
    submit(form, expectedPrevention = true) {
      let prevented = false;
      const event = { target: form, preventDefault() { prevented = true; } };
      const result = onSubmit(event);
      // The asynchronous handler must not rely on the dispatched event later.
      event.target = null;
      assert.equal(prevented, expectedPrevention);
      return result;
    },
    resolve(index = 0, ok = true) { requests[index].resolve({ ok, json: async () => ({ status: 'ok' }) }); },
    runTimer() {
      const [id, callback] = [...timers.entries()][0];
      timers.delete(id);
      return callback();
    },
  };
}

function completionForm(completed = '1') {
  return {
    action: '/projects/project/tasks/task',
    fields: { completed, filter: 'Completed', priorityFilter: 'High' },
    removed: false,
    closest(selector) {
      assert.equal(selector, '.task');
      return { remove: () => { this.removed = true; } };
    },
  };
}

test('completion saves immediately without delayed navigation that can abort a reload', async () => {
  const browser = browserHarness();
  browser.context.deferCompletionSubmit(completionForm());
  assert.deepEqual(browser.navigations, []);
  await flush();
  assert.equal(browser.requests[0].options.body.get('completed'), '1');
  browser.resolve();
  await flush();
  assert.deepEqual(browser.navigations, []);
  await browser.runTimer();
  assert.deepEqual(browser.navigations, []);
  assert.equal(browser.requests[0].options.keepalive, true);

  const html = completionPage();
  assert.match(html, /aria-label="Complete Range completed"[^>]*onchange="deferCompletionSubmit\(this.form\)"/);
  const form = html.match(/<form method="post" action="\/projects\/project\/tasks\/task">([\s\S]*?)<\/form>/)[1];
  for (const [name, value] of Object.entries({ filter: 'Completed', priorityFilter: 'High', dueFrom: '2029-01-01', dueThrough: '2029-01-31' })) {
    assert.ok(form.includes(`name="${name}" value="${value}"`));
  }
});

test('completion refresh removes only rows leaving the current filter without navigation', async () => {
  for (const [filter, completed, removed] of [
    ['Completed', '', true], ['Completed', '1', false],
    ['Open', '1', true], ['Open', '', false], ['All', '1', false],
  ]) {
    const browser = browserHarness();
    const form = completionForm(completed);
    form.fields.filter = filter;
    browser.context.deferCompletionSubmit(form);
    await flush();
    assert.equal(form.removed, false);
    browser.resolve();
    await browser.runTimer();
    assert.equal(form.removed, removed);
    assert.deepEqual(browser.navigations, []);
  }
});

test('refresh waits for every queued task save and uses the latest toggle for each row', async () => {
  const browser = browserHarness();
  const first = completionForm('');
  const second = completionForm('');
  browser.context.deferCompletionSubmit(first);
  browser.context.deferCompletionSubmit(second);
  first.fields.completed = '1';
  browser.context.deferCompletionSubmit(first);
  await flush();
  const refreshing = browser.runTimer();
  browser.resolve(0);
  await flush();
  browser.resolve(1);
  await flush();
  assert.equal(second.removed, false);
  browser.resolve(2);
  await refreshing;
  assert.equal(first.removed, false);
  assert.equal(second.removed, true);
  assert.deepEqual(browser.navigations, []);
});

test('quick deletion, edits, filters and export wait for completion to be saved', async () => {
  for (const action of ['tasks/task/delete', 'tasks/task/priority', 'tasks/task/notes', 'export', '']) {
    const browser = browserHarness();
    browser.context.deferCompletionSubmit(completionForm());
    const nextAction = `/projects/project/${action}`;
    const submitting = browser.submit({ action: nextAction });
    await flush();
    assert.deepEqual(browser.submissions, [], 'later action must not overtake completion');
    assert.equal(browser.timers.size, 0, 'later action cancels delayed row refresh');
    browser.resolve();
    await submitting;
    assert.deepEqual(browser.submissions, [nextAction]);
    assert.deepEqual(browser.navigations, []);
  }
});

test('a later form also wins while row refresh is already waiting for its response', async () => {
  const browser = browserHarness();
  browser.context.deferCompletionSubmit(completionForm());
  await flush();
  const navigation = browser.runTimer();
  const deletion = browser.submit({ action: '/projects/project/tasks/task/delete' });
  browser.resolve();
  await Promise.all([navigation, deletion]);
  assert.deepEqual(browser.navigations, []);
  assert.deepEqual(browser.submissions, ['/projects/project/tasks/task/delete']);
});

test('rapid toggles save snapshots sequentially and later actions wait for the final state', async () => {
  const browser = browserHarness();
  const form = completionForm('1');
  browser.context.deferCompletionSubmit(form);
  form.fields.completed = '';
  browser.context.deferCompletionSubmit(form);
  assert.equal(browser.timers.size, 1);
  const deletion = browser.submit({ action: '/projects/project/tasks/task/delete' });
  await flush();
  assert.equal(browser.requests.length, 1);
  assert.equal(browser.requests[0].options.body.get('completed'), '1');
  browser.resolve();
  await flush();
  assert.equal(browser.requests.length, 2);
  assert.equal(browser.requests[1].options.body.get('completed'), '');
  assert.deepEqual(browser.submissions, []);
  browser.resolve(1);
  await deletion;
  assert.equal(browser.submissions.length, 1);
});

test('failed completion saves show an alert and do not permit a later action', async () => {
  const browser = browserHarness();
  browser.context.deferCompletionSubmit(completionForm());
  const deletion = browser.submit({ action: '/projects/project/tasks/task/delete' });
  await flush();
  browser.resolve(0, false);
  await deletion;
  assert.deepEqual(browser.submissions, []);
  assert.equal(browser.alerts.length, 1);
  assert.match(browser.alerts[0], /Could not save task completion/);
});

test('settled completion saves release later native navigation and editing forms', async () => {
  const browser = browserHarness();
  browser.context.deferCompletionSubmit(completionForm());
  await flush();
  assert.equal(browser.requests[0].options.headers.Accept, 'application/json');
  browser.resolve();
  await browser.runTimer();
  for (const action of ['/', '/projects/project?filter=Open', '/projects/project/tasks/task/priority']) {
    await browser.submit({ action }, false);
  }
  assert.deepEqual(browser.submissions, [], 'native submits need no asynchronous interception once saved');
});

test('archived and deleted completion checkboxes remain disabled', () => {
  for (const [owner, record] of [[{ ...project, archived: true }, task], [project, { ...task, deleted: true }]]) {
    assert.match(renderProject(owner, [record]), /type="checkbox"[^>]* disabled[^>]*onchange="deferCompletionSubmit\(this.form\)"/);
  }
});
