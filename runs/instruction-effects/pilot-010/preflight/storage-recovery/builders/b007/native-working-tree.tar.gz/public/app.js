const heading = document.querySelector('#heading');
const alert = document.querySelector('#alert');
const projectList = document.querySelector('#project-list');
const projectDetail = document.querySelector('#project-detail');
const projects = document.querySelector('#projects');
const form = document.querySelector('#create-project');
const nameInput = document.querySelector('#project-name');
const taskForm = document.querySelector('#create-task');
const titleInput = document.querySelector('#task-title');
const taskFilter = document.querySelector('#task-filter');
const taskList = document.querySelector('#tasks');
const projectMatch = window.location.pathname.match(/^\/projects\/([1-9]\d*)$/);
const tasksPath = projectMatch ? `/api/projects/${projectMatch[1]}/tasks` : null;
let tasks = [];

function showError(message) {
  alert.textContent = message;
  alert.hidden = !message;
}

async function request(path, options) {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Unable to complete request');
  return data;
}

function renderProjects(items) {
  projects.replaceChildren();
  if (!items.length) {
    const empty = document.createElement('p');
    empty.textContent = 'No projects yet. Create your first project above.';
    projects.append(empty);
  }
  for (const project of items) {
    const row = document.createElement('div');
    row.dataset.testid = 'project-row';
    row.className = 'project-row';
    const name = document.createElement('span');
    name.textContent = project.name;
    const open = document.createElement('button');
    open.type = 'button';
    open.textContent = 'Open project';
    open.addEventListener('click', () => {
      window.location.assign(`/projects/${project.id}`);
    });
    row.append(name, open);
    projects.append(row);
  }
}

function renderTasks() {
  taskList.replaceChildren();
  const visible = tasks.filter((task) => taskFilter.value === 'all'
    || (taskFilter.value === 'completed' ? task.completed : !task.completed));
  if (!visible.length) {
    const empty = document.createElement('p');
    empty.textContent = 'No tasks match this filter.';
    taskList.append(empty);
  }
  for (const task of visible) {
    const row = document.createElement('div');
    row.dataset.testid = 'task-row';
    row.className = 'task-row';
    const label = document.createElement('label');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = task.completed;
    checkbox.setAttribute('aria-label', `Complete ${task.title}`);
    checkbox.addEventListener('change', async () => {
      showError('');
      checkbox.disabled = true;
      try {
        const updated = await request(`${tasksPath}/${task.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ completed: checkbox.checked }),
        });
        tasks = tasks.map((item) => item.id === updated.id ? updated : item);
        renderTasks();
      } catch (error) {
        checkbox.checked = task.completed;
        showError(error.message);
      } finally {
        checkbox.disabled = false;
      }
    });
    const title = document.createElement('span');
    title.textContent = task.title;
    label.append(checkbox, title);
    row.append(label);
    taskList.append(row);
  }
}

taskFilter.addEventListener('change', renderTasks);
taskForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showError('');
  const title = titleInput.value.trim();
  if (!title) {
    showError('Task title is required');
    titleInput.focus();
    return;
  }
  const submit = taskForm.querySelector('button');
  submit.disabled = true;
  try {
    await request(tasksPath, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    });
    titleInput.value = '';
    tasks = await request(tasksPath);
    renderTasks();
    titleInput.focus();
  } catch (error) {
    showError(error.message);
  } finally {
    submit.disabled = false;
  }
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  showError('');
  const name = nameInput.value.trim();
  if (!name) {
    showError('Project name is required');
    nameInput.focus();
    return;
  }
  const submit = form.querySelector('button');
  submit.disabled = true;
  try {
    await request('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });
    nameInput.value = '';
    renderProjects(await request('/api/projects'));
    nameInput.focus();
  } catch (error) {
    showError(error.message);
  } finally {
    submit.disabled = false;
  }
});

document.querySelector('#back-to-projects').addEventListener('click', () => {
  window.location.assign('/');
});

async function loadPage() {
  const match = projectMatch;
  if (match) {
    projectList.hidden = true;
    projectDetail.hidden = false;
    heading.textContent = 'Project';
    const project = await request(`/api/projects/${match[1]}`);
    heading.textContent = project.name;
    document.title = `${project.name} · Workboard`;
    tasks = await request(tasksPath);
    renderTasks();
  } else {
    renderProjects(await request('/api/projects'));
  }
}

loadPage().catch((error) => showError(error.message));
