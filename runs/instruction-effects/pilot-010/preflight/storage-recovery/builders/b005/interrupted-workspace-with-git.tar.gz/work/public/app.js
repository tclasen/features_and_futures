const heading = document.querySelector('#heading');
const error = document.querySelector('#error');
const list = document.querySelector('#project-list');
const detail = document.querySelector('#project-detail');
const projects = document.querySelector('#projects');
const form = document.querySelector('#create-project');
const nameInput = document.querySelector('#project-name');
const taskForm = document.querySelector('#create-task');
const titleInput = document.querySelector('#task-title');
const taskFilter = document.querySelector('#task-filter');
const taskList = document.querySelector('#tasks');
const projectId = window.location.pathname.match(/^\/projects\/(\d+)$/)?.[1];
let tasks = [];

function showError(message) {
  error.textContent = message;
  error.hidden = !message;
}

async function api(path, options) {
  const response = await fetch(path, options);
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Unable to load projects');
  return result;
}

function renderProjects(items) {
  projects.replaceChildren();
  for (const project of items) {
    const row = document.createElement('div');
    row.dataset.testid = 'project-row';
    row.className = 'project-row';
    const name = document.createElement('span');
    name.textContent = project.name;
    const open = document.createElement('button');
    open.type = 'button';
    open.textContent = 'Open project';
    open.addEventListener('click', () => {
      window.location.assign(`/projects/${project.id}`);
    });
    row.append(name, open);
    projects.append(row);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  showError('');
  const name = nameInput.value.trim();
  if (!name) return showError('Project name is required');
  const submit = form.querySelector('button');
  submit.disabled = true;
  try {
    await api('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });
    renderProjects(await api('/api/projects'));
    nameInput.value = '';
    nameInput.focus();
  } catch (failure) {
    showError(failure.message);
  } finally {
    submit.disabled = false;
  }
});

function renderTasks() {
  taskList.replaceChildren();
  for (const task of tasks) {
    if (taskFilter.value === 'open' && task.completed) continue;
    if (taskFilter.value === 'completed' && !task.completed) continue;
    const row = document.createElement('div');
    row.dataset.testid = 'task-row';
    row.className = 'task-row';
    const title = document.createElement('span');
    title.textContent = task.title;
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = task.completed;
    checkbox.setAttribute('aria-label', `Complete ${task.title}`);
    checkbox.addEventListener('change', async () => {
      showError('');
      checkbox.disabled = true;
      try {
        const updated = await api(`/api/projects/${projectId}/tasks/${task.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ completed: checkbox.checked }),
        });
        tasks = tasks.map((item) => item.id === updated.id ? updated : item);
        renderTasks();
      } catch (failure) {
        checkbox.checked = task.completed;
        showError(failure.message);
      } finally {
        checkbox.disabled = false;
      }
    });
    row.append(title, checkbox);
    taskList.append(row);
  }
}

taskFilter.addEventListener('change', renderTasks);
taskForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showError('');
  const title = titleInput.value.trim();
  if (!title) return showError('Task title is required');
  const submit = taskForm.querySelector('button');
  submit.disabled = true;
  try {
    const task = await api(`/api/projects/${projectId}/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    });
    tasks.push(task);
    renderTasks();
    titleInput.value = '';
    titleInput.focus();
  } catch (failure) {
    showError(failure.message);
  } finally {
    submit.disabled = false;
  }
});

document.querySelector('#back').addEventListener('click', () => window.location.assign('/'));

async function initialize() {
  try {
    if (projectId) {
      const project = await api(`/api/projects/${projectId}`);
      heading.textContent = project.name;
      document.title = `${project.name} — Workboard`;
      tasks = await api(`/api/projects/${projectId}/tasks`);
      renderTasks();
      detail.hidden = false;
    } else {
      list.hidden = false;
      renderProjects(await api('/api/projects'));
    }
  } catch (failure) {
    showError(failure.message);
  }
}
initialize();
