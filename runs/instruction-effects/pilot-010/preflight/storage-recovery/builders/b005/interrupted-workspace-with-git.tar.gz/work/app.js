import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';

const assets = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']],
  ['/styles.css', ['styles.css', 'text/css; charset=utf-8']],
]);

function json(response, status, value) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(value));
}

async function readJson(request) {
  let body = '';
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body) > 16384) {
      throw new Error('Request body is too large');
    }
  }
  return JSON.parse(body);
}

export function createApp(dbPath) {
  mkdirSync(dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec(`CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
  )`);
  db.exec(`PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER NOT NULL REFERENCES projects(id),
      title TEXT NOT NULL,
      completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1))
    );
    CREATE INDEX IF NOT EXISTS tasks_project_id ON tasks(project_id, id)`);
  const listTasks = db.prepare('SELECT id, title, completed FROM tasks WHERE project_id = ? ORDER BY id');
  const findTask = db.prepare('SELECT id, title, completed FROM tasks WHERE project_id = ? AND id = ?');
  const insertTask = db.prepare('INSERT INTO tasks (project_id, title) VALUES (?, ?)');
  const updateTask = db.prepare('UPDATE tasks SET completed = ? WHERE project_id = ? AND id = ?');
  const taskJson = (task) => ({ ...task, completed: Boolean(task.completed) });
  const listProjects = db.prepare('SELECT id, name FROM projects ORDER BY id');
  const findProject = db.prepare('SELECT id, name FROM projects WHERE id = ?');
  const insertProject = db.prepare('INSERT INTO projects (name) VALUES (?)');
  const server = createServer(async (request, response) => {
    try {
      const path = new URL(request.url, 'http://localhost').pathname;
      if (request.method === 'GET' && path === '/health') {
        return json(response, 200, { status: 'ok' });
      }
      if (path === '/api/projects' && request.method === 'GET') {
        return json(response, 200, listProjects.all());
      }
      if (path === '/api/projects' && request.method === 'POST') {
        let input;
        try {
          input = await readJson(request);
        } catch {
          return json(response, 400, { error: 'Invalid JSON request' });
        }
        const name = typeof input?.name === 'string' ? input.name.trim() : '';
        if (!name) return json(response, 400, { error: 'Project name is required' });
        const result = insertProject.run(name);
        return json(response, 201, findProject.get(result.lastInsertRowid));
      }
      const taskMatch = path.match(/^\/api\/projects\/(\d+)\/tasks(?:\/(\d+))?$/);
      if (taskMatch) {
        const [, projectId, taskId] = taskMatch;
        if (!findProject.get(projectId)) {
          return json(response, 404, { error: 'Project not found' });
        }
        if (!taskId && request.method === 'GET') {
          return json(response, 200, listTasks.all(projectId).map(taskJson));
        }
        if ((!taskId && request.method === 'POST') || (taskId && request.method === 'PATCH')) {
          let input;
          try {
            input = await readJson(request);
          } catch {
            return json(response, 400, { error: 'Invalid JSON request' });
          }
          if (!taskId) {
            const title = typeof input?.title === 'string' ? input.title.trim() : '';
            if (!title) return json(response, 400, { error: 'Task title is required' });
            const result = insertTask.run(projectId, title);
            return json(response, 201, taskJson(findTask.get(projectId, result.lastInsertRowid)));
          }
          if (!findTask.get(projectId, taskId)) {
            return json(response, 404, { error: 'Task not found' });
          }
          if (typeof input?.completed !== 'boolean') {
            return json(response, 400, { error: 'Completion must be a boolean' });
          }
          updateTask.run(Number(input.completed), projectId, taskId);
          return json(response, 200, taskJson(findTask.get(projectId, taskId)));
        }
      }
      const match = path.match(/^\/api\/projects\/(\d+)$/);
      if (request.method === 'GET' && match) {
        const project = findProject.get(match[1]);
        return project
          ? json(response, 200, project)
          : json(response, 404, { error: 'Project not found' });
      }
      if (request.method === 'GET') {
        const asset = /^\/projects\/\d+$/.test(path) ? assets.get('/') : assets.get(path);
        if (asset) {
          response.writeHead(200, { 'Content-Type': asset[1] });
          return response.end(readFileSync(new URL(`./public/${asset[0]}`, import.meta.url)));
        }
      }
      json(response, 404, { error: 'Not found' });
    } catch (error) {
      console.error(error);
      if (!response.headersSent) json(response, 500, { error: 'Internal server error' });
      else response.end();
    }
  });
  server.on('close', () => db.close());
  return server;
}
