import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import { resolve } from 'node:path';
import { once } from 'node:events';

test('projects and their tasks validate, remain isolated, and survive server restarts', async () => {
  await mkdir('data', { recursive: true });
  const directory = await mkdtemp(resolve('data/test-'));
  let child;
  async function start() {
    child = spawn(process.execPath, ['server.js'], {
      env: { ...process.env, PORT: '0', DB_PATH: resolve(directory, 'projects.sqlite') },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let output = '';
    const port = await new Promise((resolvePort, reject) => {
      child.on('error', reject);
      child.on('exit', code => reject(new Error(`Server exited: ${code}`)));
      child.stdout.on('data', chunk => {
        output += chunk;
        const match = output.match(/listening on port (\d+)/);
        if (match) resolvePort(match[1]);
      });
    });
    return `http://127.0.0.1:${port}`;
  }
  async function stop() {
    const exited = once(child, 'exit');
    child.kill('SIGTERM');
    await exited;
    child = undefined;
  }
  try {
    let base = await start();
    const health = await fetch(`${base}/health`);
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { status: 'ok' });
    const create = name => fetch(`${base}/api/projects`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });
    const invalid = await create('   ');
    assert.equal(invalid.status, 400);
    assert.deepEqual(await invalid.json(), { error: 'Project name is required' });
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), []);
    const firstResponse = await create('  First project  ');
    assert.equal(firstResponse.status, 201);
    const first = await firstResponse.json();
    assert.equal(first.name, 'First project');
    const second = await (await create('Second project')).json();
    const projects = [first, second];
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), projects);
    assert.equal((await fetch(`${base}/projects/${first.id}`)).status, 200);
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    assert.equal((await fetch(`${base}/api/projects/99999`)).status, 404);
    const taskRequest = (projectId, method = 'GET', body, taskId) => fetch(
      `${base}/api/projects/${projectId}/tasks${taskId === undefined ? '' : `/${taskId}`}`,
      { method, headers: { 'Content-Type': 'application/json' },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }) },
    );
    for (const title of ['', '   ', null]) {
      const invalidTask = await taskRequest(first.id, 'POST', { title });
      assert.equal(invalidTask.status, 400);
      assert.deepEqual(await invalidTask.json(), { error: 'Task title is required' });
    }
    assert.deepEqual(await (await taskRequest(first.id)).json(), []);
    const taskResponse = await taskRequest(first.id, 'POST', { title: '  First task  ' });
    assert.equal(taskResponse.status, 201);
    const task = await taskResponse.json();
    assert.equal(task.title, 'First task');
    assert.equal(task.completed, false);
    assert.equal(task.project_id, first.id);
    const nextTask = await (await taskRequest(first.id, 'POST', { title: 'Second task' })).json();
    const otherTask = await (await taskRequest(second.id, 'POST', { title: 'Other project task' })).json();
    assert.deepEqual(await (await taskRequest(first.id)).json(), [task, nextTask]);
    assert.deepEqual(await (await taskRequest(second.id)).json(), [otherTask]);
    assert.equal((await taskRequest(second.id, 'PATCH', { completed: true }, task.id)).status, 404);
    assert.equal((await taskRequest(99999, 'POST', { title: 'Missing project' })).status, 404);
    assert.equal((await taskRequest(first.id, 'PATCH', { completed: 'true' }, task.id)).status, 400);
    const completedResponse = await taskRequest(first.id, 'PATCH', { completed: true }, task.id);
    assert.equal(completedResponse.status, 200);
    const completedTask = await completedResponse.json();
    assert.deepEqual(completedTask, { ...task, completed: true });
    await stop();
    base = await start();
    assert.deepEqual(await (await fetch(`${base}/api/projects`)).json(), projects);
    assert.deepEqual(await (await fetch(`${base}/api/projects/${first.id}`)).json(), first);
    assert.equal((await fetch(`${base}/projects/${first.id}`)).status, 200);
    assert.deepEqual(await (await taskRequest(first.id)).json(), [completedTask, nextTask]);
    assert.deepEqual(await (await taskRequest(second.id)).json(), [otherTask]);
    const reopened = await taskRequest(first.id, 'PATCH', { completed: false }, task.id);
    assert.deepEqual(await reopened.json(), task);
    await stop();
    base = await start();
    assert.deepEqual(await (await taskRequest(first.id)).json(), [task, nextTask]);
  } finally {
    if (child) await stop();
    await rm(directory, { recursive: true, force: true });
  }
});
