import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const dbPath = process.env.DB_PATH || './data/workboard.sqlite';
if (dbPath !== ':memory:') mkdirSync(dirname(resolve(dbPath)), { recursive: true });
const db = new DatabaseSync(dbPath);
db.exec(`CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL
)`);
db.exec(`PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id),
  title TEXT NOT NULL,
  completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1))
);
CREATE INDEX IF NOT EXISTS tasks_project_id ON tasks(project_id)`);
const page = readFileSync(new URL('./public/index.html', import.meta.url));

function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body));
}

async function readJson(req) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (body.length > 65536) throw new Error('Request too large');
  }
  return JSON.parse(body);
}

const server = http.createServer(async (req, res) => {
  try {
    const path = new URL(req.url, 'http://localhost').pathname;
    if (req.method === 'GET' && path === '/health') {
      return json(res, 200, { status: 'ok' });
    }
    if (req.method === 'GET' && path === '/api/projects') {
      return json(res, 200, db.prepare('SELECT id, name FROM projects ORDER BY id').all());
    }
    if (req.method === 'POST' && path === '/api/projects') {
      let input;
      try { input = await readJson(req); }
      catch { return json(res, 400, { error: 'Invalid JSON request' }); }
      const name = typeof input?.name === 'string' ? input.name.trim() : '';
      if (!name) return json(res, 400, { error: 'Project name is required' });
      const result = db.prepare('INSERT INTO projects (name) VALUES (?)').run(name);
      return json(res, 201, { id: Number(result.lastInsertRowid), name });
    }
    const tasksMatch = path.match(/^\/api\/projects\/(\d+)\/tasks(?:\/(\d+))?$/);
    if (tasksMatch && ['GET', 'POST', 'PATCH'].includes(req.method)) {
      const projectId = tasksMatch[1];
      const taskId = tasksMatch[2];
      if (!db.prepare('SELECT id FROM projects WHERE id = ?').get(projectId)) {
        return json(res, 404, { error: 'Project not found' });
      }
      const asTask = task => ({ ...task, completed: Boolean(task.completed) });
      if (req.method === 'GET' && !taskId) {
        const tasks = db.prepare('SELECT id, title, completed FROM tasks WHERE project_id = ? ORDER BY id').all(projectId);
        return json(res, 200, tasks.map(asTask));
      }
      if ((req.method === 'POST' && !taskId) || (req.method === 'PATCH' && taskId)) {
        let input;
        try { input = await readJson(req); }
        catch { return json(res, 400, { error: 'Invalid JSON request' }); }
        if (req.method === 'POST') {
          const title = typeof input?.title === 'string' ? input.title.trim() : '';
          if (!title) return json(res, 400, { error: 'Task title is required' });
          const result = db.prepare('INSERT INTO tasks (project_id, title) VALUES (?, ?)').run(projectId, title);
          return json(res, 201, { id: Number(result.lastInsertRowid), title, completed: false });
        }
        if (typeof input?.completed !== 'boolean') {
          return json(res, 400, { error: 'Completion must be a boolean' });
        }
        const result = db.prepare('UPDATE tasks SET completed = ? WHERE id = ? AND project_id = ?')
          .run(Number(input.completed), taskId, projectId);
        if (!result.changes) return json(res, 404, { error: 'Task not found' });
        return json(res, 200, asTask(db.prepare('SELECT id, title, completed FROM tasks WHERE id = ?').get(taskId)));
      }
    }
    const match = path.match(/^\/api\/projects\/(\d+)$/);
    if (req.method === 'GET' && match) {
      const project = db.prepare('SELECT id, name FROM projects WHERE id = ?').get(match[1]);
      return project ? json(res, 200, project) : json(res, 404, { error: 'Project not found' });
    }
    if (req.method === 'GET' && (path === '/' || /^\/projects\/\d+$/.test(path))) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(page);
    }
    return json(res, 404, { error: 'Not found' });
  } catch (error) {
    console.error(error);
    return json(res, 500, { error: 'Unable to complete request' });
  }
});

server.listen(Number(process.env.PORT || 8080), '0.0.0.0');
for (const signal of ['SIGTERM', 'SIGINT']) {
  process.on(signal, () => server.close(() => {
    db.close();
    process.exit(0);
  }));
}
