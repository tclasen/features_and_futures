import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { once } from 'node:events';
import { DatabaseSync } from 'node:sqlite';

async function start(dbPath) {
  const child = spawn(process.execPath, ['server.js'], {
    env: { ...process.env, PORT: '0', DB_PATH: dbPath },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  const port = await new Promise((resolve, reject) => {
    child.stdout.on('data', chunk => {
      output += chunk;
      const match = output.match(/listening on port (\d+)/);
      if (match) resolve(match[1]);
    });
    child.on('error', reject);
    child.on('exit', code => reject(new Error(`Server exited: ${code}`)));
  });
  return {
    url: `http://127.0.0.1:${port}`,
    async stop() {
      const exited = once(child, 'exit');
      child.kill('SIGTERM');
      await exited;
    }
  };
}

test('tasks validate, filter, stay project-scoped, and persist completion', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-tasks-'));
  const dbPath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await start(dbPath);
    const request = (path, options) => fetch(server.url + path, options);
    const post = (path, fields) => request(path, {
      method: 'POST', body: new URLSearchParams(fields), redirect: 'manual'
    });
    await post('/projects', { name: 'One' });
    await post('/projects', { name: 'Two' });
    const projects = await (await request('/')).text();
    const paths = [...projects.matchAll(/action="(\/projects\/[^" ]+)" method="get"/g)].map(match => match[1]);
    const detail = () => request(paths[0]).then(response => response.text());
    assert.match(await detail(), /<label for="task-title">Task title<\/label>/);
    assert.match(await detail(), /<option selected>All<\/option>/);
    for (const title of ['', '  \t ']) {
      const response = await post(`${paths[0]}/tasks`, { title });
      assert.equal(response.status, 400);
      const html = await response.text();
      assert.match(html, /role="alert">Task title is required/);
      assert.doesNotMatch(html, /data-testid="task-row"/);
    }
    assert.equal((await post(`${paths[0]}/tasks`, { title: '  First <task>  ' })).status, 303);
    await post(`${paths[0]}/tasks`, { title: 'Second task' });
    let html = await detail();
    assert.equal((html.match(/data-testid="task-row"/g) || []).length, 2);
    assert.ok(html.indexOf('<span>First &lt;task&gt;</span>') < html.indexOf('<span>Second task</span>'));
    assert.match(html, /aria-label="Complete First &lt;task&gt;"/);
    assert.doesNotMatch(html, / checked/);
    const taskPath = html.match(/action="([^" ]+\/tasks\/[^" ]+)"/)[1];
    assert.equal((await post(taskPath, { completed: '1' })).status, 303);
    html = await detail();
    assert.match(html, /aria-label="Complete First &lt;task&gt;" checked/);
    const open = await (await request(`${paths[0]}?filter=Open`)).text();
    assert.doesNotMatch(open, /<span>First/);
    assert.match(open, /<span>Second task/);
    const completed = await (await request(`${paths[0]}?filter=Completed`)).text();
    assert.match(completed, /<span>First/);
    assert.doesNotMatch(completed, /<span>Second/);
    assert.doesNotMatch(await (await request(paths[1])).text(), /data-testid="task-row"/);
    const wrongProjectTask = taskPath.replace(paths[0], paths[1]);
    assert.equal((await post(wrongProjectTask, {})).status, 404);
    await server.stop();
    server = await start(dbPath);
    assert.equal(await detail(), html);
    assert.equal((await post(taskPath, {})).status, 303);
    assert.doesNotMatch(await detail(), / checked/);
    await server.stop();
    server = await start(dbPath);
    assert.doesNotMatch(await detail(), / checked/);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('projects validate, trim, navigate, order and persist across restart', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-test-'));
  const dbPath = join(directory, 'nested', 'projects.sqlite');
  let server;
  try {
    server = await start(dbPath);
    const request = (path, options) => fetch(server.url + path, options);
    const create = name => request('/projects', {
      method: 'POST', body: new URLSearchParams({ name }), redirect: 'manual'
    });
    const health = await request('/health');
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { status: 'ok' });
    let html = await (await request('/')).text();
    assert.match(html, /<h1>Workboard<\/h1>/);
    assert.match(html, /<label for="project-name">Project name<\/label>/);
    assert.match(html, />Create project<\/button>/);
    assert.doesNotMatch(html, /data-testid="project-row"/);
    for (const name of ['', '   \t ']) {
      const response = await create(name);
      assert.equal(response.status, 400);
      html = await response.text();
      assert.match(html, /role="alert">Project name is required/);
      assert.doesNotMatch(html, /data-testid="project-row"/);
    }
    assert.equal((await create('  First project  ')).status, 303);
    assert.equal((await create('Second <project>')).status, 303);
    html = await (await request('/')).text();
    assert.equal((html.match(/data-testid="project-row"/g) || []).length, 2);
    assert.match(html, /<span>First project<\/span>/);
    assert.match(html, /Second &lt;project&gt;/);
    assert.ok(html.indexOf('First project') < html.indexOf('Second &lt;project&gt;'));
    const paths = [...html.matchAll(/action="(\/projects\/[^" ]+)" method="get"/g)].map(match => match[1]);
    const detail = await (await request(paths[0])).text();
    assert.match(detail, /<h1>First project<\/h1>/);
    assert.match(detail, /action="\/" method="get"><button type="submit">Projects/);
    assert.equal((await request('/projects/missing')).status, 404);
    await server.stop();
    server = await start(dbPath);
    assert.equal(await (await request('/')).text(), html);
    assert.match(await (await request(paths[0])).text(), /<h1>First project<\/h1>/);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('archive, restore, summaries and legacy database migration persist', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-archive-'));
  const dbPath = join(directory, 'workboard.sqlite');
  const legacy = new DatabaseSync(dbPath);
  legacy.exec(`CREATE TABLE projects (
    position INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL UNIQUE, name TEXT NOT NULL
  ); INSERT INTO projects (id, name) VALUES ('legacy', 'Legacy project');`);
  legacy.close();
  let server;
  try {
    server = await start(dbPath);
    const request = path => fetch(server.url + path);
    const html = path => request(path).then(response => response.text());
    const post = (path, fields = {}) => fetch(server.url + path, {
      method: 'POST', body: new URLSearchParams(fields), redirect: 'manual'
    });
    assert.match(await html('/'), /<option selected>Active<\/option>/);
    assert.match(await html('/'), /data-testid="project-summary">0\/0 completed/);
    await post('/projects/legacy/tasks', { title: 'Done' });
    await post('/projects/legacy/tasks', { title: 'Pending' });
    const taskPath = (await html('/projects/legacy')).match(/action="([^" ]+\/tasks\/[^" ]+)"/)[1];
    await post(taskPath, { completed: '1' });
    assert.match(await html('/'), /data-testid="project-summary">1\/2 completed/);
    await post('/projects/legacy/archive');
    assert.doesNotMatch(await html('/'), /data-testid="project-row"/);
    let archivedList = await html('/?filter=Archived');
    assert.match(archivedList, />Restore project<\/button>/);
    assert.match(archivedList, />Open project<\/button>/);
    assert.match(archivedList, /1\/2 completed/);
    const detail = await html('/projects/legacy');
    assert.match(detail, /Archived project/);
    assert.match(detail, /<button type="submit" disabled>Create task/);
    assert.equal((detail.match(/aria-label="Complete [^"]+"(?: checked)? disabled/g) || []).length, 2);
    const filtered = await html('/projects/legacy?filter=Completed');
    assert.match(filtered, /<span>Done<\/span>/);
    assert.doesNotMatch(filtered, /<span>Pending<\/span>/);
    assert.equal((await post('/projects/legacy/tasks', { title: 'Forbidden' })).status, 403);
    assert.equal((await post(taskPath, {})).status, 403);
    await server.stop();
    server = await start(dbPath);
    assert.equal(await html('/?filter=Archived'), archivedList);
    assert.equal(await html('/projects/legacy'), detail);
    await post('/projects/legacy/restore');
    assert.doesNotMatch(await html('/?filter=Archived'), /data-testid="project-row"/);
    assert.match(await html('/'), /1\/2 completed/);
    assert.match(await html('/'), />Archive project<\/button>/);
    assert.doesNotMatch(await html('/projects/legacy'), / disabled/);
    await server.stop();
    server = await start(dbPath);
    assert.match(await html('/'), /1\/2 completed/);
    await post(taskPath, {});
    assert.match(await html('/'), /0\/2 completed/);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('task rename preserves ownership, order, completion and persistence', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-task-rename-'));
  const dbPath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await start(dbPath);
    const html = path => fetch(server.url + path).then(response => response.text());
    const post = (path, fields = {}) => fetch(server.url + path, {
      method: 'POST', body: new URLSearchParams(fields), redirect: 'manual'
    });
    await post('/projects', { name: 'One' });
    await post('/projects', { name: 'Two' });
    const paths = [...(await html('/')).matchAll(/action="(\/projects\/[^" ]+)" method="get"/g)].map(match => match[1]);
    const path = paths[0];
    await post(`${path}/tasks`, { title: 'Original' });
    await post(`${path}/tasks`, { title: 'Second' });
    const taskPath = (await html(path)).match(/action="([^" ]+\/tasks\/[^" ]+)"/)[1];
    await post(taskPath, { completed: '1' });
    assert.match(await html(path), />New task title<\/label>/);
    for (const title of ['', '  \t ']) {
      const response = await post(`${taskPath}/rename`, { title, filter: 'Completed' });
      assert.equal(response.status, 400);
      const detail = await response.text();
      assert.match(detail, /role="alert">Task title is required/);
      assert.match(detail, /aria-label="Complete Original" checked/);
      assert.match(detail, /<option selected>Completed/);
    }
    const response = await post(`${taskPath}/rename`, { title: '  Renamed <task>  ', filter: 'Completed' });
    assert.equal(response.status, 303);
    assert.equal(response.headers.get('location'), `${path}?filter=Completed`);
    const detail = await html(path);
    assert.match(detail, /aria-label="Complete Renamed &lt;task&gt;" checked/);
    assert.ok(detail.indexOf('<span>Renamed &lt;task&gt;</span>') < detail.indexOf('<span>Second</span>'));
    assert.ok(detail.includes(`action="${taskPath}"`));
    assert.match(await html('/'), /1\/2 completed/);
    assert.doesNotMatch(await html(`${path}?filter=Open`), /<span>Renamed/);
    assert.match(await html(`${path}?filter=Completed`), /<span>Renamed/);
    assert.doesNotMatch(await html(paths[1]), /data-testid="task-row"/);
    assert.equal((await post(`${taskPath.replace(path, paths[1])}/rename`, { title: 'Wrong owner' })).status, 404);
    await server.stop();
    server = await start(dbPath);
    assert.equal(await html(path), detail);
    await post(`${path}/archive`);
    const archived = await html(path);
    assert.equal((archived.match(/name="title" type="text" disabled/g) || []).length, 2);
    assert.equal((archived.match(/disabled>Rename task/g) || []).length, 2);
    assert.equal((await post(`${taskPath}/rename`, { title: 'Forbidden' })).status, 403);
    await server.stop();
    server = await start(dbPath);
    assert.equal(await html(path), archived);
    await post(`${path}/restore`);
    assert.doesNotMatch(await html(path), / disabled/);
    assert.equal((await post(`${taskPath}/rename`, { title: 'Restored' })).status, 303);
    await server.stop();
    server = await start(dbPath);
    assert.match(await html(path), /aria-label="Complete Restored" checked/);
    assert.match(await html('/'), /1\/2 completed/);
    assert.equal((await post(`${path}/tasks/missing/rename`, { title: 'Missing' })).status, 404);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('rename validates and preserves identity, order, tasks and archive protection', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-rename-'));
  const dbPath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await start(dbPath);
    const html = path => fetch(server.url + path).then(response => response.text());
    const post = (path, fields = {}) => fetch(server.url + path, {
      method: 'POST', body: new URLSearchParams(fields), redirect: 'manual'
    });
    await post('/projects', { name: 'Original' });
    await post('/projects', { name: 'Second' });
    const path = (await html('/')).match(/action="(\/projects\/[^" ]+)" method="get"/)[1];
    await post(`${path}/tasks`, { title: 'Done' });
    await post(`${path}/tasks`, { title: 'Pending' });
    const taskPath = (await html(path)).match(/action="([^" ]+\/tasks\/[^" ]+)"/)[1];
    await post(taskPath, { completed: '1' });
    assert.match(await html(path), /<label for="new-project-name">New project name<\/label>/);
    for (const name of ['', '  \t ']) {
      const response = await post(`${path}/rename`, { name });
      assert.equal(response.status, 400);
      const detail = await response.text();
      assert.match(detail, /role="alert">Project name is required/);
      assert.match(detail, /<h1>Original<\/h1>/);
    }
    const response = await post(`${path}/rename`, { name: '  Renamed <project>  ', filter: 'Completed' });
    assert.equal(response.status, 303);
    assert.equal(response.headers.get('location'), `${path}?filter=Completed`);
    const detail = await html(path);
    assert.match(detail, /<h1>Renamed &lt;project&gt;<\/h1>/);
    assert.match(detail, /aria-label="Complete Done" checked/);
    assert.match(detail, /<span>Pending<\/span>/);
    const list = await html('/');
    assert.ok(list.indexOf('Renamed &lt;project&gt;') < list.indexOf('<span>Second</span>'));
    assert.match(list, /1\/2 completed/);
    assert.ok(list.includes(`action="${path}" method="get"`));
    await server.stop();
    server = await start(dbPath);
    assert.equal(await html(path), detail);
    assert.equal(await html('/'), list);
    await post(`${path}/archive`);
    const archived = await html(path);
    assert.match(archived, /id="new-project-name" name="name" type="text" disabled/);
    assert.match(archived, /<button type="submit" disabled>Rename project/);
    assert.equal((await post(`${path}/rename`, { name: 'Forbidden' })).status, 403);
    assert.match(await html(path), /<h1>Renamed &lt;project&gt;<\/h1>/);
    await post(`${path}/restore`);
    assert.doesNotMatch(await html(path), / disabled/);
    assert.equal((await post(`${path}/rename`, { name: 'Restored' })).status, 303);
    await server.stop();
    server = await start(dbPath);
    assert.match(await html(path), /<h1>Restored<\/h1>/);
    assert.match(await html(path), /aria-label="Complete Done" checked/);
    assert.match(await html('/'), /1\/2 completed/);
    assert.equal((await post('/projects/missing/rename', { name: 'Missing' })).status, 404);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});
