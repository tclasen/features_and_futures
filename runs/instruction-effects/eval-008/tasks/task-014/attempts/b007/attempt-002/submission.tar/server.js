import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { normalizeDueDate } from './due-date.js';

const assets = new Map([
  ['/', ['text/html; charset=utf-8', readFileSync(new URL('./public/index.html', import.meta.url))]],
  ['/app.js', ['text/javascript; charset=utf-8', readFileSync(new URL('./public/app.js', import.meta.url))]],
  ['/task-filters.js', ['text/javascript; charset=utf-8', readFileSync(new URL('./public/task-filters.js', import.meta.url))]],
  ['/search.js', ['text/javascript; charset=utf-8', readFileSync(new URL('./public/search.js', import.meta.url))]],
  ['/due-date.js', ['text/javascript; charset=utf-8', readFileSync(new URL('./due-date.js', import.meta.url))]],
  ['/style.css', ['text/css; charset=utf-8', readFileSync(new URL('./public/style.css', import.meta.url))]],
]);

async function readJson(request) {
  const chunks = [];
  let bodySize = 0;
  for await (const chunk of request) {
    bodySize += chunk.length;
    if (bodySize > 65536) {
      throw Object.assign(new Error('Request is too large'), { status: 413 });
    }
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw Object.assign(new Error('Invalid JSON'), { status: 400 });
  }
}

export function createApplication(dbPath) {
  mkdirSync(dirname(dbPath), { recursive: true });
  const database = new DatabaseSync(dbPath);
  database.exec(`CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL CHECK (length(trim(name)) > 0)
  )`);
  database.exec(`PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER NOT NULL REFERENCES projects(id),
      title TEXT NOT NULL CHECK (length(trim(title)) > 0),
      completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1))
    );
    CREATE INDEX IF NOT EXISTS tasks_project_id ON tasks(project_id, id)`);
  if (!database.prepare('PRAGMA table_info(projects)').all().some((column) => column.name === 'archived')) {
    database.exec('ALTER TABLE projects ADD COLUMN archived INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1))');
  }
  if (!database.prepare('PRAGMA table_info(tasks)').all().some((column) => column.name === 'priority')) {
    database.exec("ALTER TABLE tasks ADD COLUMN priority TEXT NOT NULL DEFAULT 'Normal' CHECK (priority IN ('Low', 'Normal', 'High'))");
  }
  if (!database.prepare('PRAGMA table_info(projects)').all().some((column) => column.name === 'defaultTaskPriority')) {
    database.exec("ALTER TABLE projects ADD COLUMN defaultTaskPriority TEXT NOT NULL DEFAULT 'Normal' CHECK (defaultTaskPriority IN ('Low', 'Normal', 'High'))");
  }
  if (!database.prepare('PRAGMA table_info(tasks)').all().some((column) => column.name === 'dueDate')) {
    database.exec("ALTER TABLE tasks ADD COLUMN dueDate TEXT NOT NULL DEFAULT ''");
  }
  if (!database.prepare('PRAGMA table_info(tasks)').all().some((column) => column.name === 'position')) {
    // Preserve the original ID ordering while allowing later moves to append.
    database.exec(`BEGIN;
      ALTER TABLE tasks ADD COLUMN position INTEGER NOT NULL DEFAULT 0;
      UPDATE tasks SET position = id;
      COMMIT;`);
  }
  if (!database.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'task_positions'").get()) {
    // The legacy position column is only used to seed remembered project order.
    // Keep absent tasks' positions reserved so returns and new arrivals cannot collide.
    database.exec(`BEGIN;
      CREATE TABLE task_positions (
        task_id INTEGER NOT NULL REFERENCES tasks(id),
        project_id INTEGER NOT NULL REFERENCES projects(id),
        position INTEGER NOT NULL CHECK (position > 0),
        PRIMARY KEY (task_id, project_id),
        UNIQUE (project_id, position)
      );
      INSERT INTO task_positions (task_id, project_id, position)
        SELECT id, project_id, ROW_NUMBER() OVER (PARTITION BY project_id ORDER BY position, id)
        FROM tasks;
      COMMIT;`);
  }
  const projectQuery = `SELECT projects.id, projects.name, projects.archived, projects.defaultTaskPriority,
    COUNT(tasks.id) AS totalCount, COALESCE(SUM(tasks.completed), 0) AS completedCount
    FROM projects LEFT JOIN tasks ON tasks.project_id = projects.id`;
  const listProjects = database.prepare(`${projectQuery} GROUP BY projects.id ORDER BY projects.id`);
  const getProject = database.prepare(`${projectQuery} WHERE projects.id = ? GROUP BY projects.id`);
  const archiveProject = database.prepare('UPDATE projects SET archived = ? WHERE id = ?');
  const renameProject = database.prepare('UPDATE projects SET name = ? WHERE id = ?');
  const updateDefaultTaskPriority = database.prepare('UPDATE projects SET defaultTaskPriority = ? WHERE id = ?');
  const projectData = (project) => ({ ...project, archived: Boolean(project.archived) });
  const insertProject = database.prepare('INSERT INTO projects (name) VALUES (?)');
  const listTasks = database.prepare(`SELECT tasks.id, title, completed, priority, dueDate
    FROM tasks JOIN task_positions ON task_positions.task_id = tasks.id
      AND task_positions.project_id = tasks.project_id
    WHERE tasks.project_id = ? ORDER BY task_positions.position`);
  const getTask = database.prepare('SELECT id, title, completed, priority, dueDate FROM tasks WHERE project_id = ? AND id = ?');
  const insertTask = database.prepare('INSERT INTO tasks (project_id, title, priority) VALUES (?, ?, ?)');
  const rememberPosition = database.prepare(`INSERT INTO task_positions (task_id, project_id, position)
    SELECT ?, ?, COALESCE(MAX(position), 0) + 1 FROM task_positions WHERE project_id = ?
    ON CONFLICT (task_id, project_id) DO NOTHING`);
  const moveTask = database.prepare('UPDATE tasks SET project_id = ? WHERE project_id = ? AND id = ?');
  const updateTask = database.prepare('UPDATE tasks SET completed = ? WHERE project_id = ? AND id = ?');
  const renameTask = database.prepare('UPDATE tasks SET title = ? WHERE project_id = ? AND id = ?');
  const updateTaskPriority = database.prepare('UPDATE tasks SET priority = ? WHERE project_id = ? AND id = ?');
  const updateTaskDueDate = database.prepare('UPDATE tasks SET dueDate = ? WHERE project_id = ? AND id = ?');
  const taskData = (task) => ({ ...task, completed: Boolean(task.completed) });

  function transaction(action) {
    database.exec('BEGIN IMMEDIATE');
    try {
      const result = action();
      database.exec('COMMIT');
      return result;
    } catch (error) {
      database.exec('ROLLBACK');
      throw error;
    }
  }

  function json(response, status, value) {
    response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
    response.end(JSON.stringify(value));
  }

  const server = createServer(async (request, response) => {
    try {
      const pathname = new URL(request.url, 'http://localhost').pathname;
      if (request.method === 'GET' && pathname === '/health') {
        return json(response, 200, { status: 'ok' });
      }
      if (pathname === '/api/projects' && request.method === 'GET') {
        return json(response, 200, listProjects.all().map(projectData));
      }
      if (pathname === '/api/projects' && request.method === 'POST') {
        const input = await readJson(request);
        const name = typeof input?.name === 'string' ? input.name.trim() : '';
        if (!name) return json(response, 400, { error: 'Project name is required' });
        const result = insertProject.run(name);
        return json(response, 201, projectData(getProject.get(Number(result.lastInsertRowid))));
      }
      const moveMatch = pathname.match(/^\/api\/projects\/([1-9]\d*)\/tasks\/([1-9]\d*)\/move$/);
      if (request.method === 'POST' && moveMatch) {
        const projectId = Number(moveMatch[1]);
        const taskId = Number(moveMatch[2]);
        if (!getProject.get(projectId)) return json(response, 404, { error: 'Project not found' });
        if (!getTask.get(projectId, taskId)) return json(response, 404, { error: 'Task not found' });
        const input = await readJson(request);
        const destinationId = input?.destinationProjectId;
        if (!Number.isSafeInteger(destinationId) || destinationId <= 0 || destinationId === projectId) {
          return json(response, 400, { error: 'Choose another active destination project' });
        }
        const destination = getProject.get(destinationId);
        if (!destination) return json(response, 404, { error: 'Destination project not found' });
        if (getProject.get(projectId).archived || destination.archived) {
          return json(response, 409, { error: 'Tasks can only move between active projects' });
        }
        transaction(() => {
          rememberPosition.run(taskId, destinationId, destinationId);
          moveTask.run(destinationId, projectId, taskId);
        });
        return json(response, 200, taskData(getTask.get(destinationId, taskId)));
      }
      const tasksMatch = pathname.match(/^\/api\/projects\/([1-9]\d*)\/tasks(?:\/([1-9]\d*))?$/);
      if (tasksMatch) {
        const projectId = Number(tasksMatch[1]);
        if (!getProject.get(projectId)) return json(response, 404, { error: 'Project not found' });
        const taskId = tasksMatch[2] ? Number(tasksMatch[2]) : null;
        if (request.method === 'GET' && taskId === null) {
          return json(response, 200, listTasks.all(projectId).map(taskData));
        }
        if (request.method === 'POST' && taskId === null) {
          const input = await readJson(request);
          const project = getProject.get(projectId);
          if (project.archived) return json(response, 409, { error: 'Archived project is read-only' });
          const title = typeof input?.title === 'string' ? input.title.trim() : '';
          if (!title) return json(response, 400, { error: 'Task title is required' });
          const taskId = transaction(() => {
            const result = insertTask.run(projectId, title, project.defaultTaskPriority);
            const id = Number(result.lastInsertRowid);
            rememberPosition.run(id, projectId, projectId);
            return id;
          });
          return json(response, 201, taskData(getTask.get(projectId, taskId)));
        }
        if (request.method === 'PATCH' && taskId !== null) {
          if (!getTask.get(projectId, taskId)) return json(response, 404, { error: 'Task not found' });
          const input = await readJson(request);
          if (getProject.get(projectId).archived) return json(response, 409, { error: 'Archived project is read-only' });
          const fields = ['title', 'completed', 'priority', 'dueDate'].filter((field) => Object.hasOwn(input ?? {}, field));
          if (fields.length > 1) {
            return json(response, 400, { error: 'Update title, completion, priority, or due date separately' });
          }
          if (Object.hasOwn(input ?? {}, 'title')) {
            const title = typeof input.title === 'string' ? input.title.trim() : '';
            if (!title) return json(response, 400, { error: 'Task title is required' });
            renameTask.run(title, projectId, taskId);
          } else if (Object.hasOwn(input ?? {}, 'priority')) {
            if (!['Low', 'Normal', 'High'].includes(input.priority)) {
              return json(response, 400, { error: 'Priority must be Low, Normal, or High' });
            }
            updateTaskPriority.run(input.priority, projectId, taskId);
          } else if (Object.hasOwn(input ?? {}, 'dueDate')) {
            const dueDate = normalizeDueDate(input.dueDate);
            if (dueDate === null) {
              return json(response, 400, { error: 'Due date must be a valid YYYY-MM-DD date' });
            }
            updateTaskDueDate.run(dueDate, projectId, taskId);
          } else {
            if (typeof input?.completed !== 'boolean') {
              return json(response, 400, { error: 'Completion must be a boolean' });
            }
            updateTask.run(Number(input.completed), projectId, taskId);
          }
          return json(response, 200, taskData(getTask.get(projectId, taskId)));
        }
      }
      const projectMatch = pathname.match(/^\/api\/projects\/([1-9]\d*)$/);
      if (request.method === 'PATCH' && projectMatch) {
        const projectId = Number(projectMatch[1]);
        if (!getProject.get(projectId)) return json(response, 404, { error: 'Project not found' });
        const input = await readJson(request);
        const fields = ['name', 'archived', 'defaultTaskPriority'].filter((field) => Object.hasOwn(input ?? {}, field));
        if (fields.length > 1) {
          return json(response, 400, { error: 'Update name, archive state, or default task priority separately' });
        }
        if (Object.hasOwn(input ?? {}, 'name')) {
          if (getProject.get(projectId).archived) return json(response, 409, { error: 'Archived project is read-only' });
          const name = typeof input.name === 'string' ? input.name.trim() : '';
          if (!name) return json(response, 400, { error: 'Project name is required' });
          renameProject.run(name, projectId);
        } else if (Object.hasOwn(input ?? {}, 'defaultTaskPriority')) {
          if (getProject.get(projectId).archived) return json(response, 409, { error: 'Archived project is read-only' });
          if (!['Low', 'Normal', 'High'].includes(input.defaultTaskPriority)) {
            return json(response, 400, { error: 'Default task priority must be Low, Normal, or High' });
          }
          updateDefaultTaskPriority.run(input.defaultTaskPriority, projectId);
        } else {
          if (typeof input?.archived !== 'boolean') {
            return json(response, 400, { error: 'Archive state must be a boolean' });
          }
          archiveProject.run(Number(input.archived), projectId);
        }
        return json(response, 200, projectData(getProject.get(projectId)));
      }
      if (request.method === 'GET' && projectMatch) {
        const project = getProject.get(Number(projectMatch[1]));
        return project
          ? json(response, 200, projectData(project))
          : json(response, 404, { error: 'Project not found' });
      }
      if (request.method === 'GET') {
        const asset = assets.get(/^\/projects\/[1-9]\d*$/.test(pathname) ? '/' : pathname);
        if (asset) {
          response.writeHead(200, { 'Content-Type': asset[0] });
          return response.end(asset[1]);
        }
      }
      json(response, 404, { error: 'Not found' });
    } catch (error) {
      if (error.status) return json(response, error.status, { error: error.message });
      console.error(error);
      if (!response.headersSent) json(response, 500, { error: 'Unable to complete the request' });
      else response.end();
    }
  });
  server.on('close', () => database.close());
  return server;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const server = createApplication(process.env.DB_PATH || './data/workboard.sqlite');
  server.listen(Number(process.env.PORT || 8080), '0.0.0.0', () => {
    console.log(`Workboard listening on port ${server.address().port}`);
  });
  for (const signal of ['SIGINT', 'SIGTERM']) {
    process.on(signal, () => server.close());
  }
}
