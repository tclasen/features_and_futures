# Workboard

Requires Node.js 22.22.1. No external dependencies or installation are needed.

```sh
npm start
```

The server binds to `0.0.0.0`, with `PORT` defaulting to `8080` and `DB_PATH` defaulting to `data/workboard.sqlite`. The database directory is created automatically. Use a persistent filesystem path to retain projects, tasks, and completion state between restarts.

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
npm test
```

`GET /health` returns `{"status":"ok"}`. The browser UI uses HTML forms. Task completion and filter changes submit automatically with browser JavaScript; fallback submit buttons are available without JavaScript. Project names and task titles are trimmed on creation and escaped when displayed. Projects and tasks appear in insertion order. Each project owns its tasks; the All (default), Open, and Completed filters only show that project's tasks.

The tests use a temporary SQLite database and real HTTP requests, including server restarts to check persistence, task filtering, completion toggles, validation, and project isolation.
