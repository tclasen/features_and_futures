# Workboard

Requires Node.js 22.22.1. No external dependencies or installation are needed.

```sh
npm start
```

The server binds to `0.0.0.0`, with `PORT` defaulting to `8080` and `DB_PATH` defaulting to `data/workboard.sqlite`. The database directory is created automatically. Use a persistent filesystem path to retain projects, tasks, completion state, and archive state between restarts.

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
npm test
```

`GET /health` returns `{"status":"ok"}`. The browser UI uses HTML forms. Task completion and filter changes submit automatically with browser JavaScript; fallback submit buttons are available without JavaScript. Project names and task titles are trimmed on creation and escaped when displayed. Projects and tasks appear in insertion order. Each project owns its tasks; the All (default), Open, and Completed filters only show that project's tasks.

The project list defaults to Active; select Archived to open or restore archived projects. Every project row summarizes all tasks as completed/total. Archived projects keep their tasks and filters, but task creation and completion changes are disabled and rejected by the server. Existing SQLite databases are automatically migrated without changing project or task IDs.

Active project pages also support renaming. Names are trimmed and must be nonblank; renaming keeps the URL, creation order, tasks, and summary unchanged. Archived projects cannot be renamed until restored. Renamed names persist in the same SQLite database.

Each task row also supports renaming with a trimmed, nonblank title. Renaming preserves task identity, project ownership, order, completion, and filter membership, and updates the completion label. Archived projects disable and reject task renaming until restored.

Each task has an independent Low, Normal, or High priority. Priority changes save automatically and preserve task order, ownership, title, completion, and summaries. Archived projects disable and reject priority changes until restored. Existing tasks migrate to Normal; saved priorities survive renaming and server restarts.

Project pages combine the Task filter with a Priority filter (All, Low, Normal, High). Both default to All when opening a project. Each change submits both selections, and task edits preserve them while immediately re-evaluating matching rows in creation order. Filters remain usable on archived projects and never change saved task data or completion summaries.

Each project has a saved Default task priority (Low, Normal, High), initially Normal for both existing and new projects. Changes affect only tasks created afterward in that project, preserve both filters, and never update existing tasks. Defaults survive renaming, reloads, and restarts. Archived projects display the saved default but disable and reject edits until restored.

Every task has an optional Task due date textbox and Save due date button. Dates are trimmed and validated as real Gregorian calendar days in `YYYY-MM-DD` format (years 0001–9999), without timezone conversion. Empty input clears the date; invalid input displays an alert and preserves the saved date. Dates persist independently without affecting task data, filters, or summaries. Archived projects disable and reject due-date edits until restored.

The tests use temporary SQLite databases and real HTTP requests, including server restarts to check persistence, task filtering, completion toggles, validation, project isolation, archive/restore, summaries, renaming, priorities, combined filters, project defaults, due-date validation and persistence, and migration from previous schemas.
