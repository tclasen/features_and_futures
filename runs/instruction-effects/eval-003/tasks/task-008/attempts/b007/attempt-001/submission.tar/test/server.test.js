import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { once } from 'node:events';
import { DatabaseSync } from 'node:sqlite';

async function startServer(databasePath) {
  const child = spawn(process.execPath, ['server.js'], {
    env: { ...process.env, PORT: '0', DB_PATH: databasePath },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let output = '';
  let errors = '';
  child.stderr.on('data', (chunk) => { errors += chunk; });
  const url = await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      child.kill();
      reject(new Error(`Server startup timed out: ${errors}`));
    }, 5000);
    child.once('error', (error) => { clearTimeout(timeout); reject(error); });
    child.once('exit', (code) => {
      clearTimeout(timeout);
      reject(new Error(`Server exited with ${code}: ${errors}`));
    });
    child.stdout.on('data', (chunk) => {
      output += chunk;
      const match = output.match(/listening on port (\d+)/);
      if (match) {
        clearTimeout(timeout);
        resolve(`http://127.0.0.1:${match[1]}`);
      }
    });
  });
  return {
    url,
    async stop() {
      if (child.exitCode !== null || child.signalCode !== null) return;
      const exited = once(child, 'exit');
      child.kill('SIGTERM');
      await exited;
    },
  };
}

test('projects validate, keep creation order, and survive server restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-test-'));
  const databasePath = join(directory, 'nested', 'projects.sqlite');
  let server;
  try {
    server = await startServer(databasePath);
    const request = (path, options) => fetch(server.url + path, options);
    const create = (name) => request('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });
    const health = await request('/health');
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { status: 'ok' });
    const filterModule = await request('/task-filters.js');
    assert.equal(filterModule.status, 200);
    assert.match(filterModule.headers.get('content-type'), /text\/javascript/);
    assert.match(await filterModule.text(), /export function filterTasks/);
    for (const name of ['', '   ', null, 42]) {
      const response = await create(name);
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Project name is required' });
    }
    assert.deepEqual(await (await request('/api/projects')).json(), []);
    const firstResponse = await create('  First project  ');
    assert.equal(firstResponse.status, 201);
    const first = await firstResponse.json();
    assert.equal(first.name, 'First project');
    const second = await (await create('<b>Second project</b>')).json();
    assert.notEqual(first.id, second.id);
    const expected = [first, second];
    assert.deepEqual(await (await request('/api/projects')).json(), expected);
    assert.deepEqual(await (await request(`/api/projects/${first.id}`)).json(), first);
    const detail = await request(`/projects/${first.id}`);
    assert.equal(detail.status, 200);
    assert.match(await detail.text(), /<script type="module" src="\/app.js">/);
    assert.equal((await request('/api/projects/99999')).status, 404);
    const invalidJson = await request('/api/projects', { method: 'POST', body: '{' });
    assert.equal(invalidJson.status, 400);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request('/api/projects')).json(), expected);
    assert.deepEqual(await (await request(`/api/projects/${first.id}`)).json(), first);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('tasks validate, remain project-owned, and persist completion across restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-tasks-'));
  const databasePath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await startServer(databasePath);
    const request = (path, method = 'GET', body) => fetch(server.url + path, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const firstProject = await (await request('/api/projects', 'POST', { name: 'First' })).json();
    const secondProject = await (await request('/api/projects', 'POST', { name: 'Second' })).json();
    const path = `/api/projects/${firstProject.id}/tasks`;
    const otherPath = `/api/projects/${secondProject.id}/tasks`;
    for (const title of ['', ' \t\n ', null, 42]) {
      const response = await request(path, 'POST', { title });
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Task title is required' });
    }
    assert.deepEqual(await (await request(path)).json(), []);
    const firstResponse = await request(path, 'POST', { title: '  First task  ' });
    assert.equal(firstResponse.status, 201);
    const first = await firstResponse.json();
    assert.equal(first.title, 'First task');
    assert.equal(first.completed, false);
    const second = await (await request(path, 'POST', { title: '<b>Second task</b>' })).json();
    assert.deepEqual(await (await request(path)).json(), [first, second]);
    assert.deepEqual(await (await request(otherPath)).json(), []);
    assert.equal((await request(`${otherPath}/${first.id}`, 'PATCH', { completed: true })).status, 404);
    assert.equal((await request('/api/projects/99999/tasks', 'POST', { title: 'Orphan' })).status, 404);
    for (const completed of [null, 1, 'true']) {
      assert.equal((await request(`${path}/${first.id}`, 'PATCH', { completed })).status, 400);
    }
    const completed = await request(`${path}/${first.id}`, 'PATCH', { completed: true });
    assert.equal(completed.status, 200);
    assert.deepEqual(await completed.json(), { ...first, completed: true });
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request(path)).json(), [{ ...first, completed: true }, second]);
    assert.deepEqual(await (await request(otherPath)).json(), []);
    assert.equal((await request(`/projects/${firstProject.id}`)).status, 200);
    const reopened = await request(`${path}/${first.id}`, 'PATCH', { completed: false });
    assert.deepEqual(await reopened.json(), first);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request(path)).json(), [first, second]);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('archive and restore preserve tasks and summaries across restarts', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-archive-'));
  const databasePath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await startServer(databasePath);
    const request = (path, method = 'GET', body) => fetch(server.url + path, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const project = await (await request('/api/projects', 'POST', { name: 'Archive me' })).json();
    assert.deepEqual(project, {
      id: project.id, name: 'Archive me', archived: false, defaultPriority: 'Normal', totalCount: 0, completedCount: 0,
    });
    const projectPath = `/api/projects/${project.id}`;
    const tasksPath = `${projectPath}/tasks`;
    const first = await (await request(tasksPath, 'POST', { title: 'Finished' })).json();
    const second = await (await request(tasksPath, 'POST', { title: 'Pending' })).json();
    await request(`${tasksPath}/${first.id}`, 'PATCH', { completed: true });
    const expectedTasks = [{ ...first, completed: true }, second];
    const expectedProject = { ...project, totalCount: 2, completedCount: 1 };
    assert.deepEqual(await (await request('/api/projects')).json(), [expectedProject]);
    for (const archived of [null, 1, 'true']) {
      assert.equal((await request(projectPath, 'PATCH', { archived })).status, 400);
    }
    assert.equal((await request('/api/projects/99999', 'PATCH', { archived: true })).status, 404);
    const archiveResponse = await request(projectPath, 'PATCH', { archived: true });
    assert.equal(archiveResponse.status, 200);
    assert.deepEqual(await archiveResponse.json(), { ...expectedProject, archived: true });
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request('/api/projects')).json(), [{ ...expectedProject, archived: true }]);
    assert.deepEqual(await (await request(projectPath)).json(), { ...expectedProject, archived: true });
    assert.equal((await request(`/projects/${project.id}`)).status, 200);
    assert.equal((await request(tasksPath, 'POST', { title: 'Blocked' })).status, 409);
    assert.equal((await request(`${tasksPath}/${first.id}`, 'PATCH', { completed: false })).status, 409);
    assert.deepEqual(await (await request(tasksPath)).json(), expectedTasks);
    const restoreResponse = await request(projectPath, 'PATCH', { archived: false });
    assert.equal(restoreResponse.status, 200);
    assert.deepEqual(await restoreResponse.json(), expectedProject);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request('/api/projects')).json(), [expectedProject]);
    assert.deepEqual(await (await request(tasksPath)).json(), expectedTasks);
    assert.equal((await request(`${tasksPath}/${first.id}`, 'PATCH', { completed: false })).status, 200);
    assert.deepEqual(await (await request(projectPath)).json(), { ...expectedProject, completedCount: 0 });
    assert.equal((await request(tasksPath, 'POST', { title: 'Allowed' })).status, 201);
    assert.deepEqual(await (await request(projectPath)).json(), { ...expectedProject, totalCount: 3, completedCount: 0 });
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('renaming preserves identity, order, tasks, and summaries and respects archive state', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-rename-'));
  const databasePath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await startServer(databasePath);
    const request = (path, method = 'GET', body) => fetch(server.url + path, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const first = await (await request('/api/projects', 'POST', { name: 'Original' })).json();
    const second = await (await request('/api/projects', 'POST', { name: 'Second' })).json();
    const path = `/api/projects/${first.id}`;
    const tasksPath = `${path}/tasks`;
    const finished = await (await request(tasksPath, 'POST', { title: 'Finished' })).json();
    const open = await (await request(tasksPath, 'POST', { title: 'Open' })).json();
    await request(`${tasksPath}/${finished.id}`, 'PATCH', { completed: true });
    const original = { ...first, totalCount: 2, completedCount: 1 };
    const expectedTasks = [{ ...finished, completed: true }, open];
    for (const name of ['', ' \t\n ', null, 42]) {
      const response = await request(path, 'PATCH', { name });
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Project name is required' });
      assert.deepEqual(await (await request(path)).json(), original);
    }
    assert.equal((await request('/api/projects/99999', 'PATCH', { name: 'Missing' })).status, 404);
    const response = await request(path, 'PATCH', { name: '  Renamed <project>  ' });
    assert.equal(response.status, 200);
    const renamed = { ...original, name: 'Renamed <project>' };
    assert.deepEqual(await response.json(), renamed);
    assert.deepEqual(await (await request('/api/projects')).json(), [renamed, second]);
    assert.deepEqual(await (await request(tasksPath)).json(), expectedTasks);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request(path)).json(), renamed);
    assert.deepEqual(await (await request('/api/projects')).json(), [renamed, second]);
    assert.deepEqual(await (await request(tasksPath)).json(), expectedTasks);
    assert.equal((await request(`/projects/${first.id}`)).status, 200);

    await request(path, 'PATCH', { archived: true });
    await server.stop();
    server = await startServer(databasePath);
    const blocked = await request(path, 'PATCH', { name: 'Blocked rename' });
    assert.equal(blocked.status, 409);
    assert.deepEqual(await blocked.json(), { error: 'Archived project is read-only' });
    assert.equal((await request(path, 'PATCH', { name: 'Blocked rename', archived: false })).status, 400);
    assert.deepEqual(await (await request(path)).json(), { ...renamed, archived: true });
    await request(path, 'PATCH', { archived: false });
    const restored = { ...renamed, name: 'Restored and renamed' };
    assert.deepEqual(await (await request(path, 'PATCH', { name: '  Restored and renamed  ' })).json(), restored);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request('/api/projects')).json(), [restored, second]);
    assert.deepEqual(await (await request(tasksPath)).json(), expectedTasks);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('task renames preserve ownership, order, completion, and summaries through restore and restart', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-task-rename-'));
  const databasePath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await startServer(databasePath);
    const request = (path, method = 'GET', body) => fetch(server.url + path, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const project = await (await request('/api/projects', 'POST', { name: 'Owner' })).json();
    const other = await (await request('/api/projects', 'POST', { name: 'Other' })).json();
    const projectPath = `/api/projects/${project.id}`;
    const tasksPath = `${projectPath}/tasks`;
    const otherTasksPath = `/api/projects/${other.id}/tasks`;
    const first = await (await request(tasksPath, 'POST', { title: 'Finished' })).json();
    const second = await (await request(tasksPath, 'POST', { title: 'Open' })).json();
    const otherTask = await (await request(otherTasksPath, 'POST', { title: 'Other task' })).json();
    await request(`${tasksPath}/${first.id}`, 'PATCH', { completed: true });
    const originalTasks = [{ ...first, completed: true }, second];
    const summary = { ...project, totalCount: 2, completedCount: 1 };

    for (const title of ['', ' \t\n ', null, 42]) {
      const response = await request(`${tasksPath}/${first.id}`, 'PATCH', { title });
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Task title is required' });
      assert.deepEqual(await (await request(tasksPath)).json(), originalTasks);
    }
    assert.equal((await request(`${otherTasksPath}/${first.id}`, 'PATCH', { title: 'Wrong owner' })).status, 404);
    assert.equal((await request(`${tasksPath}/99999`, 'PATCH', { title: 'Missing task' })).status, 404);
    assert.equal((await request('/api/projects/99999/tasks/1', 'PATCH', { title: 'Missing project' })).status, 404);
    assert.equal((await request(`${tasksPath}/${first.id}`, 'PATCH', { title: 'Mixed', completed: false })).status, 400);
    assert.deepEqual(await (await request(tasksPath)).json(), originalTasks);
    const renamedFirst = { ...first, title: 'Renamed <finished>', completed: true };
    const renamedSecond = { ...second, title: 'Renamed open' };
    const renameResponse = await request(`${tasksPath}/${first.id}`, 'PATCH', { title: '  Renamed <finished>  ' });
    assert.equal(renameResponse.status, 200);
    assert.deepEqual(await renameResponse.json(), renamedFirst);
    assert.deepEqual(await (await request(`${tasksPath}/${second.id}`, 'PATCH', { title: '  Renamed open  ' })).json(), renamedSecond);
    const renamedTasks = [renamedFirst, renamedSecond];
    assert.deepEqual(await (await request(tasksPath)).json(), renamedTasks);
    assert.deepEqual(await (await request(otherTasksPath)).json(), [otherTask]);
    assert.deepEqual(await (await request(projectPath)).json(), summary);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request(tasksPath)).json(), renamedTasks);
    assert.deepEqual(await (await request(projectPath)).json(), summary);

    await request(projectPath, 'PATCH', { archived: true });
    await server.stop();
    server = await startServer(databasePath);
    for (const task of renamedTasks) {
      const blocked = await request(`${tasksPath}/${task.id}`, 'PATCH', { title: 'Blocked' });
      assert.equal(blocked.status, 409);
      assert.deepEqual(await blocked.json(), { error: 'Archived project is read-only' });
    }
    assert.deepEqual(await (await request(tasksPath)).json(), renamedTasks);
    await request(projectPath, 'PATCH', { archived: false });
    const restoredFirst = { ...renamedFirst, title: 'Restored task' };
    assert.deepEqual(await (await request(`${tasksPath}/${first.id}`, 'PATCH', { title: '  Restored task  ' })).json(), restoredFirst);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request(tasksPath)).json(), [restoredFirst, renamedSecond]);
    assert.deepEqual(await (await request(otherTasksPath)).json(), [otherTask]);
    assert.deepEqual(await (await request(projectPath)).json(), summary);
    assert.deepEqual(await (await request(`${tasksPath}/${first.id}`, 'PATCH', { completed: false })).json(), {
      ...restoredFirst, completed: false,
    });
    assert.deepEqual(await (await request(projectPath)).json(), { ...summary, completedCount: 0 });
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('existing databases migrate without losing project IDs, tasks, or completion', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-migration-'));
  const databasePath = join(directory, 'workboard.sqlite');
  let server;
  try {
    const database = new DatabaseSync(databasePath);
    try {
      database.exec(`
        CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL);
        CREATE TABLE tasks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          project_id INTEGER NOT NULL REFERENCES projects(id),
          title TEXT NOT NULL,
          completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1))
        );
        INSERT INTO projects (id, name) VALUES (7, 'Existing project');
        INSERT INTO tasks (id, project_id, title, completed) VALUES (12, 7, 'Existing task', 1);
      `);
    } finally {
      database.close();
    }
    server = await startServer(databasePath);
    const expected = [{ id: 7, name: 'Existing project', archived: false, defaultPriority: 'Normal', totalCount: 1, completedCount: 1 }];
    assert.deepEqual(await (await fetch(`${server.url}/api/projects`)).json(), expected);
    assert.deepEqual(await (await fetch(`${server.url}/api/projects/7/tasks`)).json(), [
      { id: 12, title: 'Existing task', completed: true, priority: 'Normal' },
    ]);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await fetch(`${server.url}/api/projects`)).json(), expected);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('priorities are independent, preserve task state, and survive archive, restore, and restart', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-priority-'));
  const databasePath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await startServer(databasePath);
    const request = (path, method = 'GET', body) => fetch(server.url + path, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const project = await (await request('/api/projects', 'POST', { name: 'Owner' })).json();
    const other = await (await request('/api/projects', 'POST', { name: 'Other' })).json();
    const projectPath = `/api/projects/${project.id}`;
    const tasksPath = `${projectPath}/tasks`;
    const otherTasksPath = `/api/projects/${other.id}/tasks`;
    const first = await (await request(tasksPath, 'POST', { title: 'First' })).json();
    const second = await (await request(tasksPath, 'POST', { title: 'Second' })).json();
    const otherTask = await (await request(otherTasksPath, 'POST', { title: 'Other task' })).json();
    for (const task of [first, second, otherTask]) assert.equal(task.priority, 'Normal');
    await request(`${tasksPath}/${first.id}`, 'PATCH', { completed: true });
    const completedFirst = { ...first, completed: true };
    const summary = { ...project, totalCount: 2, completedCount: 1 };
    for (const priority of ['', 'high', 'Urgent', ' High ', null, 1, true, ['High']]) {
      const response = await request(`${tasksPath}/${first.id}`, 'PATCH', { priority });
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Priority must be Low, Normal, or High' });
    }
    for (const body of [{ priority: 'High', title: 'Mixed' }, { priority: 'High', completed: false }]) {
      assert.equal((await request(`${tasksPath}/${first.id}`, 'PATCH', body)).status, 400);
    }
    assert.deepEqual(await (await request(tasksPath)).json(), [completedFirst, second]);
    assert.equal((await request(`${otherTasksPath}/${first.id}`, 'PATCH', { priority: 'High' })).status, 404);
    assert.equal((await request(`${tasksPath}/99999`, 'PATCH', { priority: 'High' })).status, 404);
    assert.equal((await request('/api/projects/99999/tasks/1', 'PATCH', { priority: 'High' })).status, 404);
    for (const priority of ['Low', 'Normal', 'High']) {
      const response = await request(`${tasksPath}/${first.id}`, 'PATCH', { priority });
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), { ...completedFirst, priority });
      assert.deepEqual(await (await request(tasksPath)).json(), [{ ...completedFirst, priority }, second]);
      assert.deepEqual(await (await request(otherTasksPath)).json(), [otherTask]);
      assert.deepEqual(await (await request(projectPath)).json(), summary);
    }
    const renamedFirst = { ...completedFirst, title: 'Renamed first', priority: 'High' };
    assert.deepEqual(await (await request(`${tasksPath}/${first.id}`, 'PATCH', { title: '  Renamed first  ' })).json(), renamedFirst);
    const lowSecond = { ...second, priority: 'Low' };
    assert.deepEqual(await (await request(`${tasksPath}/${second.id}`, 'PATCH', { priority: 'Low' })).json(), lowSecond);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request(tasksPath)).json(), [renamedFirst, lowSecond]);
    assert.deepEqual(await (await request(otherTasksPath)).json(), [otherTask]);
    assert.deepEqual(await (await request(projectPath)).json(), summary);
    await request(projectPath, 'PATCH', { archived: true });
    await server.stop();
    server = await startServer(databasePath);
    for (const task of [first, second]) {
      const response = await request(`${tasksPath}/${task.id}`, 'PATCH', { priority: 'Normal' });
      assert.equal(response.status, 409);
      assert.deepEqual(await response.json(), { error: 'Archived project is read-only' });
    }
    assert.deepEqual(await (await request(tasksPath)).json(), [renamedFirst, lowSecond]);
    await request(projectPath, 'PATCH', { archived: false });
    assert.deepEqual(await (await request(tasksPath)).json(), [renamedFirst, lowSecond]);
    const restoredFirst = { ...renamedFirst, priority: 'Low' };
    assert.deepEqual(await (await request(`${tasksPath}/${first.id}`, 'PATCH', { priority: 'Low' })).json(), restoredFirst);
    assert.deepEqual(await (await request(`${tasksPath}/${first.id}`, 'PATCH', { completed: false })).json(), {
      ...restoredFirst, completed: false,
    });
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await (await request(tasksPath)).json(), [{ ...restoredFirst, completed: false }, lowSecond]);
    assert.deepEqual(await (await request(projectPath)).json(), { ...summary, completedCount: 0 });
    assert.deepEqual(await (await request(otherTasksPath)).json(), [otherTask]);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('project defaults affect only future tasks and persist independently through rename, archive, and restart', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-default-priority-'));
  const databasePath = join(directory, 'workboard.sqlite');
  let server;
  try {
    server = await startServer(databasePath);
    const request = (path, method = 'GET', body) => fetch(server.url + path, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const read = async (path) => (await request(path)).json();
    const project = await (await request('/api/projects', 'POST', { name: 'Owner' })).json();
    const other = await (await request('/api/projects', 'POST', { name: 'Other' })).json();
    assert.equal(project.defaultPriority, 'Normal');
    assert.equal(other.defaultPriority, 'Normal');
    const projectPath = `/api/projects/${project.id}`;
    const tasksPath = `${projectPath}/tasks`;
    const otherPath = `/api/projects/${other.id}`;
    const createTask = async (path, title) => {
      const response = await request(`${path}/tasks`, 'POST', { title });
      assert.equal(response.status, 201);
      return response.json();
    };
    const first = await createTask(projectPath, 'First');
    assert.equal(first.priority, 'Normal');
    await request(`${tasksPath}/${first.id}`, 'PATCH', { completed: true });
    const savedTasks = [{ ...first, completed: true }];
    const summary = { ...project, totalCount: 1, completedCount: 1 };
    for (const defaultPriority of ['', 'high', ' High ', null, 42, true, ['High']]) {
      const response = await request(projectPath, 'PATCH', { defaultPriority });
      assert.equal(response.status, 400);
      assert.deepEqual(await response.json(), { error: 'Default priority must be Low, Normal, or High' });
    }
    for (const body of [{ defaultPriority: 'High', name: 'Mixed' }, { defaultPriority: 'High', archived: true }]) {
      assert.equal((await request(projectPath, 'PATCH', body)).status, 400);
    }
    assert.equal((await request('/api/projects/99999', 'PATCH', { defaultPriority: 'High' })).status, 404);
    assert.deepEqual(await read(projectPath), summary);
    for (const defaultPriority of ['High', 'Low', 'Normal', 'High']) {
      const response = await request(projectPath, 'PATCH', { defaultPriority });
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), { ...summary, defaultPriority });
      assert.deepEqual(await read(tasksPath), savedTasks);
      assert.deepEqual(await read(otherPath), other);
    }
    const high = await createTask(projectPath, 'Inherited High');
    assert.equal(high.priority, 'High');
    savedTasks.push(high);
    await request(projectPath, 'PATCH', { defaultPriority: 'Low' });
    assert.deepEqual(await read(tasksPath), savedTasks);
    const low = await createTask(projectPath, 'Inherited Low');
    assert.equal(low.priority, 'Low');
    savedTasks.push(low);
    await request(otherPath, 'PATCH', { defaultPriority: 'Normal' });
    assert.equal((await createTask(otherPath, 'Other task')).priority, 'Normal');
    const renamed = { ...summary, name: 'Renamed owner', defaultPriority: 'Low', totalCount: 3 };
    assert.deepEqual(await (await request(projectPath, 'PATCH', { name: '  Renamed owner  ' })).json(), renamed);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await read(projectPath), renamed);
    assert.deepEqual(await read(tasksPath), savedTasks);
    assert.equal((await read(otherPath)).defaultPriority, 'Normal');
    await request(projectPath, 'PATCH', { archived: true });
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await read(projectPath), { ...renamed, archived: true });
    const blocked = await request(projectPath, 'PATCH', { defaultPriority: 'High' });
    assert.equal(blocked.status, 409);
    assert.deepEqual(await blocked.json(), { error: 'Archived project is read-only' });
    assert.deepEqual(await read(tasksPath), savedTasks);
    assert.deepEqual(await (await request(projectPath, 'PATCH', { archived: false })).json(), renamed);
    const afterRestore = await createTask(projectPath, 'After restoration');
    assert.equal(afterRestore.priority, 'Low');
    savedTasks.push(afterRestore);
    await request(projectPath, 'PATCH', { defaultPriority: 'Normal' });
    assert.deepEqual(await read(tasksPath), savedTasks);
    await server.stop();
    server = await startServer(databasePath);
    assert.deepEqual(await read(projectPath), { ...renamed, defaultPriority: 'Normal', totalCount: 4 });
    assert.deepEqual(await read(tasksPath), savedTasks);
    assert.deepEqual((await read('/api/projects')).map((item) => item.id), [project.id, other.id]);
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});

test('default migration preserves existing archived projects and saved task priorities', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'workboard-default-migration-'));
  const databasePath = join(directory, 'workboard.sqlite');
  let server;
  try {
    const database = new DatabaseSync(databasePath);
    try {
      database.exec(`
        CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          archived INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1)));
        CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT,
          project_id INTEGER NOT NULL REFERENCES projects(id), title TEXT NOT NULL,
          completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1)),
          priority TEXT NOT NULL DEFAULT 'Normal' CHECK (priority IN ('Low', 'Normal', 'High')));
        INSERT INTO projects (id, name, archived) VALUES (7, 'Archived owner', 1);
        INSERT INTO tasks (id, project_id, title, completed, priority) VALUES (12, 7, 'High task', 1, 'High');
      `);
    } finally {
      database.close();
    }
    const expectedProject = { id: 7, name: 'Archived owner', archived: true,
      defaultPriority: 'Normal', totalCount: 1, completedCount: 1 };
    for (let restart = 0; restart < 2; restart++) {
      server = await startServer(databasePath);
      assert.deepEqual(await (await fetch(`${server.url}/api/projects/7`)).json(), expectedProject);
      assert.deepEqual(await (await fetch(`${server.url}/api/projects/7/tasks`)).json(), [
        { id: 12, title: 'High task', completed: true, priority: 'High' },
      ]);
      await server.stop();
    }
  } finally {
    if (server) await server.stop();
    await rm(directory, { recursive: true, force: true });
  }
});
