import { normalizeDueDate } from '/due-date.js';

const app = document.querySelector('#app');

async function api(path, options) {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Unable to complete request');
  return data;
}

function element(tag, text) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  return node;
}

function showAlert(message) {
  let alert = app.querySelector('[role="alert"]');
  if (!alert) {
    alert = element('p');
    alert.setAttribute('role', 'alert');
    app.append(alert);
  }
  alert.textContent = message;
}

// Normalize only for matching; saved names and titles remain untouched.
function normalizeSearchText(value) {
  return value.replace(/[ \t]+/g, ' ').replace(/[A-Z]/g, (letter) => letter.toLowerCase());
}

function searchControl(labelText, buttonText, id, onApply) {
  const form = element('form');
  const label = element('label', labelText);
  label.htmlFor = id;
  const input = element('input');
  input.id = id;
  input.type = 'text';
  const button = element('button', buttonText);
  button.type = 'submit';
  let query = '';
  form.append(label, input, button);
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    input.value = input.value.trim();
    query = normalizeSearchText(input.value);
    onApply();
  });
  return { form, matches: (text) => normalizeSearchText(text).includes(query) };
}

function projectRow(project, onArchiveChange) {
  const row = element('li');
  row.dataset.testid = 'project-row';
  row.append(element('span', project.name));
  const open = element('button', 'Open project');
  open.type = 'button';
  open.addEventListener('click', () => location.assign(`/projects/${project.id}`));
  const summary = element('span', `${project.completedCount}/${project.totalCount} completed`);
  summary.dataset.testid = 'project-summary';
  const archive = element('button', project.archived ? 'Restore project' : 'Archive project');
  archive.type = 'button';
  archive.addEventListener('click', async () => {
    archive.disabled = true;
    app.querySelector('[role="alert"]')?.remove();
    try {
      const saved = await api(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archived: !project.archived }),
      });
      Object.assign(project, saved);
      onArchiveChange();
    } catch (error) {
      showAlert(error.message);
    } finally {
      archive.disabled = false;
    }
  });
  row.append(summary, open, archive);
  return row;
}

async function showProjects() {
  app.replaceChildren(element('h1', 'Workboard'));
  const form = element('form');
  const label = element('label', 'Project name');
  label.htmlFor = 'project-name';
  const input = element('input');
  input.id = 'project-name';
  input.name = 'name';
  input.type = 'text';
  const create = element('button', 'Create project');
  create.type = 'submit';
  form.append(label, input, create);
  const list = element('ul');
  list.className = 'projects';
  let projects = [];
  const filterLabel = element('label', 'Project filter');
  filterLabel.htmlFor = 'project-filter';
  const filter = element('select');
  filter.id = 'project-filter';
  for (const value of ['Active', 'Archived']) {
    const option = element('option', value);
    option.value = value;
    filter.append(option);
  }
  const filters = element('div');
  filters.className = 'project-filter';
  filters.append(filterLabel, filter);
  const search = searchControl('Project search', 'Search projects', 'project-search', renderProjects);
  function renderProjects() {
    list.replaceChildren(...projects
      .filter((project) => Boolean(project.archived) === (filter.value === 'Archived')
        && search.matches(project.name))
      .map((project) => projectRow(project, renderProjects)));
  }
  filter.addEventListener('change', renderProjects);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (create.disabled) return;
    app.querySelector('[role="alert"]')?.remove();
    const name = input.value.trim();
    if (!name) {
      showAlert('Project name is required');
      input.focus();
      return;
    }
    create.disabled = true;
    try {
      const project = await api('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      projects.push(project);
      renderProjects();
      input.value = '';
      input.focus();
    } catch (error) {
      showAlert(error.message);
    } finally {
      create.disabled = false;
    }
  });
  const directory = element('button', 'Task directory');
  directory.type = 'button';
  directory.addEventListener('click', () => location.assign('/directory'));
  app.append(directory, form, projectImportControl(), filters, search.form, list);
  // Enable creation only after the initial list has loaded, preserving ordering.
  create.disabled = true;
  try {
    projects = await api('/api/projects');
    renderProjects();
    create.disabled = false;
  } catch (error) {
    showAlert(error.message);
  }
}

function projectImportControl() {
  const form = element('form');
  const jsonLabel = element('label', 'Project JSON');
  jsonLabel.htmlFor = 'project-json';
  const jsonInput = element('textarea');
  jsonInput.id = jsonLabel.htmlFor;
  jsonInput.rows = 6;
  const nameLabel = element('label', 'Imported project name');
  nameLabel.htmlFor = 'imported-project-name';
  const nameInput = element('input');
  nameInput.id = nameLabel.htmlFor;
  nameInput.type = 'text';
  const button = element('button', 'Import project');
  button.type = 'submit';
  form.append(jsonLabel, jsonInput, nameLabel, nameInput, button);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (button.disabled) return;
    app.querySelector('[role="alert"]')?.remove();
    const name = nameInput.value.trim();
    if (!name) {
      showAlert('Project name is required');
      return;
    }
    button.disabled = true;
    try {
      const project = await api('/api/projects/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, projectJson: jsonInput.value }),
      });
      location.assign(`/projects/${project.id}`);
    } catch (error) {
      showAlert(error.message);
    } finally {
      button.disabled = false;
    }
  });
  return form;
}

// Shared controls keep directory and project filtering/validation semantics identical.
function taskFilters(onChange, { restoreInvalidRange = false } = {}) {
  const filters = element('div');
  filters.className = 'task-filter';
  function selectControl(labelText, id, values) {
    const label = element('label', labelText);
    label.htmlFor = id;
    const select = element('select');
    select.id = id;
    for (const value of values) {
      const option = element('option', value);
      option.value = value;
      select.append(option);
    }
    select.addEventListener('change', onChange);
    filters.append(label, select);
    return select;
  }
  const completion = selectControl('Task filter', 'task-filter', ['All', 'Open', 'Completed', 'Deleted']);
  const priority = selectControl('Priority filter', 'priority-filter', ['All', 'Low', 'Normal', 'High']);
  const rangeForm = element('form');
  function boundary(labelText, id) {
    const label = element('label', labelText);
    label.htmlFor = id;
    const input = element('input');
    input.id = id;
    input.type = 'text';
    rangeForm.append(label, input);
    return input;
  }
  const fromInput = boundary('Due from', 'due-from');
  const throughInput = boundary('Due through', 'due-through');
  const apply = element('button', 'Apply due range');
  apply.type = 'submit';
  rangeForm.append(apply);
  let from = '';
  let through = '';
  rangeForm.addEventListener('submit', (event) => {
    event.preventDefault();
    app.querySelector('[role="alert"]')?.remove();
    const nextFrom = normalizeDueDate(fromInput.value);
    const nextThrough = normalizeDueDate(throughInput.value);
    const error = nextFrom === null || nextThrough === null
      ? 'Due range must use valid YYYY-MM-DD dates'
      : nextFrom && nextThrough && nextFrom > nextThrough
        ? 'Due from must not be after Due through'
        : null;
    if (error) {
      if (restoreInvalidRange) {
        fromInput.value = from;
        throughInput.value = through;
      }
      showAlert(error);
      return;
    }
    fromInput.value = from = nextFrom;
    throughInput.value = through = nextThrough;
    onChange();
  });
  return {
    filters, rangeForm,
    matches: (task) =>
      (completion.value === 'Deleted' ? task.deleted : !task.deleted
        && (completion.value === 'All'
          || (completion.value === 'Completed' ? task.completed : !task.completed)))
      && (priority.value === 'All' || task.priority === priority.value)
      && ((!from && !through) || (task.dueDate
        && (!from || task.dueDate >= from)
        && (!through || task.dueDate <= through))),
  };
}

async function showDirectory() {
  document.title = 'Task directory — Workboard';
  app.replaceChildren(element('h1', 'Task directory'));
  const back = element('button', 'Projects');
  back.type = 'button';
  back.addEventListener('click', () => location.assign('/'));
  const scopeLabel = element('label', 'Project scope');
  scopeLabel.htmlFor = 'project-scope';
  const scope = element('select');
  scope.id = scopeLabel.htmlFor;
  for (const value of ['Active', 'Archived']) {
    const option = element('option', value);
    option.value = value;
    scope.append(option);
  }
  const scopeControl = element('div');
  scopeControl.className = 'project-filter';
  scopeControl.append(scopeLabel, scope);
  const controls = taskFilters(renderDirectory, { restoreInvalidRange: true });
  const search = searchControl('Directory search', 'Search directory', 'directory-search', renderDirectory);
  const list = element('ul');
  list.className = 'directory';
  let tasks = [];
  function renderDirectory() {
    list.replaceChildren(...tasks.filter((task) =>
      task.projectArchived === (scope.value === 'Archived')
      && controls.matches(task) && search.matches(task.title)).map((task) => {
      const row = element('li');
      row.dataset.testid = 'directory-task-row';
      for (const [field, text] of [
        ['title', task.title], ['project-name', task.projectName],
        ['completion', task.completed ? 'Completed' : 'Open'],
        ['priority', task.priority], ['due-date', task.dueDate], ['notes', task.notes],
      ]) {
        const value = element('div', text);
        value.dataset.testid = field === 'project-name' ? 'directory-project-name' : `directory-task-${field}`;
        row.append(value);
      }
      const open = element('button', 'Open project');
      open.type = 'button';
      open.addEventListener('click', () => location.assign(`/projects/${task.projectId}`));
      row.append(open);
      return row;
    }));
  }
  scope.addEventListener('change', renderDirectory);
  app.append(back, scopeControl, controls.filters, controls.rangeForm, search.form, list);
  try {
    tasks = await api('/api/directory');
    renderDirectory();
  } catch (error) {
    showAlert(error.message);
  }
}

async function showTasks(project) {
  const projectId = project.id;
  const archived = Boolean(project.archived);
  const endpoint = `/api/projects/${projectId}/tasks`;
  let tasks = [];
  let destinations = [];
  const saving = new Set();
  const form = element('form');
  const titleLabel = element('label', 'Task title');
  titleLabel.htmlFor = 'task-title';
  const input = element('input');
  input.id = 'task-title';
  input.name = 'title';
  input.type = 'text';
  const create = element('button', 'Create task');
  create.type = 'submit';
  create.disabled = true;
  form.append(titleLabel, input, create);

  const controls = taskFilters(renderTasks);
  const list = element('ul');
  list.className = 'tasks';

  const search = searchControl('Task search', 'Search tasks', 'task-search', renderTasks);
  function renderTasks() {
    const visible = tasks.filter((task) => search.matches(task.title) && controls.matches(task));
    list.replaceChildren(...visible.map((task) => {
      const row = element('li');
      row.dataset.testid = 'task-row';
      const readOnly = archived || task.deleted || saving.has(task.id);
      const checkbox = element('input');
      checkbox.type = 'checkbox';
      checkbox.checked = task.completed;
      checkbox.disabled = Boolean(readOnly);
      checkbox.setAttribute('aria-label', `Complete ${task.title}`);
      async function saveTask(changes) {
        if (archived || saving.has(task.id) || (task.deleted && !Object.hasOwn(changes, 'deleted'))) return;
        saving.add(task.id);
        deletionButton.disabled = true;
        checkbox.disabled = true;
        renameInput.disabled = true;
        renameButton.disabled = true;
        priority.disabled = true;
        dueDateInput.disabled = true;
        dueDateButton.disabled = true;
        notesInput.disabled = true;
        notesButton.disabled = true;
        destination.disabled = true;
        moveButton.disabled = true;
        app.querySelector('[role="alert"]')?.remove();
        try {
          const saved = await api(`${endpoint}/${task.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(changes),
          });
          if (Object.hasOwn(changes, 'destinationProjectId')) {
            tasks = tasks.filter((current) => current.id !== task.id);
          } else {
            Object.assign(task, saved);
          }
        } catch (error) {
          checkbox.checked = task.completed;
          showAlert(error.message);
        } finally {
          saving.delete(task.id);
          renderTasks();
        }
      }
      checkbox.addEventListener('change', () => saveTask({ completed: checkbox.checked }));
      const renameForm = element('form');
      const renameLabel = element('label', 'New task title');
      renameLabel.htmlFor = `new-task-title-${task.id}`;
      const renameInput = element('input');
      renameInput.id = renameLabel.htmlFor;
      renameInput.name = 'title';
      renameInput.type = 'text';
      renameInput.disabled = Boolean(readOnly);
      const renameButton = element('button', 'Rename task');
      renameButton.type = 'submit';
      renameButton.disabled = Boolean(readOnly);
      renameForm.append(renameLabel, renameInput, renameButton);
      renameForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (archived || saving.has(task.id)) return;
        app.querySelector('[role="alert"]')?.remove();
        const title = renameInput.value.trim();
        if (!title) {
          showAlert('Task title is required');
          renameInput.focus();
          return;
        }
        await saveTask({ title });
      });
      const priorityLabel = element('label', 'Task priority');
      priorityLabel.htmlFor = `task-priority-${task.id}`;
      const priority = element('select');
      priority.id = priorityLabel.htmlFor;
      for (const value of ['Low', 'Normal', 'High']) {
        const option = element('option', value);
        option.value = value;
        priority.append(option);
      }
      priority.value = task.priority;
      priority.disabled = Boolean(readOnly);
      priority.addEventListener('change', () => {
        if (archived || saving.has(task.id)) return;
        return saveTask({ priority: priority.value });
      });
      const dueDateForm = element('form');
      const dueDateLabel = element('label', 'Task due date');
      dueDateLabel.htmlFor = `task-due-date-${task.id}`;
      const dueDateInput = element('input');
      dueDateInput.id = dueDateLabel.htmlFor;
      dueDateInput.name = 'dueDate';
      dueDateInput.type = 'text';
      dueDateInput.value = task.dueDate || '';
      dueDateInput.disabled = Boolean(readOnly);
      const dueDateButton = element('button', 'Save due date');
      dueDateButton.type = 'submit';
      dueDateButton.disabled = Boolean(readOnly);
      dueDateForm.append(dueDateLabel, dueDateInput, dueDateButton);
      dueDateForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (archived || saving.has(task.id)) return;
        await saveTask({ dueDate: dueDateInput.value.trim() });
      });
      const moveForm = element('form');
      const destinationLabel = element('label', 'Destination project');
      destinationLabel.htmlFor = `destination-project-${task.id}`;
      const destination = element('select');
      destination.id = destinationLabel.htmlFor;
      for (const project of destinations) {
        const option = element('option', project.name);
        option.value = String(project.id);
        destination.append(option);
      }
      const moveButton = element('button', 'Move task');
      moveButton.type = 'submit';
      destination.disabled = moveButton.disabled = Boolean(readOnly) || destinations.length === 0;
      moveForm.append(destinationLabel, destination, moveButton);
      moveForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (moveButton.disabled) return;
        await saveTask({ destinationProjectId: Number(destination.value) });
      });
      const notesForm = element('form');
      const notesLabel = element('label', 'Task notes');
      notesLabel.htmlFor = `task-notes-${task.id}`;
      const notesInput = element('textarea');
      notesInput.id = notesLabel.htmlFor;
      notesInput.name = 'notes';
      notesInput.rows = 4;
      notesInput.value = task.notes || '';
      notesInput.disabled = Boolean(readOnly);
      const notesButton = element('button', 'Save notes');
      notesButton.type = 'submit';
      notesButton.disabled = Boolean(readOnly);
      notesForm.append(notesLabel, notesInput, notesButton);
      notesForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (archived || saving.has(task.id)) return;
        await saveTask({ notes: notesInput.value });
      });
      const deletionButton = element('button', task.deleted ? 'Restore task' : 'Delete task');
      deletionButton.type = 'button';
      deletionButton.disabled = archived || saving.has(task.id);
      deletionButton.addEventListener('click', () => saveTask({ deleted: !task.deleted }));
      row.append(checkbox, element('span', task.title), renameForm, priorityLabel, priority, dueDateForm, moveForm, notesForm, deletionButton);
      return row;
    }));
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (create.disabled) return;
    app.querySelector('[role="alert"]')?.remove();
    const title = input.value.trim();
    if (!title) {
      showAlert('Task title is required');
      input.focus();
      return;
    }
    create.disabled = true;
    try {
      const task = await api(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title }),
      });
      tasks.push(task);
      renderTasks();
      input.value = '';
      input.focus();
    } catch (error) {
      showAlert(error.message);
    } finally {
      create.disabled = archived;
    }
  });
  app.append(form, controls.filters, controls.rangeForm, search.form, defaultPriorityControl(project), list);
  const [savedTasks, projects] = await Promise.all([api(endpoint), api('/api/projects')]);
  tasks = savedTasks;
  destinations = projects.filter((candidate) => !candidate.archived && candidate.id !== projectId);
  renderTasks();
  create.disabled = archived;
}

function defaultPriorityControl(project) {
  const control = element('div');
  const label = element('label', 'Default task priority');
  label.htmlFor = 'default-task-priority';
  const select = element('select');
  select.id = label.htmlFor;
  for (const value of ['Low', 'Normal', 'High']) {
    const option = element('option', value);
    option.value = value;
    select.append(option);
  }
  select.value = project.defaultTaskPriority;
  select.disabled = project.archived;
  select.addEventListener('change', async () => {
    if (select.disabled) return;
    select.disabled = true;
    app.querySelector('[role="alert"]')?.remove();
    try {
      const saved = await api(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ defaultTaskPriority: select.value }),
      });
      Object.assign(project, saved);
    } catch (error) {
      showAlert(error.message);
    } finally {
      select.value = project.defaultTaskPriority;
      select.disabled = project.archived;
    }
  });
  control.append(label, select);
  return control;
}

function showRenameForm(project, heading) {
  const form = element('form');
  const label = element('label', 'New project name');
  label.htmlFor = 'new-project-name';
  const input = element('input');
  input.id = 'new-project-name';
  input.name = 'name';
  input.type = 'text';
  input.disabled = project.archived;
  const rename = element('button', 'Rename project');
  rename.type = 'submit';
  rename.disabled = project.archived;
  form.append(label, input, rename);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (rename.disabled) return;
    app.querySelector('[role="alert"]')?.remove();
    const name = input.value.trim();
    if (!name) {
      showAlert('Project name is required');
      input.focus();
      return;
    }
    rename.disabled = true;
    try {
      const saved = await api(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      Object.assign(project, saved);
      heading.textContent = project.name;
      document.title = `${project.name} — Workboard`;
      input.value = '';
      input.focus();
    } catch (error) {
      showAlert(error.message);
    } finally {
      rename.disabled = project.archived;
    }
  });
  app.append(form);
}

async function showProject(id) {
  app.replaceChildren();
  const back = element('button', 'Projects');
  back.type = 'button';
  back.addEventListener('click', () => location.assign('/'));
  app.append(back);
  try {
    const project = await api(`/api/projects/${id}`);
    document.title = `${project.name} — Workboard`;
    const heading = element('h1', project.name);
    app.prepend(heading);
    if (project.archived) app.append(element('p', 'Archived project'));
    const download = element('button', 'Download project');
    download.type = 'button';
    // The attachment response starts a download without replacing the current page.
    download.addEventListener('click', () => location.assign(`/api/projects/${project.id}/export`));
    app.append(download);
    showRenameForm(project, heading);
    await showTasks(project);
  } catch (error) {
    if (!app.querySelector('h1')) app.prepend(element('h1', 'Workboard'));
    showAlert(error.message);
  }
}

const match = location.pathname.match(/^\/projects\/(\d+)$/);
(match ? showProject(match[1]) : location.pathname === '/directory' ? showDirectory() : showProjects()).finally(() => {
  app.setAttribute('aria-busy', 'false');
});
