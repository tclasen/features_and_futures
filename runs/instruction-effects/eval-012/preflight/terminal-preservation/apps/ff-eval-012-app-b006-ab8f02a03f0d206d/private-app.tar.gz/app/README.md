# Workboard

Requires Node.js 22.22.1. No dependencies need installation.

Start with `npm start`. The server binds to `0.0.0.0` on `PORT` (default `8080`).
Set `DB_PATH` to select a persistent SQLite file (default `data/workboard.sqlite`).

Example: `PORT=8080 DB_PATH=data/workboard.sqlite npm start`

Run verification with `npm test`.

Create projects on the home page and open a project to create tasks. Task titles
are trimmed, tasks start open, and the Task filter shows All, Open, Completed, or Deleted
tasks in creation order. Completion changes and project ownership are stored in
the configured SQLite file and survive restarts.

Projects can be archived and restored from the project list, which shows each
project's completion summary. Archived projects keep their tasks and allow
filtering, but task creation, completion changes, and renaming are disabled.
Use New project name and Rename project on an active project page to rename it.
Names are trimmed and required; renaming preserves the URL, creation order,
tasks, and completion summary and persists across restarts.

Each task row provides New task title and Rename task. Renaming trims and
requires a title while preserving ownership, order, completion, and summaries.
Task renaming persists across restarts and is disabled in archived projects.

Task priority is saved independently for each task and can
be changed to Low or High. Archived projects disable priority edits.
The Priority filter (All, Low, Normal, High) combines with the Task filter;
both initially show All and remain usable in archived projects. Matching tasks
keep their creation order. Edits immediately update matching rows while keeping
both filter selections, and project summaries always count every live task.

Default task priority on each project page selects Low, Normal, or High for
subsequent new tasks. Projects initially default to Normal. Changing the default
preserves existing tasks and both filter selections. Defaults are independent
per project, persist across restarts, renaming, archive and restore, and cannot
be edited while the project is archived.

Each task has an optional Task due date, saved with Save due date. Dates must be
real Gregorian calendar dates in YYYY-MM-DD format (years 0001–9999). Surrounding
whitespace is trimmed; an empty value clears the date. Invalid dates show an
alert and leave saved data unchanged. Dates persist across restarts and task
renames without changing filters or summaries. Archived projects disable date
editing; restoration preserves dates and enables editing again.

Due from and Due through apply an inclusive due-date range alongside both task
filters. Empty boundaries are unbounded; tasks without dates match only when
both boundaries are empty. Apply due range validates and trims dates, retaining
the previous applied range if a date is invalid or the boundaries are reversed.
Task edits re-evaluate all filters without resetting them. Range controls remain
usable in archived projects, and reopening a project starts with an empty range.

Destination project and Move task move tasks between active projects while
preserving their current title, completion, priority, and due date. First-time
arrivals append after all positions established in the destination. Returning
tasks recover their remembered position there, even when several return in a
different order. New tasks follow reserved positions of tasks currently away.
Positions persist across restarts, project renaming, archival, and restoration.
Moving retains the source page's filters and updates both project summaries.

Project search and Search projects filter names within the selected Active or
Archived list. Task search and Search tasks filter titles alongside completion,
priority, and the applied due range. Searches match substrings ignoring ASCII
letter case and trim surrounding query whitespace. For matching only, runs of
ASCII spaces and horizontal tabs in queries and names/titles become one space;
saved and displayed names/titles retain their original whitespace and case.
An empty query matches everything permitted by the other filters. Applied
queries remain in effect during edits and filter changes; opening either page
starts with an empty query. Archived projects still allow task searches.

Task notes and Save notes store optional multiline plain text exactly as entered,
including whitespace, Unicode, and literal markup. Empty text clears notes.
Notes persist across restarts and travel with tasks through moves and remembered
return positions. Saving notes preserves filters and all other task data; searches
continue matching names and titles only. Archived notes remain visible with editing
disabled, and restoring the project enables editing again. Existing databases gain
empty notes without altering their saved task data.

Delete task removes a live task from ordinary filters and completion summaries
without losing any saved fields or remembered positions. The Deleted filter
shows deleted tasks with the same priority, date range, and title search rules.
Restore task returns a task to its reserved position; tasks created later remain
after it. Deleted task fields and move controls are read-only until restoration.
Archived projects also disable deletion and restoration. Deletion state persists
across restarts; existing databases initialize all earlier tasks as live.

Download project on any project page exports UTF-8 JSON as workboard-project.json.
The version 1 workboard-project document contains the current project name,
archive state and default priority, plus every live and deleted task in stored
order with its title, completion, priority, due date, notes and deletion state.
Export ignores page filters and normalizes only notes line endings to LF in the
download; saved data and remembered return positions remain unchanged.

Import project on the home page accepts a version 1 portable document in Project
JSON and a required Imported project name. It validates every field before
creating a new independent project and opens that project on success. Invalid
documents leave all data and submitted inputs unchanged. Imports preserve task
order and saved fields, including deleted tasks, archived state and the default
priority; notes line endings become LF. Extra fields cannot set internal IDs.

Task directory on the home page opens a read-only list across projects. Project
scope selects Active or Archived owners; completion/deletion, priority, inclusive
due range and title search intersect using the same rules as project pages.
Rows show the saved title, owner, completion, priority, date and literal notes in
project creation order and remembered task order. Open project navigates to the
owner with fresh project-page filters. Opening the directory starts with Active,
All tasks, All priorities, and empty search and due range. Viewing and filtering
never change stored data.
