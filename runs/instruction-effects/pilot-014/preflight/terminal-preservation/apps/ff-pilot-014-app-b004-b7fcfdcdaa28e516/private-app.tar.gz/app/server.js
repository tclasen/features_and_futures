import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const dbPath = process.env.DB_PATH || path.join(root, 'workboard.sqlite');
const db = new DatabaseSync(dbPath);
db.exec(`CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived INTEGER NOT NULL DEFAULT 0
)`);
try { db.exec('ALTER TABLE projects ADD COLUMN archived INTEGER NOT NULL DEFAULT 0'); } catch (error) { if (!String(error.message).includes('duplicate column')) throw error; }
db.exec(`CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  completed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)`);
const listProjects = db.prepare(`SELECT p.id, p.name, p.archived,
  COUNT(t.id) AS totalCount, COALESCE(SUM(t.completed), 0) AS completedCount
  FROM projects p LEFT JOIN tasks t ON t.project_id = p.id GROUP BY p.id ORDER BY p.id`);
const createProject = db.prepare('INSERT INTO projects (name) VALUES (?)');
const findProject = db.prepare('SELECT id, name, archived FROM projects WHERE id = ?');
const setArchived = db.prepare('UPDATE projects SET archived = ? WHERE id = ?');
const renameProject = db.prepare('UPDATE projects SET name = ? WHERE id = ?');
const listTasks = db.prepare('SELECT id, project_id AS projectId, title, completed FROM tasks WHERE project_id = ? ORDER BY id');
const createTask = db.prepare('INSERT INTO tasks (project_id, title) VALUES (?, ?)');
const findTask = db.prepare('SELECT id, project_id AS projectId, title, completed FROM tasks WHERE id = ? AND project_id = ?');
const updateTask = db.prepare('UPDATE tasks SET completed = ? WHERE id = ? AND project_id = ?');
const renameTask = db.prepare('UPDATE tasks SET title = ? WHERE id = ? AND project_id = ?');

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const send = (status, type, body) => {
    res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
    res.end(body);
  };
  if (req.method === 'GET' && url.pathname === '/health') {
    return send(200, 'application/json; charset=utf-8', JSON.stringify({ status: 'ok' }));
  }
  const projectRenameRoute = url.pathname.match(/^\/api\/projects\/(\d+)\/rename$/);
  if (projectRenameRoute && req.method === 'PATCH') {
    try {
      let body = '';
      for await (const chunk of req) body += chunk;
      const payload = JSON.parse(body || '{}');
      const name = typeof payload.name === 'string' ? payload.name.trim() : '';
      if (!name) return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Project name is required' }));
      const id = Number(projectRenameRoute[1]);
      const project = findProject.get(id);
      if (!project) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Project not found' }));
      if (project.archived) return send(403, 'application/json; charset=utf-8', JSON.stringify({ error: 'Archived project' }));
      renameProject.run(name, id);
      return send(200, 'application/json; charset=utf-8', JSON.stringify(findProject.get(id)));
    } catch { return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' })); }
  }
  const projectStateRoute = url.pathname.match(/^\/api\/projects\/(\d+)\/archive$/);
  if (projectStateRoute && req.method === 'PATCH') {
    try {
      let body = '';
      for await (const chunk of req) body += chunk;
      const payload = JSON.parse(body || '{}');
      if (typeof payload.archived !== 'boolean') return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid archive state' }));
      const id = Number(projectStateRoute[1]);
      if (!findProject.get(id)) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Project not found' }));
      setArchived.run(payload.archived ? 1 : 0, id);
      return send(200, 'application/json; charset=utf-8', JSON.stringify(findProject.get(id)));
    } catch { return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' })); }
  }
  const taskRenameRoute = url.pathname.match(/^\/api\/projects\/(\d+)\/tasks\/(\d+)\/rename$/);
  if (taskRenameRoute && req.method === 'PATCH') {
    const projectId = Number(taskRenameRoute[1]);
    const taskId = Number(taskRenameRoute[2]);
    if (!findProject.get(projectId)) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Project not found' }));
    if (findProject.get(projectId).archived) return send(403, 'application/json; charset=utf-8', JSON.stringify({ error: 'Archived project' }));
    try {
      let body = '';
      for await (const chunk of req) body += chunk;
      const payload = JSON.parse(body || '{}');
      const title = typeof payload.title === 'string' ? payload.title.trim() : '';
      if (!title) return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Task title is required' }));
      if (!findTask.get(taskId, projectId)) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Task not found' }));
      renameTask.run(title, taskId, projectId);
      return send(200, 'application/json; charset=utf-8', JSON.stringify(findTask.get(taskId, projectId)));
    } catch { return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' })); }
  }
  const taskRoute = url.pathname.match(/^\/api\/projects\/(\d+)\/tasks(?:\/(\d+))?$/);
  if (taskRoute) {
    const projectId = Number(taskRoute[1]);
    if (!findProject.get(projectId)) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Project not found' }));
    if (!taskRoute[2] && req.method === 'GET') return send(200, 'application/json; charset=utf-8', JSON.stringify(listTasks.all(projectId)));
    if (!taskRoute[2] && req.method === 'POST') {
      if (findProject.get(projectId).archived) return send(403, 'application/json; charset=utf-8', JSON.stringify({ error: 'Archived project' }));
      try {
        let body = '';
        for await (const chunk of req) body += chunk;
        const payload = JSON.parse(body || '{}');
        const title = typeof payload.title === 'string' ? payload.title.trim() : '';
        if (!title) return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Task title is required' }));
        const result = createTask.run(projectId, title);
        return send(201, 'application/json; charset=utf-8', JSON.stringify(findTask.get(result.lastInsertRowid, projectId)));
      } catch {
        return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' }));
      }
    }
    if (taskRoute[2] && req.method === 'PATCH') {
      if (findProject.get(projectId).archived) return send(403, 'application/json; charset=utf-8', JSON.stringify({ error: 'Archived project' }));
      try {
        let body = '';
        for await (const chunk of req) body += chunk;
        const payload = JSON.parse(body || '{}');
        if (typeof payload.completed !== 'boolean') return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid completion state' }));
        updateTask.run(payload.completed ? 1 : 0, Number(taskRoute[2]), projectId);
        const task = findTask.get(Number(taskRoute[2]), projectId);
        if (!task) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Task not found' }));
        return send(200, 'application/json; charset=utf-8', JSON.stringify(task));
      } catch {
        return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' }));
      }
    }
    return send(405, 'application/json; charset=utf-8', JSON.stringify({ error: 'Method not allowed' }));
  }
  if (url.pathname === '/api/projects' && req.method === 'GET') {
    return send(200, 'application/json; charset=utf-8', JSON.stringify(listProjects.all()));
  }
  if (url.pathname === '/api/projects' && req.method === 'POST') {
    try {
      let body = '';
      for await (const chunk of req) body += chunk;
      const payload = JSON.parse(body || '{}');
      const name = typeof payload.name === 'string' ? payload.name.trim() : '';
      if (!name) return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Project name is required' }));
      const result = createProject.run(name);
      return send(201, 'application/json; charset=utf-8', JSON.stringify(findProject.get(result.lastInsertRowid)));
    } catch {
      return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' }));
    }
  }
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname.startsWith('/projects/'))) {
    try {
      return send(200, 'text/html; charset=utf-8', await readFile(path.join(root, 'index.html')));
    } catch {
      return send(500, 'text/plain; charset=utf-8', 'Unable to load application');
    }
  }
  if (req.method === 'GET' && url.pathname === '/app.js') {
    return send(200, 'text/javascript; charset=utf-8', await readFile(path.join(root, 'app.js')));
  }
  if (req.method === 'GET' && url.pathname === '/style.css') {
    return send(200, 'text/css; charset=utf-8', await readFile(path.join(root, 'style.css')));
  }
  send(404, 'text/plain; charset=utf-8', 'Not found');
});

const port = Number(process.env.PORT || 8080);
server.listen(port, '0.0.0.0', () => console.log(`Workboard listening on ${port}`));
