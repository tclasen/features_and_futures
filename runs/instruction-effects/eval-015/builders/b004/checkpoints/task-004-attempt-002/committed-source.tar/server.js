import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const port = Number(process.env.PORT || 8080);
const dbPath = process.env.DB_PATH || join(dirname(fileURLToPath(import.meta.url)), 'workboard.sqlite');
mkdirSync(dirname(dbPath), { recursive: true });
const db = new DatabaseSync(dbPath);
db.exec(`CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  archived INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  completed INTEGER NOT NULL DEFAULT 0
)`);
// Upgrade databases created by earlier checkpoints.
try { db.exec('ALTER TABLE projects ADD COLUMN archived INTEGER NOT NULL DEFAULT 0'); } catch (error) { if (!String(error.message).includes('duplicate column')) throw error; }
const indexPath = join(dirname(fileURLToPath(import.meta.url)), 'index.html');
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const send = (status, type, body) => { res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' }); res.end(body); };
  if (url.pathname === '/health' && req.method === 'GET') return send(200, 'application/json; charset=utf-8', JSON.stringify({ status: 'ok' }));
  if (url.pathname === '/api/projects' && req.method === 'GET') {
    return send(200, 'application/json; charset=utf-8', JSON.stringify(db.prepare(`SELECT p.id, p.name, p.archived, COUNT(t.id) AS total, COALESCE(SUM(t.completed), 0) AS completed FROM projects p LEFT JOIN tasks t ON t.project_id = p.id GROUP BY p.id ORDER BY p.id`).all().map(p => ({ ...p, archived: Boolean(p.archived) }))));
  }
  if (url.pathname === '/api/projects' && req.method === 'POST') {
    let body = '';
    for await (const chunk of req) body += chunk;
    try {
      const data = JSON.parse(body);
      const name = typeof data.name === 'string' ? data.name.trim() : '';
      if (!name) return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Project name is required' }));
      const result = db.prepare('INSERT INTO projects (name) VALUES (?)').run(name);
      return send(201, 'application/json; charset=utf-8', JSON.stringify({ id: Number(result.lastInsertRowid), name }));
    } catch {
      return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' }));
    }
  }
  const tasks = url.pathname.match(/^\/api\/projects\/(\d+)\/tasks$/);
  if (tasks && req.method === 'GET') {
    const projectId = Number(tasks[1]);
    if (!db.prepare('SELECT id FROM projects WHERE id = ?').get(projectId)) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Not found' }));
    return send(200, 'application/json; charset=utf-8', JSON.stringify(db.prepare('SELECT id, project_id AS projectId, title, completed FROM tasks WHERE project_id = ? ORDER BY id').all(projectId).map(task => ({ ...task, completed: Boolean(task.completed) }))));
  }
  if (tasks && req.method === 'POST') {
    let body = '';
    for await (const chunk of req) body += chunk;
    try {
      const projectId = Number(tasks[1]);
      const owner = db.prepare('SELECT id, archived FROM projects WHERE id = ?').get(projectId);
      if (!owner) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Not found' }));
      if (owner.archived) return send(409, 'application/json; charset=utf-8', JSON.stringify({ error: 'Archived project' }));
      const data = JSON.parse(body);
      const title = typeof data.title === 'string' ? data.title.trim() : '';
      if (!title) return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Task title is required' }));
      const result = db.prepare('INSERT INTO tasks (project_id, title) VALUES (?, ?)').run(projectId, title);
      return send(201, 'application/json; charset=utf-8', JSON.stringify({ id: Number(result.lastInsertRowid), projectId, title, completed: false }));
    } catch { return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' })); }
  }
  const project = url.pathname.match(/^\/api\/projects\/(\d+)$/);
  if (project && req.method === 'PATCH') {
    let body = ''; for await (const chunk of req) body += chunk;
    try {
      const data = JSON.parse(body);
      const id = Number(project[1]);
      if (typeof data.name === 'string') {
        const name = data.name.trim();
        if (!name) return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Project name is required' }));
        const result = db.prepare('UPDATE projects SET name = ? WHERE id = ? AND archived = 0').run(name, id);
        if (!result.changes) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Not found' }));
        return send(200, 'application/json; charset=utf-8', JSON.stringify({ ok: true, name }));
      }
      if (typeof data.archived !== 'boolean') return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' }));
      const result = db.prepare('UPDATE projects SET archived = ? WHERE id = ?').run(data.archived ? 1 : 0, id);
      if (!result.changes) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Not found' }));
      return send(200, 'application/json; charset=utf-8', JSON.stringify({ ok: true }));
    } catch { return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' })); }
  }
  const task = url.pathname.match(/^\/api\/tasks\/(\d+)$/);
  if (task && req.method === 'PATCH') {
    let body = '';
    for await (const chunk of req) body += chunk;
    try {
      const data = JSON.parse(body);
      if (typeof data.completed !== 'boolean') return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' }));
      const result = db.prepare('UPDATE tasks SET completed = ? WHERE id = ? AND project_id IN (SELECT id FROM projects WHERE archived = 0)').run(data.completed ? 1 : 0, Number(task[1]));
      if (!result.changes) return send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Not found' }));
      return send(200, 'application/json; charset=utf-8', JSON.stringify({ ok: true }));
    } catch { return send(400, 'application/json; charset=utf-8', JSON.stringify({ error: 'Invalid request' })); }
  }
  if (project && req.method === 'GET') {
    const item = db.prepare('SELECT id, name, archived FROM projects WHERE id = ?').get(Number(project[1]));
    return item ? send(200, 'application/json; charset=utf-8', JSON.stringify({ ...item, archived: Boolean(item.archived) })) : send(404, 'application/json; charset=utf-8', JSON.stringify({ error: 'Not found' }));
  }
  if (req.method === 'GET' && (url.pathname === '/' || /^\/projects\/\d+\/?$/.test(url.pathname))) {
    const { readFile } = await import('node:fs/promises');
    return send(200, 'text/html; charset=utf-8', await readFile(indexPath));
  }
  send(404, 'text/plain; charset=utf-8', 'Not found');
});
server.listen(port, '0.0.0.0');
