# Workboard

Requires Node.js 22.22.1. No dependency installation is needed.

```sh
npm start
```

The server binds to `0.0.0.0`, using `PORT` (default `8080`) and SQLite at
`DB_PATH` (default `./data/workboard.sqlite`). Parent directories are created
on startup. Keep that database file to preserve projects, archive states, tasks,
and completion states across restarts. Existing databases are migrated automatically.

Example:

```sh
PORT=8080 DB_PATH=./data/workboard.sqlite npm start
```

`GET /health` returns `{"status":"ok"}`. The UI uses HTML forms with a small
browser script to submit completion changes and task filters automatically.
Project names and task titles are trimmed and HTML-escaped. Projects and tasks
are ordered by their persistent creation IDs. Each project's tasks can be
filtered by All (the default), Open, or Completed. The project list defaults to
Active and can show Archived projects instead. Archive and restore preserve all
tasks; archived pages allow filtering but reject task changes and renaming. Each
project row shows completed/total counts across all its tasks. Active project pages
allow renaming with a trimmed, nonblank name. Renaming preserves the project URL,
creation order, tasks, and completion states; names persist across restarts.

Run automated HTTP and persistence tests:

```sh
npm test
```
