import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
}

function page(title, content) {
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)} · Workboard</title>
<style>
  body { font-family: system-ui, sans-serif; color: #172438; background: #f4f6fa; margin: 0; }
  main { max-width: 720px; margin: 48px auto; padding: 24px; background: white; border-radius: 12px; }
  h1 { margin-top: 0; }
  label { display: block; margin-bottom: 8px; font-weight: 600; }
  input, button, select { font: inherit; padding: 10px 14px; border-radius: 6px; }
  input { border: 1px solid #8794a8; max-width: 100%; box-sizing: border-box; }
  button { background: #244db2; color: white; border: 0; cursor: pointer; }
  button:focus-visible, input:focus-visible, select:focus-visible { outline: 3px solid #e59e16; outline-offset: 3px; }
  button:disabled, input:disabled, select:disabled { cursor: not-allowed; opacity: 0.6; }
  .project-row { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 16px; padding: 16px 0; border-bottom: 1px solid #dbe1eb; }
  .project-name { overflow-wrap: anywhere; min-width: 0; }
  .project-row form { flex-shrink: 0; }
  .task-row { display: flex; flex-wrap: wrap; align-items: center; gap: 12px; padding: 16px 0; border-bottom: 1px solid #dbe1eb; }
  .task-row label { margin: 0; overflow-wrap: anywhere; }
  .task-controls { margin-top: 24px; }
  [role="alert"] { color: #a01616; }
  @media (max-width: 600px) { main { margin: 16px; } }
</style></head><body><main>${content}</main></body></html>`;
}

function isValidDueDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  if (year < 1 || month < 1 || month > 12) return false;
  const leapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day >= 1 && day <= daysInMonth[month - 1];
}

async function readForm(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 65536) {
      const error = new Error('Request too large');
      error.status = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  return new URLSearchParams(Buffer.concat(chunks).toString('utf8'));
}

export function createApplication(databasePath) {
  mkdirSync(dirname(databasePath), { recursive: true });
  const database = new DatabaseSync(databasePath);
  database.exec(`CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
  )`);
  database.exec(`PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER NOT NULL REFERENCES projects(id),
      title TEXT NOT NULL,
      completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0, 1))
    );
    CREATE INDEX IF NOT EXISTS tasks_project_id ON tasks(project_id);`);
  // Upgrade existing project databases without changing IDs or task ownership.
  if (!database.prepare('PRAGMA table_info(projects)').all().some(column => column.name === 'archived')) {
    database.exec('ALTER TABLE projects ADD COLUMN archived INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1))');
  }
  // SQLite supplies Normal for existing rows as well as future inserts.
  if (!database.prepare('PRAGMA table_info(tasks)').all().some(column => column.name === 'priority')) {
    database.exec("ALTER TABLE tasks ADD COLUMN priority TEXT NOT NULL DEFAULT 'Normal' CHECK (priority IN ('Low', 'Normal', 'High'))");
  }
  if (!database.prepare('PRAGMA table_info(projects)').all().some(column => column.name === 'default_priority')) {
    database.exec("ALTER TABLE projects ADD COLUMN default_priority TEXT NOT NULL DEFAULT 'Normal' CHECK (default_priority IN ('Low', 'Normal', 'High'))");
  }
  if (!database.prepare('PRAGMA table_info(tasks)').all().some(column => column.name === 'due_date')) {
    database.exec("ALTER TABLE tasks ADD COLUMN due_date TEXT NOT NULL DEFAULT ''");
  }
  const priorities = ['Low', 'Normal', 'High'];
  const listTasks = database.prepare('SELECT id, title, completed, priority, due_date FROM tasks WHERE project_id = ? ORDER BY id');
  const setTaskDueDate = database.prepare('UPDATE tasks SET due_date = ? WHERE id = ? AND project_id = ?');
  const insertTask = database.prepare('INSERT INTO tasks (project_id, title, priority) VALUES (?, ?, ?)');
  const updateTask = database.prepare('UPDATE tasks SET completed = ? WHERE id = ? AND project_id = ?');
  const renameTask = database.prepare('UPDATE tasks SET title = ? WHERE id = ? AND project_id = ?');
  const setTaskPriority = database.prepare('UPDATE tasks SET priority = ? WHERE id = ? AND project_id = ?');
  const listProjects = database.prepare(`SELECT projects.id, projects.name, projects.archived,
    COUNT(tasks.id) AS total, COALESCE(SUM(tasks.completed), 0) AS completed
    FROM projects LEFT JOIN tasks ON tasks.project_id = projects.id
    WHERE projects.archived = ? GROUP BY projects.id ORDER BY projects.id`);
  const getProject = database.prepare('SELECT id, name, archived, default_priority FROM projects WHERE id = ?');
  const setDefaultPriority = database.prepare('UPDATE projects SET default_priority = ? WHERE id = ?');
  const setArchived = database.prepare('UPDATE projects SET archived = ? WHERE id = ?');
  const renameProject = database.prepare('UPDATE projects SET name = ? WHERE id = ?');
  const insertProject = database.prepare('INSERT INTO projects (name) VALUES (?)');

  function projectFilter(value) {
    return value === 'Archived' ? 'Archived' : 'Active';
  }

  function projectsPage(error = '', filter = 'Active') {
    const rows = listProjects.all(filter === 'Archived' ? 1 : 0).map(project => `
      <div class="project-row" data-testid="project-row">
        <span class="project-name">${escapeHtml(project.name)}</span>
        <span data-testid="project-summary">${project.completed}/${project.total} completed</span>
        <form action="/projects/${project.id}" method="get"><button type="submit">Open project</button></form>
        <form action="/projects/${project.id}/${project.archived ? 'restore' : 'archive'}" method="post">
          <button type="submit">${project.archived ? 'Restore' : 'Archive'} project</button>
        </form>
      </div>`).join('');
    return page('Projects', `<h1>Workboard</h1>
      ${error ? `<p role="alert">${escapeHtml(error)}</p>` : ''}
      <form action="/projects" method="post">
        <label for="project-name">Project name</label>
        <input id="project-name" name="name" type="text">
        <button type="submit">Create project</button>
      </form>
      <form class="task-controls" action="/" method="get">
        <label for="project-filter">Project filter</label>
        <select id="project-filter" name="filter" onchange="this.form.requestSubmit()">
          ${['Active', 'Archived'].map(option => `<option${filter === option ? ' selected' : ''}>${option}</option>`).join('')}
        </select>
      </form>
      <section aria-label="Projects">${rows}</section>`);
  }

  function taskFilter(value) {
    return ['All', 'Open', 'Completed'].includes(value) ? value : 'All';
  }

  function priorityFilter(value) {
    return priorities.includes(value) ? value : 'All';
  }

  // Applied ranges travel with each form, independently of editable range fields.
  function dueRange(parameters) {
    const from = (parameters.get('dueFrom') ?? '').trim();
    const through = (parameters.get('dueThrough') ?? '').trim();
    if ((from && !isValidDueDate(from)) || (through && !isValidDueDate(through))
      || (from && through && from > through)) return { from: '', through: '' };
    return { from, through };
  }

  function rangeFields(range) {
    return `<input type="hidden" name="dueFrom" value="${range.from}">
      <input type="hidden" name="dueThrough" value="${range.through}">`;
  }

  function projectLocation(id, filter, priority, range) {
    const query = new URLSearchParams({ filter });
    if (priority !== 'All') query.set('priorityFilter', priority);
    if (range?.from) query.set('dueFrom', range.from);
    if (range?.through) query.set('dueThrough', range.through);
    return `/projects/${id}?${query}`;
  }

  function projectPage(project, filter, error = '', priority = 'All', range = { from: '', through: '' }) {
    const path = `/projects/${project.id}`;
    const filterFields = `<input type="hidden" name="filter" value="${filter}">
      <input type="hidden" name="priorityFilter" value="${priority}">
      ${rangeFields(range)}`;
    const rows = listTasks.all(project.id)
      .filter(task => (filter === 'All' || Boolean(task.completed) === (filter === 'Completed'))
        && (priority === 'All' || task.priority === priority)
        && ((!range.from && !range.through) || (task.due_date
          && (!range.from || task.due_date >= range.from)
          && (!range.through || task.due_date <= range.through))))
      .map(task => `<div class="task-row" data-testid="task-row">
        <form action="${path}/tasks/${task.id}" method="post">
          ${filterFields}
          <input id="task-${task.id}" type="checkbox" name="completed" value="1"
            aria-label="Complete ${escapeHtml(task.title)}" ${task.completed ? 'checked' : ''} ${project.archived ? 'disabled' : ''}
            onchange="this.form.requestSubmit()">
          <label for="task-${task.id}">${escapeHtml(task.title)}</label>
        </form>
        <form action="${path}/tasks/${task.id}/rename" method="post">
          ${filterFields}
          <label for="new-task-title-${task.id}">New task title</label>
          <input id="new-task-title-${task.id}" name="title" type="text"${project.archived ? ' disabled' : ''}>
          <button type="submit"${project.archived ? ' disabled' : ''}>Rename task</button>
        </form>
        <form action="${path}/tasks/${task.id}/priority" method="post">
          ${filterFields}
          <label for="task-priority-${task.id}">Task priority</label>
          <select id="task-priority-${task.id}" name="priority"${project.archived ? ' disabled' : ''}
            onchange="this.form.requestSubmit()">
            ${priorities.map(priority => `<option${task.priority === priority ? ' selected' : ''}>${priority}</option>`).join('')}
          </select>
        </form>
        <form action="${path}/tasks/${task.id}/due-date" method="post">
          ${filterFields}
          <label for="task-due-date-${task.id}">Task due date</label>
          <input id="task-due-date-${task.id}" name="dueDate" type="text" value="${escapeHtml(task.due_date)}"${project.archived ? ' disabled' : ''}>
          <button type="submit"${project.archived ? ' disabled' : ''}>Save due date</button>
        </form>
      </div>`).join('');
    return page(project.name, `<h1>${escapeHtml(project.name)}</h1>
      <form action="/" method="get"><button type="submit">Projects</button></form>
      ${project.archived ? '<p>Archived project</p>' : ''}
      ${error ? `<p role="alert">${escapeHtml(error)}</p>` : ''}
      <form class="task-controls" action="${path}/rename" method="post">
        ${filterFields}
        <label for="new-project-name">New project name</label>
        <input id="new-project-name" name="name" type="text"${project.archived ? ' disabled' : ''}>
        <button type="submit"${project.archived ? ' disabled' : ''}>Rename project</button>
      </form>
      <form class="task-controls" action="${path}/default-priority" method="post">
        ${filterFields}
        <label for="default-task-priority">Default task priority</label>
        <select id="default-task-priority" name="priority"${project.archived ? ' disabled' : ''}
          onchange="this.form.requestSubmit()">
          ${priorities.map(option => `<option${project.default_priority === option ? ' selected' : ''}>${option}</option>`).join('')}
        </select>
      </form>
      <form class="task-controls" action="${path}/tasks" method="post">
        ${filterFields}
        <label for="task-title">Task title</label>
        <input id="task-title" name="title" type="text">
        <button type="submit"${project.archived ? ' disabled' : ''}>Create task</button>
      </form>
      <form class="task-controls" action="${path}/due-range" method="get">
        ${filterFields}
        <label for="due-from">Due from</label>
        <input id="due-from" name="rangeFrom" type="text" value="${range.from}">
        <label for="due-through">Due through</label>
        <input id="due-through" name="rangeThrough" type="text" value="${range.through}">
        <button type="submit">Apply due range</button>
      </form>
      <form class="task-controls" action="${path}" method="get">
        ${rangeFields(range)}
        <label for="task-filter">Task filter</label>
        <select id="task-filter" name="filter" onchange="this.form.requestSubmit()">
          ${['All', 'Open', 'Completed'].map(option => `<option${filter === option ? ' selected' : ''}>${option}</option>`).join('')}
        </select>
        <label for="priority-filter">Priority filter</label>
        <select id="priority-filter" name="priorityFilter" onchange="this.form.requestSubmit()">
          ${['All', ...priorities].map(option => `<option${priority === option ? ' selected' : ''}>${option}</option>`).join('')}
        </select>
      </form>
      <section aria-label="Tasks">${rows}</section>`);
  }

  function html(response, status, content) {
    response.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8' });
    response.end(content);
  }

  const server = createServer(async (request, response) => {
    try {
      const { pathname, searchParams } = new URL(request.url, 'http://localhost');
      if (request.method === 'GET' && pathname === '/health') {
        response.writeHead(200, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ status: 'ok' }));
      } else if (request.method === 'GET' && pathname === '/') {
        html(response, 200, projectsPage('', projectFilter(searchParams.get('filter'))));
      } else if (request.method === 'POST' && pathname === '/projects') {
        const form = await readForm(request);
        const name = (form.get('name') ?? '').trim();
        if (!name) {
          html(response, 422, projectsPage('Project name is required'));
          return;
        }
        insertProject.run(name);
        response.writeHead(303, { Location: '/' });
        response.end();
      } else if (request.method === 'POST' && /^\/projects\/\d+\/default-priority$/.test(pathname)) {
        const id = Number(pathname.split('/')[2]);
        const project = Number.isSafeInteger(id) ? getProject.get(id) : undefined;
        if (!project) {
          html(response, 404, page('Not found', '<h1>Project not found</h1>'));
          return;
        }
        const form = await readForm(request);
        const filter = taskFilter(form.get('filter'));
        const selectedPriority = priorityFilter(form.get('priorityFilter'));
        const range = dueRange(form);
        if (project.archived) {
          html(response, 403, projectPage(project, filter, 'Archived project cannot be changed', selectedPriority, range));
          return;
        }
        const priority = form.get('priority');
        if (!priorities.includes(priority)) {
          html(response, 422, projectPage(project, filter, 'Invalid task priority', selectedPriority, range));
          return;
        }
        setDefaultPriority.run(priority, id);
        response.writeHead(303, { Location: projectLocation(id, filter, selectedPriority, range) });
        response.end();
      } else if (request.method === 'POST' && /^\/projects\/\d+\/rename$/.test(pathname)) {
        const id = Number(pathname.split('/')[2]);
        const project = Number.isSafeInteger(id) ? getProject.get(id) : undefined;
        if (!project) {
          html(response, 404, page('Not found', '<h1>Project not found</h1>'));
          return;
        }
        const form = await readForm(request);
        const filter = taskFilter(form.get('filter'));
        const priority = priorityFilter(form.get('priorityFilter'));
        const range = dueRange(form);
        if (project.archived) {
          html(response, 403, projectPage(project, filter, 'Archived project cannot be changed', priority, range));
          return;
        }
        const name = (form.get('name') ?? '').trim();
        if (!name) {
          html(response, 422, projectPage(project, filter, 'Project name is required', priority, range));
          return;
        }
        renameProject.run(name, id);
        response.writeHead(303, { Location: projectLocation(id, filter, priority, range) });
        response.end();
      } else if (request.method === 'POST' && /^\/projects\/\d+\/(archive|restore)$/.test(pathname)) {
        const [, , projectId, action] = pathname.split('/');
        const id = Number(projectId);
        const project = Number.isSafeInteger(id) ? getProject.get(id) : undefined;
        if (!project) {
          html(response, 404, page('Not found', '<h1>Project not found</h1>'));
          return;
        }
        setArchived.run(action === 'archive' ? 1 : 0, id);
        response.writeHead(303, { Location: action === 'archive' ? '/' : '/?filter=Archived' });
        response.end();
      } else if (request.method === 'GET' && /^\/projects\/\d+\/due-range$/.test(pathname)) {
        const id = Number(pathname.split('/')[2]);
        const project = Number.isSafeInteger(id) ? getProject.get(id) : undefined;
        if (!project) {
          html(response, 404, page('Not found', '<h1>Project not found</h1>'));
          return;
        }
        const filter = taskFilter(searchParams.get('filter'));
        const priority = priorityFilter(searchParams.get('priorityFilter'));
        const from = (searchParams.get('rangeFrom') ?? '').trim();
        const through = (searchParams.get('rangeThrough') ?? '').trim();
        let error = '';
        if ((from && !isValidDueDate(from)) || (through && !isValidDueDate(through))) {
          error = 'Due range must use valid YYYY-MM-DD dates';
        } else if (from && through && from > through) {
          error = 'Due from must not be after Due through';
        }
        if (error) {
          html(response, 422, projectPage(project, filter, error, priority, dueRange(searchParams)));
          return;
        }
        response.writeHead(303, { Location: projectLocation(id, filter, priority, { from, through }) });
        response.end();
      } else if (request.method === 'GET' && /^\/projects\/\d+$/.test(pathname)) {
        const id = Number(pathname.split('/')[2]);
        const project = Number.isSafeInteger(id) ? getProject.get(id) : undefined;
        if (!project) {
          html(response, 404, page('Not found', '<h1>Project not found</h1><form action="/"><button>Projects</button></form>'));
          return;
        }
        html(response, 200, projectPage(project, taskFilter(searchParams.get('filter')), '', priorityFilter(searchParams.get('priorityFilter')), dueRange(searchParams)));
      } else if (request.method === 'POST' && /^\/projects\/\d+\/tasks(?:\/\d+(?:\/(?:rename|priority|due-date))?)?$/.test(pathname)) {
        const [, , projectId, , taskId, action] = pathname.split('/');
        const id = Number(projectId);
        const project = Number.isSafeInteger(id) ? getProject.get(id) : undefined;
        if (!project) {
          html(response, 404, page('Not found', '<h1>Project not found</h1>'));
          return;
        }
        const form = await readForm(request);
        const filter = taskFilter(form.get('filter'));
        const selectedPriority = priorityFilter(form.get('priorityFilter'));
        const range = dueRange(form);
        if (project.archived) {
          html(response, 403, projectPage(project, filter, 'Archived project cannot be changed', selectedPriority, range));
          return;
        }
        if (taskId === undefined) {
          const title = (form.get('title') ?? '').trim();
          if (!title) {
            html(response, 422, projectPage(project, filter, 'Task title is required', selectedPriority, range));
            return;
          }
          insertTask.run(id, title, project.default_priority);
        } else {
          const taskNumber = Number(taskId);
          const title = (form.get('title') ?? '').trim();
          if (action === 'rename' && !title) {
            html(response, 422, projectPage(project, filter, 'Task title is required', selectedPriority, range));
            return;
          }
          const priority = form.get('priority');
          if (action === 'priority' && !priorities.includes(priority)) {
            html(response, 422, projectPage(project, filter, 'Invalid task priority', selectedPriority, range));
            return;
          }
          const dueDate = (form.get('dueDate') ?? '').trim();
          if (action === 'due-date' && dueDate && !isValidDueDate(dueDate)) {
            html(response, 422, projectPage(project, filter, 'Due date must be a valid YYYY-MM-DD date', selectedPriority, range));
            return;
          }
          let result;
          if (Number.isSafeInteger(taskNumber)) {
            if (action === 'rename') {
              result = renameTask.run(title, taskNumber, id);
            } else if (action === 'priority') {
              result = setTaskPriority.run(priority, taskNumber, id);
            } else if (action === 'due-date') {
              result = setTaskDueDate.run(dueDate, taskNumber, id);
            } else {
              result = updateTask.run(form.get('completed') === '1' ? 1 : 0, taskNumber, id);
            }
          }
          if (!result?.changes) {
            html(response, 404, page('Not found', '<h1>Task not found</h1>'));
            return;
          }
        }
        response.writeHead(303, { Location: projectLocation(id, filter, selectedPriority, range) });
        response.end();
      } else {
        html(response, 404, page('Not found', '<h1>Page not found</h1>'));
      }
    } catch (error) {
      if (!error.status) console.error(error);
      if (!response.headersSent) {
        html(response, error.status ?? 500, page('Error', '<h1>Unable to complete request</h1>'));
      } else {
        response.end();
      }
    }
  });
  server.on('close', () => database.close());
  return server;
}
