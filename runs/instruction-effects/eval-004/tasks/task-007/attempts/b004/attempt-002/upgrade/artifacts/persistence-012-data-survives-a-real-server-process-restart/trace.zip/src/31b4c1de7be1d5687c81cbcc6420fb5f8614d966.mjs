import { test, expect } from '@playwright/test';
import { stage, projectRow, openProject, isolateBrowser } from './helpers.mjs';

test('012 data survives a real server-process restart', async ({ page, context }) => {
  await isolateBrowser(context);
  await page.goto('/');
  if (stage >= 3) {
    await page.getByRole('combobox', { name: 'Project filter', exact: true }).selectOption({ label: 'Archived' });
    await expect(projectRow(page, stage >= 4 ? 'Persistence renamed' : 'Persistence sentinel').getByTestId('project-summary')).toHaveText('1/1 completed');
  }
  await expect(projectRow(page, stage >= 4 ? 'Persistence renamed' : 'Persistence sentinel')).toBeVisible();
  await openProject(page, stage >= 4 ? 'Persistence renamed' : 'Persistence sentinel');
  if (stage >= 2) {
    await expect(page.getByRole('checkbox', { name: stage >= 5 ? 'Complete Memory kept' : 'Complete Remember me', exact: true })).toBeChecked();
  }
  if (stage >= 6) {
    const priority=page.getByTestId('task-row').filter({hasText:'Memory kept'}).getByRole('combobox', {name:'Task priority', exact:true});
    await expect(priority.locator('option:checked')).toHaveText('High');
    await expect(priority).toBeDisabled();
  }
  if (stage >= 3) {
    await expect(page.getByRole('checkbox', { name: stage >= 5 ? 'Complete Memory kept' : 'Complete Remember me', exact: true })).toBeDisabled();
  }
});
