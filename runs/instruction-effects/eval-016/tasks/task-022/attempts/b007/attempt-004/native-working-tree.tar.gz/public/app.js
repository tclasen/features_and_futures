import { normalizeDueRange } from './due-date.js';
import { matchesSearch } from './search.js';
import { matchesTaskFilters } from './task-filters.js';
import { orderDirectoryTasks } from './directory-order.js';

const app = document.querySelector('#app');
const pendingWrites = new Set();

function element(tag, text, attributes = {}) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  for (const [name, value] of Object.entries(attributes)) node.setAttribute(name, value);
  return node;
}

function renderRows(list, rows) {
  // Avoid detaching focused controls when only saved fields changed.
  if (list.children.length === rows.length
    && rows.every((row, index) => list.children[index] === row)) return;
  list.replaceChildren(...rows);
}

async function request(path, options) {
  const operation = (async () => {
    const response = await fetch(path, options);
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || 'Unable to complete request');
    return body;
  })();
  const writing = options?.method && options.method !== 'GET';
  if (writing) pendingWrites.add(operation);
  try {
    return await operation;
  } finally {
    pendingWrites.delete(operation);
  }
}

async function navigate(path) {
  // A control's selected value can precede its saved response. Let in-flight
  // edits finish before leaving so the next page reads the durable state.
  while (pendingWrites.size) await Promise.allSettled([...pendingWrites]);
  window.location.href = path;
}

function showError(message) {
  let alert = app.querySelector('[role="alert"]');
  if (!alert) {
    alert = element('p', '', { role: 'alert' });
    app.append(alert);
  }
  alert.textContent = message;
}

function searchForm(id, label, buttonLabel, onSearch) {
  const form = element('form', '', { class: 'search-form' });
  const input = element('input', '', { id, type: 'text' });
  form.append(element('label', label, { for: id }), input,
    element('button', buttonLabel, { type: 'submit' }));
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const query = input.value.trim();
    input.value = query;
    onSearch(query);
  });
  return form;
}

function dueRangeControls(onApply) {
  const dueRangeForm = element('form', '', { class: 'due-range' });
  const dueFrom = element('input', '', { id: 'due-from', type: 'text', placeholder: 'YYYY-MM-DD' });
  const dueThrough = element('input', '', { id: 'due-through', type: 'text', placeholder: 'YYYY-MM-DD' });
  dueRangeForm.append(element('label', 'Due from', { for: 'due-from' }), dueFrom,
    element('label', 'Due through', { for: 'due-through' }), dueThrough,
    element('button', 'Apply due range', { type: 'submit' }));
  dueRangeForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const range = normalizeDueRange(dueFrom.value, dueThrough.value);
    if (range.error) return showError(range.error);
    dueFrom.value = range.from;
    dueThrough.value = range.through;
    app.querySelector('[role="alert"]')?.remove();
    onApply(range);
  });
  return dueRangeForm;
}

function filterSelect(id, label, options, controls, onChange) {
  const select = element('select', '', { id });
  for (const option of options) select.append(element('option', option, { value: option }));
  select.addEventListener('change', onChange);
  controls.append(element('label', label, { for: id }), select);
  return select;
}

async function showDirectory() {
  const back = element('button', 'Projects', { type: 'button' });
  back.addEventListener('click', () => navigate('/'));
  app.replaceChildren(back, element('h1', 'Task directory'));
  document.title = 'Task directory · Workboard';
  let tasks = [];
  const rows = new Map();
  let dueRange = { from: '', through: '' };
  let query = '';
  let loading = true;
  const controls = element('div', '', { class: 'task-filters' });
  const scope = filterSelect('project-scope', 'Project scope', ['Active', 'Archived'], controls, render);
  const completion = filterSelect('task-filter', 'Task filter', ['All', 'Open', 'Completed', 'Deleted'], controls, render);
  const priority = filterSelect('priority-filter', 'Priority filter', ['All', 'Low', 'Normal', 'High'], controls, render);
  const order = filterSelect('directory-order', 'Directory order', ['Original', 'Priority', 'Due date', 'Title'], controls, render);
  const rangeForm = dueRangeControls((range) => { dueRange = range; render(); });
  const search = searchForm('directory-search', 'Directory search', 'Search directory', (value) => {
    query = value;
    render();
  });
  const list = element('ul', '', { class: 'directory-tasks', 'aria-label': 'Directory tasks' });
  const actions = element('div', '', { class: 'directory-actions' });
  const complete = element('button', 'Complete visible tasks', { type: 'button' });
  const reopen = element('button', 'Reopen visible tasks', { type: 'button' });
  complete.addEventListener('click', () => bulkCompletion(true));
  reopen.addEventListener('click', () => bulkCompletion(false));
  actions.append(complete, reopen);
  const summary = element('p', '', { 'data-testid': 'directory-summary' });
  const empty = element('p', 'No matching tasks', { role: 'status' });
  app.append(controls, rangeForm, search, actions, summary, list);

  function visibleTasks() {
    return tasks.filter((task) => task.archived === (scope.value === 'Archived')
      && matchesTaskFilters(task, completion.value, priority.value, dueRange, query));
  }

  async function bulkCompletion(completed) {
    if ((completed ? complete : reopen).disabled) return;
    loading = true;
    app.setAttribute('aria-busy', 'true');
    render();
    try {
      tasks = await request('/api/task-directory/completion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed, scope: scope.value, completion: completion.value,
          priority: priority.value, dueRange, query }),
      });
      app.querySelector('[role="alert"]')?.remove();
    } catch (error) {
      showError(error.message);
    } finally {
      loading = false;
      app.setAttribute('aria-busy', 'false');
      render();
    }
  }

  function render() {
    const visible = orderDirectoryTasks(visibleTasks(), order.value);
    summary.hidden = loading;
    if (!loading) {
      const completedCount = visible.filter((task) => task.completed).length;
      summary.textContent = `${completedCount}/${visible.length} completed`;
    }
    const readOnly = loading || scope.value === 'Archived' || completion.value === 'Deleted';
    complete.disabled = readOnly || !visible.some((task) => !task.completed);
    reopen.disabled = readOnly || !visible.some((task) => task.completed);
    empty.remove();
    if (!loading && visible.length === 0) app.append(empty);
    renderRows(list, visible.map((task) => {
      let row = rows.get(task.id);
      if (!row) {
        row = createDirectoryRow(task);
        rows.set(task.id, row);
      }
      row.querySelector('[data-testid="directory-task-completion"]').textContent = task.completed ? 'Completed' : 'Open';
      return row;
    }));
  }

  function createDirectoryRow(task) {
    const row = element('li', '', { 'data-testid': 'directory-task-row' });
    for (const [field, value] of [
      ['directory-task-title', task.title], ['directory-project-name', task.projectName],
      ['directory-task-completion', task.completed ? 'Completed' : 'Open'],
      ['directory-task-priority', task.priority],
      ['directory-task-due-date', task.dueDate ?? ''], ['directory-task-notes', task.notes ?? ''],
    ]) {
      // textContent keeps literal markup and notes as plain text.
      row.append(element('div', value, { 'data-testid': field }));
    }
    const open = element('button', 'Open project', { type: 'button' });
    open.addEventListener('click', () => navigate(`/projects/${task.projectId}`));
    row.append(open);
    return row;
  }

  render();
  try {
    tasks = await request('/api/task-directory');
    loading = false;
    render();
  } finally {
    app.setAttribute('aria-busy', 'false');
  }
}

function projectRow(project, onArchiveChange) {
  const row = element('li', '', { 'data-testid': 'project-row' });
  const open = element('button', 'Open project', { type: 'button' });
  open.addEventListener('click', () => navigate(`/projects/${project.id}`));
  const archive = element('button', project.archived ? 'Restore project' : 'Archive project', { type: 'button' });
  archive.addEventListener('click', async () => {
    archive.disabled = true;
    try {
      const saved = await request(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archived: !project.archived }),
      });
      Object.assign(project, saved);
      app.querySelector('[role="alert"]')?.remove();
      onArchiveChange();
    } catch (error) {
      showError(error.message);
    } finally {
      archive.disabled = false;
    }
  });
  const details = element('div', '', { class: 'project-details' });
  details.append(element('span', project.name), element('span',
    `${project.completedCount}/${project.totalCount} completed`, { 'data-testid': 'project-summary' }));
  const actions = element('div', '', { class: 'project-actions' });
  actions.append(open, archive);
  row.append(details, actions);
  return row;
}

function projectImportForm() {
  const form = element('form', '', { class: 'project-import' });
  const source = element('textarea', '', { id: 'project-json', rows: '8' });
  const name = element('input', '', { id: 'imported-project-name', type: 'text' });
  const submit = element('button', 'Import project', { type: 'submit' });
  form.append(element('label', 'Project JSON', { for: 'project-json' }), source,
    element('label', 'Imported project name', { for: 'imported-project-name' }), name, submit);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (submit.disabled) return;
    if (!name.value.trim()) return showError('Project name is required');
    submit.disabled = true;
    try {
      const project = await request('/api/projects/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.value, json: source.value }),
      });
      navigate(`/projects/${project.id}`);
    } catch (error) {
      showError(error.message);
    } finally {
      submit.disabled = false;
    }
  });
  return form;
}

async function showProjects() {
  app.replaceChildren(element('h1', 'Workboard'));
  let projects = [];
  const rows = new Map();
  const form = element('form');
  const label = element('label', 'Project name', { for: 'project-name' });
  const input = element('input', '', { id: 'project-name', name: 'name', type: 'text' });
  const create = element('button', 'Create project', { type: 'submit' });
  form.append(label, input, create);
  const list = element('ul', '', { 'aria-label': 'Projects', class: 'projects' });
  const filter = element('select', '', { id: 'project-filter' });
  for (const option of ['Active', 'Archived']) {
    filter.append(element('option', option, { value: option }));
  }
  const filters = element('div', '', { class: 'project-filters' });
  filters.append(element('label', 'Project filter', { for: 'project-filter' }), filter);
  let searchQuery = '';
  const search = searchForm('project-search', 'Project search', 'Search projects', (query) => {
    searchQuery = query;
    renderProjects();
  });
  function renderProjects() {
    const visible = projects.filter((project) => project.archived === (filter.value === 'Archived')
      && matchesSearch(project.name, searchQuery));
    renderRows(list, visible.map((project) => {
      let entry = rows.get(project.id);
      if (!entry || entry.archived !== project.archived) {
        entry = { archived: project.archived, row: projectRow(project, renderProjects) };
        rows.set(project.id, entry);
      }
      return entry.row;
    }));
  }
  filter.addEventListener('change', renderProjects);
  const directory = element('button', 'Task directory', { type: 'button' });
  directory.addEventListener('click', () => navigate('/task-directory'));
  app.append(form, filters, search, directory, list, projectImportForm());
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (create.disabled) return;
    const name = input.value.trim();
    if (!name) {
      showError('Project name is required');
      return;
    }
    create.disabled = true;
    try {
      const project = await request('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      projects.push(project);
      renderProjects();
      input.value = '';
      app.querySelector('[role="alert"]')?.remove();
      input.focus();
    } catch (error) {
      showError(error.message);
    } finally {
      create.disabled = false;
    }
  });
  // Load the persisted list before allowing writes so initial rows stay in order.
  create.disabled = true;
  try {
    projects = await request('/api/projects');
    renderProjects();
    create.disabled = false;
  } finally {
    app.setAttribute('aria-busy', 'false');
  }
}

async function showProject(id) {
  app.replaceChildren();
  const back = element('button', 'Projects', { type: 'button' });
  back.addEventListener('click', () => navigate('/'));
  app.append(back);
  try {
    const project = await request(`/api/projects/${id}`);
    const heading = element('h1', project.name);
    app.append(heading);
    const download = element('button', 'Download project', { type: 'button' });
    download.addEventListener('click', () => navigate(`/api/projects/${project.id}/export`));
    app.append(download);
    document.title = `${project.name} · Workboard`;
    if (project.archived) app.append(element('p', 'Archived project'));
    showProjectRename(project, heading);
    showProjectDefaultPriority(project);
    await showTasks(id, project.archived);
  } finally {
    app.setAttribute('aria-busy', 'false');
  }
}

function showProjectRename(project, heading) {
  const form = element('form', '', { class: 'project-rename' });
  const input = element('input', '', { id: 'new-project-name', name: 'name', type: 'text' });
  const rename = element('button', 'Rename project', { type: 'submit' });
  input.value = project.name;
  input.disabled = project.archived;
  rename.disabled = project.archived;
  form.append(element('label', 'New project name', { for: 'new-project-name' }), input, rename);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (rename.disabled) return;
    const name = input.value.trim();
    if (!name) return showError('Project name is required');
    rename.disabled = true;
    try {
      const saved = await request(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      project.name = saved.name;
      heading.textContent = project.name;
      document.title = `${project.name} · Workboard`;
      input.value = project.name;
      app.querySelector('[role="alert"]')?.remove();
    } catch (error) {
      showError(error.message);
    } finally {
      rename.disabled = project.archived;
    }
  });
  app.append(form);
}

function showProjectDefaultPriority(project) {
  const control = element('div', '', { class: 'project-default-priority' });
  const select = element('select', '', { id: 'default-task-priority' });
  for (const priority of ['Low', 'Normal', 'High']) {
    select.append(element('option', priority, { value: priority }));
  }
  select.value = project.defaultPriority;
  select.disabled = project.archived;
  select.addEventListener('change', async () => {
    if (select.disabled) return;
    select.disabled = true;
    try {
      const saved = await request(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ defaultPriority: select.value }),
      });
      project.defaultPriority = saved.defaultPriority;
      app.querySelector('[role="alert"]')?.remove();
    } catch (error) {
      showError(error.message);
    } finally {
      select.value = project.defaultPriority;
      select.disabled = project.archived;
    }
  });
  control.append(element('label', 'Default task priority', { for: 'default-task-priority' }), select);
  app.append(control);
}

function taskRenameForm(task, path, archived, onRename) {
  const form = element('form', '', { class: 'task-rename' });
  const inputId = `new-task-title-${task.id}`;
  const input = element('input', '', { id: inputId, name: 'title', type: 'text' });
  const rename = element('button', 'Rename task', { type: 'submit' });
  input.value = task.title;
  input.disabled = archived;
  rename.disabled = archived;
  form.append(element('label', 'New task title', { for: inputId }), input, rename);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (rename.disabled) return;
    const title = input.value.trim();
    if (!title) return showError('Task title is required');
    rename.disabled = true;
    try {
      const saved = await request(`${path}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title }),
      });
      task.title = saved.title;
      input.value = task.title;
      app.querySelector('[role="alert"]')?.remove();
      onRename();
    } catch (error) {
      showError(error.message);
    } finally {
      rename.disabled = archived;
    }
  });
  return form;
}

function taskPriorityControl(task, path, archived, onPriorityChange) {
  const control = element('div', '', { class: 'task-priority' });
  const inputId = `task-priority-${task.id}`;
  const select = element('select', '', { id: inputId });
  for (const priority of ['Low', 'Normal', 'High']) {
    select.append(element('option', priority, { value: priority }));
  }
  select.value = task.priority;
  select.disabled = archived;
  select.addEventListener('change', async () => {
    if (select.disabled) return;
    select.disabled = true;
    try {
      const saved = await request(`${path}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priority: select.value }),
      });
      // This write only changes priority; other controls may have saved meanwhile.
      task.priority = saved.priority;
      app.querySelector('[role="alert"]')?.remove();
      onPriorityChange();
    } catch (error) {
      showError(error.message);
    } finally {
      select.value = task.priority;
      select.disabled = archived;
    }
  });
  control.append(element('label', 'Task priority', { for: inputId }), select);
  return control;
}

function taskDueDateForm(task, path, archived, onDueDateChange) {
  const form = element('form', '', { class: 'task-due-date' });
  const inputId = `task-due-date-${task.id}`;
  const input = element('input', '', { id: inputId, name: 'dueDate', type: 'text', placeholder: 'YYYY-MM-DD' });
  const save = element('button', 'Save due date', { type: 'submit' });
  input.value = task.dueDate ?? '';
  input.disabled = archived;
  save.disabled = archived;
  form.append(element('label', 'Task due date', { for: inputId }), input, save);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (save.disabled) return;
    save.disabled = true;
    try {
      const saved = await request(`${path}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dueDate: input.value }),
      });
      // Preserve any concurrent changes saved by the other task controls.
      task.dueDate = saved.dueDate;
      input.value = task.dueDate;
      app.querySelector('[role="alert"]')?.remove();
      onDueDateChange();
    } catch (error) {
      showError(error.message);
    } finally {
      save.disabled = archived;
    }
  });
  return form;
}

function taskNotesForm(task, path, archived, onNotesChange) {
  const form = element('form', '', { class: 'task-notes' });
  const inputId = `task-notes-${task.id}`;
  const input = element('textarea', '', { id: inputId, name: 'notes', rows: '4' });
  const save = element('button', 'Save notes', { type: 'submit' });
  input.value = task.notes ?? '';
  input.disabled = archived;
  save.disabled = archived;
  form.append(element('label', 'Task notes', { for: inputId }), input, save);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (save.disabled) return;
    save.disabled = true;
    try {
      const saved = await request(`${path}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes: input.value }),
      });
      // Update only notes so concurrent saves from other controls are retained.
      task.notes = saved.notes;
      app.querySelector('[role="alert"]')?.remove();
      onNotesChange();
    } catch (error) {
      showError(error.message);
    } finally {
      save.disabled = archived;
    }
  });
  return form;
}

function taskMoveForm(task, path, archived, destinations, onMove) {
  const form = element('form', '', { class: 'task-move' });
  const inputId = `destination-project-${task.id}`;
  const select = element('select', '', { id: inputId });
  for (const project of destinations) {
    select.append(element('option', project.name, { value: String(project.id) }));
  }
  const move = element('button', 'Move task', { type: 'submit' });
  const disabled = archived || destinations.length === 0;
  select.disabled = disabled;
  move.disabled = disabled;
  form.append(element('label', 'Destination project', { for: inputId }), select, move);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (move.disabled) return;
    select.disabled = true;
    move.disabled = true;
    try {
      await request(`${path}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destinationProjectId: Number(select.value) }),
      });
      app.querySelector('[role="alert"]')?.remove();
      onMove();
    } catch (error) {
      showError(error.message);
    } finally {
      select.disabled = disabled;
      move.disabled = disabled;
    }
  });
  return form;
}

function taskDeletionControl(task, path, archived, onChange) {
  const button = element('button', task.deleted ? 'Restore task' : 'Delete task', { type: 'button' });
  button.disabled = archived;
  button.addEventListener('click', async () => {
    if (button.disabled) return;
    button.disabled = true;
    try {
      const saved = await request(`${path}/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deleted: !task.deleted }),
      });
      task.deleted = saved.deleted;
      app.querySelector('[role="alert"]')?.remove();
      onChange();
    } catch (error) {
      showError(error.message);
    } finally {
      button.disabled = archived;
    }
  });
  return button;
}

async function showTasks(projectId, archived) {
  const path = `/api/projects/${projectId}/tasks`;
  let tasks = [];
  let destinations = [];
  const rows = new Map();
  const form = element('form');
  const input = element('input', '', { id: 'task-title', name: 'title', type: 'text' });
  const create = element('button', 'Create task', { type: 'submit' });
  create.disabled = true;
  form.append(element('label', 'Task title', { for: 'task-title' }), input, create);
  const filter = element('select', '', { id: 'task-filter' });
  for (const option of ['All', 'Open', 'Completed', 'Deleted']) {
    filter.append(element('option', option, { value: option }));
  }
  const priorityFilter = element('select', '', { id: 'priority-filter' });
  for (const option of ['All', 'Low', 'Normal', 'High']) {
    priorityFilter.append(element('option', option, { value: option }));
  }
  const filters = element('div', '', { class: 'task-filters' });
  filters.append(element('label', 'Task filter', { for: 'task-filter' }), filter,
    element('label', 'Priority filter', { for: 'priority-filter' }), priorityFilter);
  let dueRange = { from: '', through: '' };
  const dueRangeForm = dueRangeControls((range) => {
    dueRange = range;
    renderTasks();
  });
  const list = element('ul', '', { 'aria-label': 'Tasks', class: 'tasks' });
  let searchQuery = '';
  const search = searchForm('task-search', 'Task search', 'Search tasks', (query) => {
    searchQuery = query;
    renderTasks();
  });
  app.append(form, filters, dueRangeForm, search, list);

  function renderTasks() {
    const visible = tasks.filter((task) =>
      matchesTaskFilters(task, filter.value, priorityFilter.value, dueRange, searchQuery));
    renderRows(list, visible.map((task) => {
      let entry = rows.get(task.id);
      if (!entry || entry.deleted !== Boolean(task.deleted)) {
        entry = { deleted: Boolean(task.deleted), row: createTaskRow(task) };
        rows.set(task.id, entry);
      }
      return entry.row;
    }));
  }

  // Keep controls alive across edits and filtering. Rebuilding unrelated rows
  // discards drafts and pending-control state, and duplicates large destination menus.
  function createTaskRow(task) {
    const row = element('li', '', { 'data-testid': 'task-row' });
    const readOnly = archived || Boolean(task.deleted);
    const checkbox = element('input', '', {
      type: 'checkbox', 'aria-label': `Complete ${task.title}`,
    });
    checkbox.checked = task.completed;
    checkbox.disabled = readOnly;
    checkbox.addEventListener('change', async () => {
      checkbox.disabled = true;
      try {
        const saved = await request(`${path}/${task.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ completed: checkbox.checked }),
        });
        task.completed = saved.completed;
        app.querySelector('[role="alert"]')?.remove();
        renderTasks();
      } catch (error) {
        checkbox.checked = task.completed;
        showError(error.message);
      } finally {
        checkbox.disabled = readOnly;
      }
    });
    const details = element('div', '', { class: 'task-details' });
    const title = element('span', task.title);
    details.append(title, taskRenameForm(task, path, readOnly, () => {
      title.textContent = task.title;
      checkbox.setAttribute('aria-label', `Complete ${task.title}`);
      renderTasks();
    }),
      taskPriorityControl(task, path, readOnly, renderTasks), taskDueDateForm(task, path, readOnly, renderTasks),
      taskNotesForm(task, path, readOnly, renderTasks),
      taskMoveForm(task, path, readOnly, destinations, () => {
        tasks = tasks.filter((remaining) => remaining.id !== task.id);
        renderTasks();
      }));
    details.append(taskDeletionControl(task, path, archived, renderTasks));
    row.append(checkbox, details);
    return row;
  }

  filter.addEventListener('change', renderTasks);
  priorityFilter.addEventListener('change', renderTasks);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (create.disabled) return;
    const title = input.value.trim();
    if (!title) return showError('Task title is required');
    create.disabled = true;
    try {
      const task = await request(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title }),
      });
      tasks.push(task);
      renderTasks();
      input.value = '';
      app.querySelector('[role="alert"]')?.remove();
      input.focus();
    } catch (error) {
      showError(error.message);
    } finally {
      create.disabled = archived;
    }
  });
  const [savedTasks, projects] = await Promise.all([request(path), request('/api/projects')]);
  tasks = savedTasks;
  destinations = projects.filter((project) => !project.archived && project.id !== Number(projectId));
  renderTasks();
  create.disabled = archived;
}

const projectRoute = window.location.pathname.match(/^\/projects\/(\d+)$/);
try {
  if (projectRoute) await showProject(projectRoute[1]);
  else if (window.location.pathname === '/task-directory') await showDirectory();
  else await showProjects();
} catch (error) {
  showError(error.message);
}
